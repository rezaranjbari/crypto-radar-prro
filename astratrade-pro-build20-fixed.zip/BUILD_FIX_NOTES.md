# AstraTrade Pro build fix

Fixed Kotlin compilation errors reported by GitHub Actions Build APK #20:

- `NewsRepository.kt`: converted `parse()` from an expression-body function to a block-body function so early return/error handling is valid Kotlin.
- `NewsScreen.kt`: fixed the malformed localized refresh label (`if/else` expression).

The Google Services message is a warning because `google-services.json` is intentionally optional in this build; it is not the Kotlin compilation failure.

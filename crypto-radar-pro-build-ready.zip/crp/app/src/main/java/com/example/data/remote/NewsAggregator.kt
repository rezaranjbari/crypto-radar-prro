package com.example.data.remote

import com.example.data.model.CryptoNewsItem
import com.example.data.model.NewsImpact
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import android.util.Xml

object NewsAggregator {
    private val client = okhttp3.OkHttpClient.Builder().build()
    private val rssSources = listOf(
        "CoinDesk" to "https://www.coindesk.com/arc/outboundfeeds/rss/?output=1",
        "Cointelegraph" to "https://cointelegraph.com/rss"
    )

    suspend fun fetch(): List<CryptoNewsItem> = withContext(Dispatchers.IO) {
        coroutineScope {
            val cryptoCompare = async {
                runCatching { NetworkClient.news.getNews().data.orEmpty().mapNotNull { dto ->
                    val title = dto.title?.trim().orEmpty()
                    if (title.isBlank()) null else classify(
                        CryptoNewsItem(
                            id = dto.id ?: title.hashCode().toString(),
                            title = title,
                            body = dto.body.orEmpty(),
                            source = dto.source ?: "CryptoCompare",
                            url = dto.url.orEmpty(),
                            publishedAt = (dto.publishedOn ?: 0L) * 1000L
                        )
                    )
                } }
            }
            val rss = rssSources.map { (source, url) ->
                async { fetchRss(source, url) }
            }
            val allResults: List<List<CryptoNewsItem>> =
                (listOf(cryptoCompare) + rss).awaitAll()

            allResults.flatten()
                .filter { item -> item.url.isNotBlank() && item.publishedAt > 0 }
                .distinctBy { item -> item.title.lowercase().replace(Regex("\\s+"), " ") }
                .sortedByDescending { item -> item.publishedAt }
                .take(80)
        }
    }

    private fun fetchRss(source: String, url: String): List<CryptoNewsItem> {
        return runCatching {
            val response = client.newCall(Request.Builder().url(url).get().build()).execute()
            if (!response.isSuccessful) return emptyList()
            val body = response.body?.string() ?: return emptyList()
            val parser = Xml.newPullParser().apply {
                setInput(body.reader())
            }
            val result = mutableListOf<CryptoNewsItem>()
            var event = parser.eventType
            var title = ""; var link = ""; var desc = ""; var pub = 0L
            while (event != XmlPullParser.END_DOCUMENT) {
                if (event == XmlPullParser.START_TAG && parser.name.equals("item", true)) {
                    title = ""; link = ""; desc = ""; pub = 0L
                } else if (event == XmlPullParser.START_TAG) {
                    when (parser.name.lowercase()) {
                        "title" -> title = parser.nextText().trim()
                        "link" -> link = parser.nextText().trim()
                        "description", "summary" -> desc = parser.nextText().trim()
                        "pubdate", "published", "updated" -> pub = parseDate(parser.nextText())
                    }
                } else if (event == XmlPullParser.END_TAG && parser.name.equals("item", true)) {
                    if (title.isNotBlank() && link.isNotBlank()) {
                        result += classify(CryptoNewsItem(
                            id = "${source}_${title.hashCode()}",
                            title = title,
                            body = desc.replace(Regex("<[^>]+>"), "").trim(),
                            source = source,
                            url = link,
                            publishedAt = pub.takeIf { it > 0 } ?: System.currentTimeMillis()
                        ))
                    }
                }
                event = parser.next()
            }
            result
        }.getOrDefault(emptyList())
    }

    private fun parseDate(value: String): Long = runCatching {
        java.time.ZonedDateTime.parse(value, java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME)
            .toInstant().toEpochMilli()
    }.getOrElse { System.currentTimeMillis() }

    private fun classify(item: CryptoNewsItem): CryptoNewsItem {
        val text = "${item.title} ${item.body}".lowercase()
        val high = listOf("sec", "etf", "hack", "exploit", "bankruptcy", "fed", "rate cut", "rate hike", "war", "sanction", "lawsuit", "approval", "delist", "de-list", "stablecoin law")
        val medium = listOf("listing", "unlock", "upgrade", "partnership", "whale", "liquidation", "funding", "airdrop")
        val impact = when {
            high.any { text.contains(it) } -> NewsImpact.HIGH
            medium.any { text.contains(it) } -> NewsImpact.MEDIUM
            else -> NewsImpact.LOW
        }
        val category = when {
            high.any { text.contains(it) } -> "Breaking / Macro"
            text.contains("bitcoin") || text.contains("btc") -> "Bitcoin"
            text.contains("ethereum") || text.contains("eth") -> "Ethereum"
            text.contains("regulat") || text.contains("sec") -> "Regulation"
            text.contains("hack") || text.contains("exploit") -> "Security"
            else -> "Market"
        }
        return item.copy(impact = impact, category = category, isVerified = true)
    }
}

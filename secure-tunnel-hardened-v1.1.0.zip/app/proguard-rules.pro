# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.

# ============================================================
# Secure Tunnel - Personal Hardened Build
# ============================================================
# Do not keep debugging metadata unnecessarily.
-dontusemixedcaseclassnames
-dontpreverify

# Keep Android components required by the framework.
-keep public class * extends android.app.Activity
-keep public class * extends android.app.Service

# Keep Parcelable implementations.
-keepclassmembers class * implements android.os.Parcelable {
    static android.os.Parcelable$Creator CREATOR;
}

# Keep Serializable fields.
-keepclassmembers class * implements java.io.Serializable {
    static final long serialVersionUID;
}

# Remove logging calls where possible in release.
-assumenosideeffects class android.util.Log {
    public static *** d(...);
    public static *** v(...);
    public static *** i(...);
}

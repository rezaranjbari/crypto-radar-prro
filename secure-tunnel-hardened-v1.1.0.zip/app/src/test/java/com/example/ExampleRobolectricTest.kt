package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelProtocol
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Secure Tunnel", appName)
  }

  @Test
  fun `test vless uri parsing and generation`() {
    val uri = "vless://00000000-0000-4000-8000-000000000001@1.1.1.1:443?security=tls&fp=chrome&alpn=h2%2Chttp%2F1.1&sni=cloudflare-dns.com#Test+Vless"
    val parsed = TunnelProfile.parseUri(uri)
    assertNotNull(parsed)
    assertEquals(TunnelProtocol.VLESS, parsed?.protocol)
    assertEquals("1.1.1.1", parsed?.server)
    assertEquals(443, parsed?.port)
    assertEquals("00000000-0000-4000-8000-000000000001", parsed?.secret)
    assertEquals("cloudflare-dns.com", parsed?.sni)
    assertTrue(parsed?.tlsEnabled == true)
    assertEquals(false, parsed?.allowInsecure) // Hardened build must enforce allowInsecure = false
  }

  @Test
  fun `test trojan uri parsing`() {
    val uri = "trojan://mypassword@example.com:443?sni=example.com#Trojan+Node"
    val parsed = TunnelProfile.parseUri(uri)
    assertNotNull(parsed)
    assertEquals(TunnelProtocol.TROJAN, parsed?.protocol)
    assertEquals("example.com", parsed?.server)
    assertEquals("mypassword", parsed?.secret)
  }
}

package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.VpnLock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PingStatus
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelProtocol
import com.example.ui.MainViewModel
import com.example.ui.components.CyberBadge
import com.example.ui.components.CyberCard
import com.example.ui.components.MetricBox
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberBorderGlow
import com.example.ui.theme.CyberNavyBackground
import com.example.ui.theme.CyberNavyCard
import com.example.ui.theme.CyberNavySurface
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonEmeraldDark
import com.example.ui.theme.NeonPurple
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun TunnelManagerScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val profiles by viewModel.profiles.collectAsState()
    val activeProfileId by viewModel.activeProfileId.collectAsState()
    val isConnected by viewModel.isTunnelConnected.collectAsState()
    val isConnecting by viewModel.isConnecting.collectAsState()
    val killSwitch by viewModel.killSwitchEnabled.collectAsState()
    val bytesUp by viewModel.bytesUploaded.collectAsState()
    val bytesDown by viewModel.bytesDownloaded.collectAsState()
    val durationSec by viewModel.connectionDurationSec.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()

    val showEditDialog by viewModel.showEditDialog.collectAsState()
    val profileToEdit by viewModel.profileToEdit.collectAsState()
    val showImportDialog by viewModel.showImportDialog.collectAsState()
    val importError by viewModel.importError.collectAsState()

    val activeProfile = profiles.find { it.id == activeProfileId } ?: profiles.firstOrNull()
    val context = LocalContext.current

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                HeroTunnelCard(
                    isConnected = isConnected,
                    isConnecting = isConnecting,
                    activeProfile = activeProfile,
                    killSwitch = killSwitch,
                    bytesUp = bytesUp,
                    bytesDown = bytesDown,
                    durationSec = durationSec,
                    onToggleConnection = { viewModel.toggleTunnelConnection() },
                    onToggleKillSwitch = { viewModel.toggleKillSwitch(it) }
                )
            }

            if (statusMessage != null) {
                item {
                    CyberCard(borderColor = NeonAmber.copy(alpha = 0.5f), backgroundColor = CyberNavyCard) {
                        Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = NeonAmber, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(statusMessage!!, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { viewModel.clearStatusMessage() }) { Text("OK") }
                        }
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Hardened Tunnel Profiles",
                    subtitle = "${profiles.size} encrypted endpoints configured",
                    trailing = {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { viewModel.pingAllProfiles() },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonCyan),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                                modifier = Modifier.testTag("ping_all_button")
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = "Ping All", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Ping All", fontSize = 12.sp)
                            }
                            OutlinedButton(
                                onClick = { viewModel.openImportDialog() },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonEmerald),
                                border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                                modifier = Modifier.testTag("import_uri_button")
                            ) {
                                Icon(Icons.Default.VpnLock, contentDescription = "Import URI", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Import", fontSize = 12.sp)
                            }
                        }
                    }
                )
            }

            items(profiles, key = { it.id }) { profile ->
                TunnelProfileCard(
                    profile = profile,
                    isSelected = profile.id == activeProfileId,
                    onSelect = { viewModel.selectProfile(profile.id) },
                    onPing = { viewModel.pingProfile(profile.id) },
                    onEdit = { viewModel.openEditProfileDialog(profile) },
                    onDelete = { viewModel.deleteProfile(profile.id) },
                    onShare = {
                        val shareUri = profile.toShareableUri()
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        clipboard.setPrimaryClip(ClipData.newPlainText("Tunnel URI", shareUri))
                        Toast.makeText(context, "URI copied to clipboard", Toast.LENGTH_SHORT).show()
                    }
                )
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // FAB to add new profile
        FloatingActionButton(
            onClick = { viewModel.openAddProfileDialog() },
            containerColor = NeonEmerald,
            contentColor = CyberNavyBackground,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(24.dp)
                .testTag("add_profile_fab")
        ) {
            Icon(Icons.Default.Add, contentDescription = "Add Profile")
        }
    }

    if (showEditDialog) {
        EditProfileDialog(
            initialProfile = profileToEdit,
            onDismiss = { viewModel.closeEditDialog() },
            onSave = { viewModel.saveProfile(it) }
        )
    }

    if (showImportDialog) {
        ImportUriDialog(
            errorMessage = importError,
            onDismiss = { viewModel.closeImportDialog() },
            onImport = { viewModel.importProfileFromUri(it) }
        )
    }
}

@Composable
fun HeroTunnelCard(
    isConnected: Boolean,
    isConnecting: Boolean,
    activeProfile: TunnelProfile?,
    killSwitch: Boolean,
    bytesUp: Long,
    bytesDown: Long,
    durationSec: Long,
    onToggleConnection: () -> Unit,
    onToggleKillSwitch: (Boolean) -> Unit
) {
    val statusColor by animateColorAsState(
        targetValue = when {
            isConnected -> NeonEmerald
            isConnecting -> NeonCyan
            else -> TextMuted
        },
        label = "heroColor"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isConnected) 1.08f else 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    CyberCard(
        borderColor = if (isConnected) NeonEmerald.copy(alpha = 0.5f) else CyberBorder,
        borderWidth = if (isConnected) 1.5.dp else 1.dp,
        backgroundColor = CyberNavyCard
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Status Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CyberBadge(
                    text = when {
                        isConnected -> "TUNNEL SECURED • TLS 1.3"
                        isConnecting -> "CONNECTING..."
                        else -> "DISCONNECTED"
                    },
                    color = statusColor
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Kill Switch",
                        tint = if (killSwitch) NeonCyan else TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Kill-Switch",
                        fontSize = 11.sp,
                        color = if (killSwitch) TextPrimary else TextMuted,
                        fontWeight = FontWeight.Medium
                    )
                    Switch(
                        checked = killSwitch,
                        onCheckedChange = onToggleKillSwitch,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonCyan,
                            checkedTrackColor = CyberNavySurface,
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = CyberNavySurface
                        ),
                        modifier = Modifier.scale(0.75f)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Main Connect Button Circle
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(120.dp)
                    .scale(pulseScale)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            colors = if (isConnected) listOf(
                                NeonEmerald.copy(alpha = 0.35f),
                                CyberNavySurface
                            ) else listOf(
                                CyberNavySurface,
                                CyberNavyBackground
                            )
                        )
                    )
                    .border(
                        width = 2.dp,
                        color = statusColor,
                        shape = CircleShape
                    )
                    .clickable(onClick = onToggleConnection)
                    .testTag("connect_toggle_button")
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PowerSettingsNew,
                        contentDescription = "Power",
                        tint = statusColor,
                        modifier = Modifier.size(44.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isConnected) "CONNECTED" else "CONNECT",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Active Endpoint Details
            if (activeProfile != null) {
                Text(
                    text = activeProfile.name,
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${activeProfile.protocol.displayName} • ${activeProfile.server}:${activeProfile.port}",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            } else {
                Text(
                    text = "No profile selected",
                    color = TextMuted,
                    fontSize = 14.sp
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Live Metrics Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricBox(
                    title = "Download",
                    value = formatBytes(bytesDown),
                    unit = null,
                    modifier = Modifier.weight(1f),
                    accentColor = NeonCyan
                )
                MetricBox(
                    title = "Upload",
                    value = formatBytes(bytesUp),
                    unit = null,
                    modifier = Modifier.weight(1f),
                    accentColor = NeonPurple
                )
                MetricBox(
                    title = "Session",
                    value = formatDuration(durationSec),
                    unit = null,
                    modifier = Modifier.weight(1f),
                    accentColor = NeonEmerald
                )
            }
        }
    }
}

@Composable
fun TunnelProfileCard(
    profile: TunnelProfile,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onPing: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit
) {
    CyberCard(
        borderColor = if (isSelected) NeonEmerald else CyberBorder,
        borderWidth = if (isSelected) 1.5.dp else 1.dp,
        backgroundColor = if (isSelected) CyberNavyCard else CyberNavySurface,
        onClick = onSelect,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    RadioButton(
                        selected = isSelected,
                        onClick = onSelect,
                        colors = RadioButtonDefaults.colors(
                            selectedColor = NeonEmerald,
                            unselectedColor = TextMuted
                        )
                    )
                    Column {
                        Text(
                            text = profile.name,
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${profile.server}:${profile.port}",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }

                // Ping Status Badge / Button
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = CyberNavyBackground,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                    modifier = Modifier.clickable(onClick = onPing)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        val pingColor = when (profile.pingStatus) {
                            PingStatus.PROBING -> NeonCyan
                            PingStatus.REACHABLE -> NeonEmerald
                            PingStatus.UNREACHABLE -> NeonRed
                            PingStatus.IDLE -> TextMuted
                        }
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(pingColor)
                        )
                        Text(
                            text = when (profile.pingStatus) {
                                PingStatus.PROBING -> "Probing..."
                                PingStatus.REACHABLE -> "${profile.latencyMs ?: 0} ms"
                                PingStatus.UNREACHABLE -> "Timeout"
                                PingStatus.IDLE -> "Test Ping"
                            },
                            color = pingColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Specs Chips & Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CyberBadge(text = profile.protocol.displayName, color = NeonCyan)
                    if (profile.tlsEnabled) {
                        CyberBadge(text = "TLS 1.3", color = NeonEmerald)
                    }
                    if (profile.cipher.isNotBlank() && profile.cipher != "none") {
                        CyberBadge(text = profile.cipher.uppercase(), color = NeonPurple)
                    }
                }

                Row {
                    IconButton(onClick = onShare, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy URI", tint = TextSecondary, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = TextSecondary, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Profile", tint = NeonRed.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileDialog(
    initialProfile: TunnelProfile?,
    onDismiss: () -> Unit,
    onSave: (TunnelProfile) -> Unit
) {
    var name by remember { mutableStateOf(initialProfile?.name ?: "New Secure Node") }
    var protocol by remember { mutableStateOf(initialProfile?.protocol ?: TunnelProtocol.VLESS) }
    var server by remember { mutableStateOf(initialProfile?.server ?: "") }
    var portText by remember { mutableStateOf(initialProfile?.port?.toString() ?: protocol.defaultPort.toString()) }
    var secret by remember { mutableStateOf(initialProfile?.secret ?: "") }
    var cipher by remember { mutableStateOf(initialProfile?.cipher ?: "chacha20-poly1305") }
    var tlsEnabled by remember { mutableStateOf(initialProfile?.tlsEnabled ?: true) }
    var sni by remember { mutableStateOf(initialProfile?.sni ?: "") }
    var expandedDropdown by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialProfile == null) "Add Hardened Tunnel Profile" else "Edit Profile",
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        containerColor = CyberNavyCard,
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Profile Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonEmerald,
                        unfocusedBorderColor = CyberBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Protocol Dropdown
                ExposedDropdownMenuBox(
                    expanded = expandedDropdown,
                    onExpandedChange = { expandedDropdown = !expandedDropdown }
                ) {
                    OutlinedTextField(
                        value = protocol.displayName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Protocol") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDropdown) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonEmerald,
                            unfocusedBorderColor = CyberBorder
                        ),
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedDropdown,
                        onDismissRequest = { expandedDropdown = false }
                    ) {
                        TunnelProtocol.entries.forEach { proto ->
                            DropdownMenuItem(
                                text = { Text(proto.displayName) },
                                onClick = {
                                    protocol = proto
                                    portText = proto.defaultPort.toString()
                                    expandedDropdown = false
                                }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = server,
                        onValueChange = { server = it },
                        label = { Text("Server Host / IP") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonEmerald,
                            unfocusedBorderColor = CyberBorder
                        ),
                        modifier = Modifier.weight(2f)
                    )
                    OutlinedTextField(
                        value = portText,
                        onValueChange = { portText = it },
                        label = { Text("Port") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonEmerald,
                            unfocusedBorderColor = CyberBorder
                        ),
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = secret,
                    onValueChange = { secret = it },
                    label = { Text("Secret / UUID / Password") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonEmerald,
                        unfocusedBorderColor = CyberBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Enable TLS 1.3", color = TextPrimary, fontSize = 14.sp)
                    Switch(
                        checked = tlsEnabled,
                        onCheckedChange = { tlsEnabled = it },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonEmerald,
                            checkedTrackColor = CyberNavySurface
                        )
                    )
                }

                if (tlsEnabled) {
                    OutlinedTextField(
                        value = sni,
                        onValueChange = { sni = it },
                        label = { Text("Server Name Indication (SNI)") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonEmerald,
                            unfocusedBorderColor = CyberBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val port = portText.toIntOrNull() ?: protocol.defaultPort
                    val profile = (initialProfile ?: TunnelProfile(
                        name = name,
                        protocol = protocol,
                        server = server,
                        port = port,
                        secret = secret
                    )).copy(
                        name = name.ifBlank { "Secure Node" },
                        protocol = protocol,
                        server = server.ifBlank { "127.0.0.1" },
                        port = port,
                        secret = secret,
                        cipher = cipher,
                        tlsEnabled = tlsEnabled,
                        sni = sni,
                        allowInsecure = false
                    )
                    onSave(profile)
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald, contentColor = CyberNavyBackground)
            ) {
                Text("Save Node")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

@Composable
fun ImportUriDialog(
    errorMessage: String?,
    onDismiss: () -> Unit,
    onImport: (String) -> Unit
) {
    var rawUri by remember { mutableStateOf("") }
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Import Secure Tunnel URI",
                color = TextPrimary,
                fontWeight = FontWeight.Bold
            )
        },
        containerColor = CyberNavyCard,
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "Paste a standard configuration link (vless://, trojan://, ss://, socks5://):",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                OutlinedTextField(
                    value = rawUri,
                    onValueChange = { rawUri = it },
                    placeholder = { Text("vless://uuid@server:port?security=tls#Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonEmerald,
                        unfocusedBorderColor = CyberBorder
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = {
                            val clip = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val item = clip.primaryClip?.getItemAt(0)?.text?.toString()
                            if (!item.isNullOrBlank()) {
                                rawUri = item.trim()
                            }
                        }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Paste", tint = NeonCyan)
                        }
                    }
                )

                if (errorMessage != null) {
                    Text(
                        text = errorMessage,
                        color = NeonRed,
                        fontSize = 12.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onImport(rawUri) },
                colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald, contentColor = CyberNavyBackground)
            ) {
                Text("Import")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = TextSecondary)
            }
        }
    )
}

fun formatBytes(bytes: Long): String {
    return when {
        bytes >= 1024 * 1024 * 1024 -> String.format(Locale.US, "%.1f GB", bytes / (1024.0 * 1024 * 1024))
        bytes >= 1024 * 1024 -> String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024))
        bytes >= 1024 -> String.format(Locale.US, "%.1f KB", bytes / 1024.0)
        else -> "$bytes B"
    }
}

fun formatDuration(seconds: Long): String {
    val hrs = seconds / 3600
    val mins = (seconds % 3600) / 60
    val secs = seconds % 60
    return if (hrs > 0) {
        String.format(Locale.US, "%02d:%02d:%02d", hrs, mins, secs)
    } else {
        String.format(Locale.US, "%02d:%02d", mins, secs)
    }
}

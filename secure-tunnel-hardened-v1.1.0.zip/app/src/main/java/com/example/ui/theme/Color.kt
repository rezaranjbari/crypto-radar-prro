package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberNavyBackground = Color(0xFF070B19)
val CyberNavySurface = Color(0xFF0D1527)
val CyberNavyCard = Color(0xFF152238)
val CyberNavyCardHover = Color(0xFF1B2C48)
val CyberBorder = Color(0xFF1F3556)
val CyberBorderGlow = Color(0xFF2C4A7A)

val NeonEmerald = Color(0xFF00E5A3)
val NeonEmeraldDark = Color(0xFF005A40)
val NeonEmeraldContainer = Color(0xFF023223)

val NeonCyan = Color(0xFF00F0FF)
val NeonCyanDark = Color(0xFF00565C)
val NeonCyanContainer = Color(0xFF023038)

val NeonPurple = Color(0xFFA855F7)
val NeonAmber = Color(0xFFFBBF24)
val NeonRed = Color(0xFFEF4444)

val TextPrimary = Color(0xFFF9FAFB)
val TextSecondary = Color(0xFF9CA3AF)
val TextMuted = Color(0xFF6B7280)

package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AuditCheckItem
import com.example.data.model.DohQueryResult
import com.example.data.model.FullAuditReport
import com.example.data.model.NetworkInterfaceInfo
import com.example.data.model.TlsInspectionResult
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelProtocol
import com.example.data.repository.NetworkDiagnosticsService
import com.example.data.repository.SecurityAuditEngine
import com.example.data.repository.TunnelRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AppTab(val title: String) {
    TUNNEL("Tunnel"),
    AUDIT("Security Audit"),
    DIAGNOSTICS("Diagnostics"),
    HARDENING("Build CI")
}

data class WorkflowStepItem(
    val stepNumber: Int,
    val title: String,
    val commandSummary: String,
    val description: String,
    val isHardened: Boolean = true
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val tunnelRepo = TunnelRepository(application)
    private val auditEngine = SecurityAuditEngine(application)
    private val diagnosticsService = NetworkDiagnosticsService()

    // Navigation state
    private val _currentTab = MutableStateFlow(AppTab.TUNNEL)
    val currentTab: StateFlow<AppTab> = _currentTab.asStateFlow()

    // Tunnel states
    val profiles = tunnelRepo.profiles
    val activeProfileId = tunnelRepo.activeProfileId
    val isTunnelConnected = tunnelRepo.isTunnelConnected
    val isConnecting = tunnelRepo.isConnecting
    val killSwitchEnabled = tunnelRepo.killSwitchEnabled
    val bytesUploaded = tunnelRepo.bytesUploaded
    val bytesDownloaded = tunnelRepo.bytesDownloaded
    val connectionDurationSec = tunnelRepo.connectionDurationSec
    val statusMessage = tunnelRepo.statusMessage

    // Audit states
    private val _auditReport = MutableStateFlow<FullAuditReport?>(null)
    val auditReport: StateFlow<FullAuditReport?> = _auditReport.asStateFlow()

    private val _isAuditing = MutableStateFlow(false)
    val isAuditing: StateFlow<Boolean> = _isAuditing.asStateFlow()

    // TLS Inspector states
    private val _tlsInspection = MutableStateFlow<TlsInspectionResult?>(null)
    val tlsInspection: StateFlow<TlsInspectionResult?> = _tlsInspection.asStateFlow()

    private val _isInspectingTls = MutableStateFlow(false)
    val isInspectingTls: StateFlow<Boolean> = _isInspectingTls.asStateFlow()

    // DoH query states
    private val _dohResult = MutableStateFlow<DohQueryResult?>(null)
    val dohResult: StateFlow<DohQueryResult?> = _dohResult.asStateFlow()

    private val _isQueryingDoh = MutableStateFlow(false)
    val isQueryingDoh: StateFlow<Boolean> = _isQueryingDoh.asStateFlow()

    // Network interfaces
    private val _networkInterfaces = MutableStateFlow<List<NetworkInterfaceInfo>>(emptyList())
    val networkInterfaces: StateFlow<List<NetworkInterfaceInfo>> = _networkInterfaces.asStateFlow()

    // Dialog & UI states
    private val _profileToEdit = MutableStateFlow<TunnelProfile?>(null)
    val profileToEdit: StateFlow<TunnelProfile?> = _profileToEdit.asStateFlow()

    private val _showEditDialog = MutableStateFlow(false)
    val showEditDialog: StateFlow<Boolean> = _showEditDialog.asStateFlow()

    private val _showImportDialog = MutableStateFlow(false)
    val showImportDialog: StateFlow<Boolean> = _showImportDialog.asStateFlow()

    private val _importError = MutableStateFlow<String?>(null)
    val importError: StateFlow<String?> = _importError.asStateFlow()

    // Workflow step items reflecting the GitHub Actions steps
    val workflowSteps = listOf(
        WorkflowStepItem(1, "Checkout Source", "uses: actions/checkout@v4", "Retrieves clean repository source code."),
        WorkflowStepItem(2, "Setup Java 17", "distribution: temurin, java-version: 17", "Configures modern JDK runtime environment."),
        WorkflowStepItem(3, "Detect Android Project", "find ./gradlew", "Identifies root Android Gradle directory."),
        WorkflowStepItem(4, "Manifest Security Audit", "grep usesCleartextTraffic / allowBackup", "Scans AndroidManifest for security flags."),
        WorkflowStepItem(5, "Disable Cleartext Traffic", "usesCleartextTraffic=\"false\"", "Enforces strict TLS; plain HTTP sockets rejected."),
        WorkflowStepItem(6, "Disable Application Backup", "allowBackup=\"false\", fullBackupContent=\"false\"", "Prevents device ADB and cloud backup data extraction."),
        WorkflowStepItem(7, "Harden Network Security Config", "network_security_config.xml (<certificates src=\"system\"/>)", "Restricts trust anchors exclusively to system CAs to defeat MitM."),
        WorkflowStepItem(8, "Secure Data Extraction Rules", "data_extraction_rules.xml (exclude domain=\"root\")", "Restricts local file extraction across backups and device migration."),
        WorkflowStepItem(9, "Harden Release Build", "isDebuggable = false, isMinifyEnabled = true", "Eliminates JDWP debug hooks and applies R8 code optimization."),
        WorkflowStepItem(10, "Harden R8 Configuration", "proguard-rules.pro (assumenosideeffects Log.d/v/i)", "Redacts all debug log calls from the compiled release DEX."),
        WorkflowStepItem(11, "Sensitive Permissions Audit", "grep dangerous permissions", "Ensures zero permissions for camera, contacts, SMS, or location."),
        WorkflowStepItem(12, "Audit Exported Components", "grep android:exported", "Guarantees only launcher activity is exported to third-party apps."),
        WorkflowStepItem(13, "Zero Telemetry & Analytics Audit", "grep firebase/analytics/sentry/mixpanel", "Verifies binary is completely free from ad and tracking SDKs."),
        WorkflowStepItem(14, "Audit HTTP Endpoints", "grep http://", "Assures zero plaintext unencrypted network URLs in code."),
        WorkflowStepItem(15, "Secret & Private Key Scan", "grep BEGIN RSA PRIVATE KEY / api_key", "Scans source code for accidentally committed private keys."),
        WorkflowStepItem(16, "Dependency Report", "gradle dependencies --configuration releaseRuntimeClasspath", "Validates clean dependency tree with zero rogue libraries."),
        WorkflowStepItem(17, "Clean Project", "gradle clean", "Ensures reproducible and pristine compilation environment."),
        WorkflowStepItem(18, "Build Release APK", "gradle assembleRelease --stacktrace", "Compiles hardened APK with release signing configurations."),
        WorkflowStepItem(19, "Locate APK Artifact", "find app/build/outputs/apk", "Confirms presence of built release APK."),
        WorkflowStepItem(20, "Create Source ZIP", "zip -r release/SecureTunnel-hardened-source.zip", "Packages verified hardened source archive."),
        WorkflowStepItem(21, "Collect APK Artifact", "cp *.apk release/apk/", "Stages release APK for distribution."),
        WorkflowStepItem(22, "Generate Security Report", "cat > release/SECURITY_REPORT.txt", "Emits formal cryptographic audit and threat model disclosure."),
        WorkflowStepItem(23, "Upload APK Artifact", "uses: actions/upload-artifact@v4", "Archives hardened APK securely."),
        WorkflowStepItem(24, "Upload Source ZIP", "uses: actions/upload-artifact@v4", "Stores source code bundle artifact."),
        WorkflowStepItem(25, "Upload Security Report", "uses: actions/upload-artifact@v4", "Publishes verifiable security audit report.")
    )

    init {
        runSecurityAudit()
        refreshNetworkInterfaces()
    }

    fun setTab(tab: AppTab) {
        _currentTab.value = tab
    }

    fun toggleTunnelConnection() {
        if (isTunnelConnected.value) tunnelRepo.disconnectTunnel() else tunnelRepo.connectTunnel()
    }

    fun clearStatusMessage() = tunnelRepo.clearStatus()

    fun selectProfile(id: String) {
        tunnelRepo.selectProfile(id)
    }

    fun toggleKillSwitch(enabled: Boolean) {
        tunnelRepo.setKillSwitch(enabled)
    }

    fun pingProfile(id: String) {
        viewModelScope.launch {
            tunnelRepo.pingProfile(id)
        }
    }

    fun pingAllProfiles() {
        viewModelScope.launch {
            tunnelRepo.pingAllProfiles()
        }
    }

    fun openAddProfileDialog() {
        _profileToEdit.value = null
        _showEditDialog.value = true
    }

    fun openEditProfileDialog(profile: TunnelProfile) {
        _profileToEdit.value = profile
        _showEditDialog.value = true
    }

    fun closeEditDialog() {
        _showEditDialog.value = false
        _profileToEdit.value = null
    }

    fun saveProfile(profile: TunnelProfile) {
        if (_profileToEdit.value == null) {
            tunnelRepo.addProfile(profile)
        } else {
            tunnelRepo.updateProfile(profile)
        }
        closeEditDialog()
    }

    fun deleteProfile(id: String) {
        tunnelRepo.deleteProfile(id)
    }

    fun openImportDialog() {
        _importError.value = null
        _showImportDialog.value = true
    }

    fun closeImportDialog() {
        _showImportDialog.value = false
        _importError.value = null
    }

    fun importProfileFromUri(rawUri: String) {
        val parsed = TunnelProfile.parseUri(rawUri)
        if (parsed != null) {
            tunnelRepo.addProfile(parsed)
            closeImportDialog()
        } else {
            _importError.value = "Unsupported format. Supported: vless://, vmess://, trojan://, ss://, socks5://, wireguard://"
        }
    }

    fun runSecurityAudit() {
        viewModelScope.launch {
            _isAuditing.value = true
            delay(400) // Visual feedback for smooth UX
            val report = auditEngine.runAudit()
            _auditReport.value = report
            _isAuditing.value = false
        }
    }

    fun inspectTls(host: String, port: Int = 443) {
        viewModelScope.launch {
            _isInspectingTls.value = true
            val result = diagnosticsService.inspectTlsEndpoint(host.trim(), port)
            _tlsInspection.value = result
            _isInspectingTls.value = false
        }
    }

    fun queryDoh(domain: String, useCloudflare: Boolean = true) {
        viewModelScope.launch {
            _isQueryingDoh.value = true
            val result = diagnosticsService.queryDoh(domain.trim(), useCloudflare)
            _dohResult.value = result
            _isQueryingDoh.value = false
        }
    }

    fun refreshNetworkInterfaces() {
        _networkInterfaces.value = diagnosticsService.getNetworkInterfaces()
    }

    override fun onCleared() {
        super.onCleared()
    }
}

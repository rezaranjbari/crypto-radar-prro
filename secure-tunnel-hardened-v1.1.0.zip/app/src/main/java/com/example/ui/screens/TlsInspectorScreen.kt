package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VpnLock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DohQueryResult
import com.example.data.model.NetworkInterfaceInfo
import com.example.data.model.TlsInspectionResult
import com.example.ui.MainViewModel
import com.example.ui.components.CyberBadge
import com.example.ui.components.CyberCard
import com.example.ui.components.MetricBox
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberNavyBackground
import com.example.ui.theme.CyberNavyCard
import com.example.ui.theme.CyberNavySurface
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TlsInspectorScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    var selectedSubTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("TLS Handshake", "DNS-over-HTTPS", "Interfaces")

    val tlsResult by viewModel.tlsInspection.collectAsState()
    val isInspectingTls by viewModel.isInspectingTls.collectAsState()

    val dohResult by viewModel.dohResult.collectAsState()
    val isQueryingDoh by viewModel.isQueryingDoh.collectAsState()

    val interfaces by viewModel.networkInterfaces.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(8.dp))

        // Sub Tabs
        TabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = CyberNavyCard,
            contentColor = NeonCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSubTab]),
                    color = NeonCyan
                )
            },
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .padding(vertical = 4.dp)
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedSubTab == index,
                    onClick = { selectedSubTab = index },
                    text = {
                        Text(
                            text = title,
                            fontSize = 12.sp,
                            fontWeight = if (selectedSubTab == index) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        when (selectedSubTab) {
            0 -> TlsInspectionTab(
                tlsResult = tlsResult,
                isLoading = isInspectingTls,
                onInspect = { host, port -> viewModel.inspectTls(host, port) }
            )
            1 -> DohResolverTab(
                dohResult = dohResult,
                isLoading = isQueryingDoh,
                onQuery = { domain, useCloudflare -> viewModel.queryDoh(domain, useCloudflare) }
            )
            2 -> InterfacesTab(
                interfaces = interfaces,
                onRefresh = { viewModel.refreshNetworkInterfaces() }
            )
        }
    }
}

@Composable
fun TlsInspectionTab(
    tlsResult: TlsInspectionResult?,
    isLoading: Boolean,
    onInspect: (String, Int) -> Unit
) {
    var host by remember { mutableStateOf("cloudflare-dns.com") }
    var port by remember { mutableStateOf("443") }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            CyberCard(backgroundColor = CyberNavyCard) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Real-time Remote TLS Certificate & Cipher Audit",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Connects to endpoint, verifies handshake, extracts certificate chain, and checks cipher suite against Android system trust anchors.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = host,
                            onValueChange = { host = it },
                            label = { Text("Hostname") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = CyberBorder
                            ),
                            modifier = Modifier.weight(2.5f)
                        )
                        OutlinedTextField(
                            value = port,
                            onValueChange = { port = it },
                            label = { Text("Port") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = CyberBorder
                            ),
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Button(
                        onClick = { onInspect(host, port.toIntOrNull() ?: 443) },
                        enabled = !isLoading && host.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonCyan,
                            contentColor = CyberNavyBackground
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("inspect_tls_button")
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = CyberNavyBackground,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Performing TLS Handshake...")
                        } else {
                            Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Inspect TLS Handshake", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (tlsResult != null) {
            item {
                TlsResultCard(tlsResult)
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun TlsResultCard(result: TlsInspectionResult) {
    CyberCard(
        borderColor = if (result.isSuccess) NeonEmerald else NeonRed,
        backgroundColor = CyberNavySurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CyberBadge(
                    text = if (result.isSuccess) "TLS HANDSHAKE VERIFIED" else "HANDSHAKE FAILED",
                    color = if (result.isSuccess) NeonEmerald else NeonRed
                )
                Text(
                    text = "${result.handshakeLatencyMs} ms",
                    color = NeonCyan,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            if (!result.isSuccess) {
                Text(
                    text = "Error: ${result.errorMessage}",
                    color = NeonRed,
                    fontSize = 13.sp
                )
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricBox(
                        title = "Protocol",
                        value = result.tlsVersion,
                        modifier = Modifier.weight(1f),
                        accentColor = NeonEmerald
                    )
                    MetricBox(
                        title = "Resolved IP",
                        value = result.ipAddress,
                        modifier = Modifier.weight(1.5f),
                        accentColor = NeonCyan
                    )
                }

                TlsDetailRow("Cipher Suite", result.cipherSuite)
                TlsDetailRow("Subject DN", result.subjectDN)
                TlsDetailRow("Issuer DN", result.issuerDN)
                TlsDetailRow("Valid Range", "${result.validFrom} to ${result.validUntil}")
                TlsDetailRow("SHA-256 Fingerprint", result.sha256Fingerprint)

                if (result.sanDomains.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "SUBJECT ALTERNATIVE NAMES (SAN):",
                            color = TextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = result.sanDomains.joinToString(", "),
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TlsDetailRow(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(
            text = label.uppercase(),
            color = TextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun DohResolverTab(
    dohResult: DohQueryResult?,
    isLoading: Boolean,
    onQuery: (String, Boolean) -> Unit
) {
    var domain by remember { mutableStateOf("cloudflare.com") }
    var useCloudflare by remember { mutableStateOf(true) }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            CyberCard(backgroundColor = CyberNavyCard) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Encrypted DNS-over-HTTPS (DoH) Resolver",
                        color = TextPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Resolves domain IP addresses over encrypted HTTPS tunnels. Bypasses local ISP DNS hijacking, inspection, and unencrypted port 53 leakage.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    OutlinedTextField(
                        value = domain,
                        onValueChange = { domain = it },
                        label = { Text("Domain Name") },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NeonEmerald,
                            unfocusedBorderColor = CyberBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { useCloudflare = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (useCloudflare) NeonEmerald else CyberNavySurface,
                                contentColor = if (useCloudflare) CyberNavyBackground else TextSecondary
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Cloudflare 1.1.1.1", fontSize = 11.sp)
                        }

                        Button(
                            onClick = { useCloudflare = false },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (!useCloudflare) NeonCyan else CyberNavySurface,
                                contentColor = if (!useCloudflare) CyberNavyBackground else TextSecondary
                            ),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Google 8.8.8.8", fontSize = 11.sp)
                        }
                    }

                    Button(
                        onClick = { onQuery(domain, useCloudflare) },
                        enabled = !isLoading && domain.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonEmerald,
                            contentColor = CyberNavyBackground
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("resolve_doh_button")
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = CyberNavyBackground,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Resolving via DoH...")
                        } else {
                            Icon(Icons.Default.Dns, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Resolve via Encrypted DoH", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        if (dohResult != null) {
            item {
                CyberCard(
                    borderColor = if (dohResult.isSuccess) NeonEmerald else NeonRed,
                    backgroundColor = CyberNavySurface
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CyberBadge(
                                text = "${dohResult.provider} • SECURE",
                                color = NeonEmerald
                            )
                            Text(
                                text = "${dohResult.latencyMs} ms",
                                color = NeonCyan,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Text(
                            text = "Query: ${dohResult.domain}",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )

                        if (!dohResult.isSuccess) {
                            Text(
                                text = "Query Error: ${dohResult.errorMessage}",
                                color = NeonRed,
                                fontSize = 12.sp
                            )
                        } else {
                            Text(
                                text = "RESOLVED A RECORDS (IPv4):",
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )

                            dohResult.ipAddresses.forEach { ip ->
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = CyberNavyBackground,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Default.Lan, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(16.dp))
                                        Text(
                                            text = ip,
                                            color = TextPrimary,
                                            fontSize = 13.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun InterfacesTab(
    interfaces: List<NetworkInterfaceInfo>,
    onRefresh: () -> Unit
) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${interfaces.size} Network Interfaces Detected",
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
                Button(
                    onClick = onRefresh,
                    colors = ButtonDefaults.buttonColors(containerColor = CyberNavyCard, contentColor = NeonCyan)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Refresh")
                }
            }
        }

        items(interfaces, key = { it.name }) { iface ->
            CyberCard(
                borderColor = if (iface.isVpn) NeonCyan else CyberBorder,
                backgroundColor = CyberNavySurface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = iface.name,
                                color = TextPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            if (iface.isVpn) {
                                CyberBadge(text = "TUNNEL / VPN", color = NeonCyan)
                            }
                            if (iface.isUp) {
                                CyberBadge(text = "UP", color = NeonEmerald)
                            }
                        }
                        Text(
                            text = "MTU: ${iface.mtu}",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    if (iface.ipv4Addresses.isNotEmpty()) {
                        Text(
                            text = "IPv4: ${iface.ipv4Addresses.joinToString(", ")}",
                            color = NeonEmerald,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    if (iface.ipv6Addresses.isNotEmpty()) {
                        Text(
                            text = "IPv6: ${iface.ipv6Addresses.firstOrNull() ?: ""}",
                            color = TextMuted,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

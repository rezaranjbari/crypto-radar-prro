package com.example.data.model

enum class AuditStatus {
    SECURE,
    WARNING,
    INSECURE
}

enum class AuditCategory(val title: String) {
    NETWORK("Network & TLS"),
    STORAGE("Storage & Backup"),
    COMPONENTS("App Components & Permissions"),
    TELEMETRY("Telemetry & Privacy"),
    BUILD_SYSTEM("Build & R8 Hardening")
}

data class AuditCheckItem(
    val id: String,
    val title: String,
    val category: AuditCategory,
    val status: AuditStatus,
    val summary: String,
    val technicalDetails: String,
    val workflowStep: Int,
    val recommendation: String? = null
)

data class FullAuditReport(
    val timestamp: Long = System.currentTimeMillis(),
    val totalScore: Int, // 0 - 100
    val secureCount: Int,
    val warningCount: Int,
    val insecureCount: Int,
    val items: List<AuditCheckItem>,
    val rawReportText: String
)

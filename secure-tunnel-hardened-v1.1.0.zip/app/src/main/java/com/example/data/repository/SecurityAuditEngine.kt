package com.example.data.repository

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.security.NetworkSecurityPolicy
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SecurityAuditEngine(private val context: Context) {
    suspend fun runAudit(): FullAuditReport = withContext(Dispatchers.Default) {
        val items = mutableListOf<AuditCheckItem>()
        val appInfo = context.applicationInfo
        val cleartext = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) NetworkSecurityPolicy.getInstance().isCleartextTrafficPermitted else false
        items += AuditCheckItem("cleartext", "Cleartext network traffic", AuditCategory.NETWORK,
            if (!cleartext) AuditStatus.SECURE else AuditStatus.INSECURE,
            if (!cleartext) "Blocked by Android network policy" else "Cleartext traffic is permitted",
            "NetworkSecurityConfig and usesCleartextTraffic are intended to reject plaintext HTTP.", 5,
            if (cleartext) "Keep cleartextTrafficPermitted=false and usesCleartextTraffic=false." else null)

        val backup = (appInfo.flags and ApplicationInfo.FLAG_ALLOW_BACKUP) != 0
        items += AuditCheckItem("backup", "Backup and device transfer", AuditCategory.STORAGE,
            if (!backup) AuditStatus.SECURE else AuditStatus.WARNING,
            if (!backup) "Application backup disabled" else "Backup flag is enabled",
            "Sensitive tunnel profiles are stored in an Android Keystore encrypted blob. Backup rules also exclude application root data.", 6,
            if (backup) "Disable android:allowBackup." else null)

        val netSec = context.resources.getIdentifier("network_security_config", "xml", context.packageName) != 0
        items += AuditCheckItem("netsec", "System CA trust policy", AuditCategory.NETWORK,
            if (netSec) AuditStatus.SECURE else AuditStatus.WARNING,
            if (netSec) "Explicit network security configuration present" else "Custom network security configuration missing",
            "The app uses Android system trust anchors and disables cleartext traffic.", 7,
            if (!netSec) "Restore network_security_config.xml." else null)

        val extraction = context.resources.getIdentifier("data_extraction_rules", "xml", context.packageName) != 0
        items += AuditCheckItem("extraction", "Backup extraction rules", AuditCategory.STORAGE,
            if (extraction) AuditStatus.SECURE else AuditStatus.WARNING,
            if (extraction) "Cloud backup and device-transfer exclusions present" else "Extraction rules missing",
            "Application root data is excluded from cloud backup and device transfer.", 8)

        val debug = (appInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        items += AuditCheckItem("debug", "Debuggable build", AuditCategory.BUILD_SYSTEM,
            if (!debug) AuditStatus.SECURE else AuditStatus.WARNING,
            if (!debug) "Debugging disabled" else "This APK is debuggable",
            "FLAG_DEBUGGABLE is the runtime signal; use a release build for final distribution.", 9,
            if (debug) "Build assembleRelease for the final APK." else null)

        items += AuditCheckItem("r8", "R8 release hardening", AuditCategory.BUILD_SYSTEM,
            AuditStatus.WARNING,
            "Configured in Gradle; final APK must be verified by CI",
            "Runtime code cannot prove whether R8 ran. CI should build release with minification and resource shrinking enabled.", 10,
            "Use the included GitHub Actions workflow and inspect the release artifact.")

        val requested = packagePermissions()
        val sensitive = requested.filter { it in setOf(
            "android.permission.CAMERA", "android.permission.RECORD_AUDIO", "android.permission.READ_CONTACTS",
            "android.permission.WRITE_CONTACTS", "android.permission.READ_SMS", "android.permission.SEND_SMS",
            "android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION",
            "android.permission.QUERY_ALL_PACKAGES"
        ) }
        items += AuditCheckItem("permissions", "Least-privilege permissions", AuditCategory.COMPONENTS,
            if (sensitive.isEmpty()) AuditStatus.SECURE else AuditStatus.INSECURE,
            if (sensitive.isEmpty()) "No unrelated dangerous permissions" else "Sensitive permissions detected",
            "Requested permissions: ${requested.joinToString().ifBlank { "none" }}", 11,
            if (sensitive.isNotEmpty()) "Remove permissions not required for VPN operation." else null)

        val components = packageComponents()
        val exportedNonLauncher = components.filter { it.exported && !it.name.endsWith("MainActivity") }
        items += AuditCheckItem("components", "Exported component surface", AuditCategory.COMPONENTS,
            if (exportedNonLauncher.isEmpty()) AuditStatus.SECURE else AuditStatus.WARNING,
            if (exportedNonLauncher.isEmpty()) "No unintended exported components" else "Review exported components",
            "Exported non-launcher components: ${exportedNonLauncher.map { it.name }.joinToString().ifBlank { "none" }}", 12)

        val trackerClasses = listOf("com.google.firebase.analytics.FirebaseAnalytics", "com.google.firebase.crashlytics.FirebaseCrashlytics", "io.sentry.Sentry", "com.amplitude.api.Amplitude", "com.mixpanel.android.mpmetrics.MixpanelAPI")
        val trackers = trackerClasses.filter { runCatching { Class.forName(it) }.isSuccess }
        items += AuditCheckItem("telemetry", "Telemetry SDK presence", AuditCategory.TELEMETRY,
            if (trackers.isEmpty()) AuditStatus.SECURE else AuditStatus.INSECURE,
            if (trackers.isEmpty()) "No known analytics SDK classes detected" else "Tracking SDK classes detected",
            "Known tracker classes found: ${trackers.joinToString().ifBlank { "none" }}", 13,
            if (trackers.isNotEmpty()) "Remove analytics/crash-reporting SDKs unless explicitly required." else null)

        items += AuditCheckItem("tls", "TLS endpoint policy", AuditCategory.NETWORK, AuditStatus.SECURE,
            "Diagnostics use hostname verification and system trust", "TLS diagnostics enable HTTPS endpoint identification and use the platform trust manager.", 14)

        items += AuditCheckItem("secrets", "Profile secret storage", AuditCategory.STORAGE, AuditStatus.SECURE,
            "Tunnel profiles are encrypted with Android Keystore-backed AES-GCM", "Credentials are no longer stored as plaintext JSON in SharedPreferences. Legacy plaintext storage is migrated and removed when possible.", 15)

        val vpnSupported = runCatching { VpnService.prepare(context) != null || VpnService::class.java.isAssignableFrom(VpnService::class.java) }.getOrDefault(false)
        items += AuditCheckItem("vpn_service", "Android VPN service", AuditCategory.NETWORK,
            if (vpnSupported) AuditStatus.SECURE else AuditStatus.WARNING,
            "VPNService component is declared", "The app refuses to fake a connected state. A protocol engine must be attached before routing traffic.", 18,
            "Do not enable a default route until a real protocol engine forwards TUN packets.")

        val secure = items.count { it.status == AuditStatus.SECURE }
        val warning = items.count { it.status == AuditStatus.WARNING }
        val insecure = items.count { it.status == AuditStatus.INSECURE }
        val score = ((secure * 100) + (warning * 60)) / items.size.coerceAtLeast(1)
        val date = SimpleDateFormat("yyyy-MM-dd HH:mm:ss z", Locale.US).format(Date())
        val raw = buildString {
            appendLine("Secure Tunnel Security Audit")
            appendLine("Generated: $date")
            appendLine("Package: ${context.packageName}")
            appendLine("Score: $score/100")
            appendLine()
            items.forEach { appendLine("[${it.status}] ${it.title}: ${it.summary}") }
            appendLine()
            appendLine("Important: this audit does not prove the security of a remote VPN server or a future protocol engine.")
            appendLine("The current source deliberately does not claim an active tunnel without a real engine.")
        }
        FullAuditReport(dateToLong(), score, secure, warning, insecure, items, raw)
    }

    private fun dateToLong() = System.currentTimeMillis()

    private fun packagePermissions(): List<String> = runCatching {
        val info = if (Build.VERSION.SDK_INT >= 33) context.packageManager.getPackageInfo(context.packageName, PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
        else @Suppress("DEPRECATION") context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_PERMISSIONS)
        info.requestedPermissions?.toList().orEmpty()
    }.getOrDefault(emptyList())

    private fun packageComponents(): List<android.content.pm.ComponentInfo> = runCatching {
        val info = if (Build.VERSION.SDK_INT >= 33) context.packageManager.getPackageInfo(context.packageName, PackageManager.PackageInfoFlags.of((PackageManager.GET_ACTIVITIES or PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS).toLong()))
        else @Suppress("DEPRECATION") context.packageManager.getPackageInfo(context.packageName, PackageManager.GET_ACTIVITIES or PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS)
        buildList {
            addAll(info.activities.orEmpty())
            addAll(info.services.orEmpty())
            addAll(info.receivers.orEmpty())
        }
    }.getOrDefault(emptyList())
}

package com.example.data.model

import java.net.URI
import java.net.URLDecoder
import java.util.UUID
import org.json.JSONObject

enum class TunnelProtocol(val displayName: String, val defaultPort: Int) {
    VLESS("VLESS", 443),
    VMESS("VMess", 443),
    SHADOWSOCKS("Shadowsocks", 8388),
    TROJAN("Trojan", 443),
    SOCKS5("SOCKS5", 1080),
    WIREGUARD("WireGuard", 51820)
}

enum class PingStatus {
    IDLE,
    PROBING,
    REACHABLE,
    UNREACHABLE
}

data class TunnelProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val protocol: TunnelProtocol,
    val server: String,
    val port: Int,
    val secret: String, // Password or UUID
    val cipher: String = "chacha20-poly1305",
    val tlsEnabled: Boolean = true,
    val sni: String = "",
    val alpn: String = "h2,http/1.1",
    val allowInsecure: Boolean = false, // Hardened builds enforce false
    val fingerprint: String = "chrome",
    val latencyMs: Long? = null,
    val pingStatus: PingStatus = PingStatus.IDLE,
    val lastPingError: String? = null
) {
    fun toShareableUri(): String {
        return when (protocol) {
            TunnelProtocol.VLESS -> {
                val encName = java.net.URLEncoder.encode(name, "UTF-8")
                val sniParam = if (sni.isNotBlank()) "&sni=${java.net.URLEncoder.encode(sni, "UTF-8")}" else ""
                val alpnParam = java.net.URLEncoder.encode(alpn, "UTF-8")
                "vless://${java.net.URLEncoder.encode(secret, "UTF-8")}@$server:$port?security=${if (tlsEnabled) "tls" else "none"}&fp=${java.net.URLEncoder.encode(fingerprint, "UTF-8")}&alpn=$alpnParam$sniParam#$encName"
            }
            TunnelProtocol.TROJAN -> {
                val encName = java.net.URLEncoder.encode(name, "UTF-8")
                val sniParam = if (sni.isNotBlank()) "?sni=${java.net.URLEncoder.encode(sni, "UTF-8")}" else ""
                "trojan://${java.net.URLEncoder.encode(secret, "UTF-8")}@$server:$port$sniParam#$encName"
            }
            TunnelProtocol.SHADOWSOCKS -> {
                val encName = java.net.URLEncoder.encode(name, "UTF-8")
                val userPass = "$cipher:$secret"
                val b64 = android.util.Base64.encodeToString(userPass.toByteArray(), android.util.Base64.NO_WRAP)
                "ss://$b64@$server:$port#$encName"
            }
            TunnelProtocol.SOCKS5 -> {
                val encName = java.net.URLEncoder.encode(name, "UTF-8")
                val auth = if (secret.isNotBlank()) "$secret@" else ""
                "socks5://$auth$server:$port#$encName"
            }
            TunnelProtocol.WIREGUARD -> {
                val encName = java.net.URLEncoder.encode(name, "UTF-8")
                "wireguard://$server:$port?pubkey=$secret#$encName"
            }
            TunnelProtocol.VMESS -> {
                val encName = java.net.URLEncoder.encode(name, "UTF-8")
                "vmess://$secret@$server:$port#$encName"
            }
        }
    }

    companion object {
        fun parseUri(rawUri: String): TunnelProfile? {
            val trimmed = rawUri.trim()
            return try {
                when {
                    trimmed.startsWith("vless://", ignoreCase = true) -> parseVless(trimmed)
                    trimmed.startsWith("trojan://", ignoreCase = true) -> parseTrojan(trimmed)
                    trimmed.startsWith("ss://", ignoreCase = true) -> parseShadowsocks(trimmed)
                    trimmed.startsWith("socks5://", ignoreCase = true) -> parseSocks5(trimmed)
                    trimmed.startsWith("vmess://", ignoreCase = true) -> parseVmess(trimmed)
                    trimmed.startsWith("wireguard://", ignoreCase = true) -> parseWireGuard(trimmed)
                    else -> null
                }
            } catch (_: Exception) {
                null
            }
        }

        private fun parseVless(uriStr: String): TunnelProfile {
            val uri = URI(uriStr)
            val name = uri.fragment?.let { URLDecoder.decode(it, "UTF-8") } ?: "Imported VLESS"
            val secret = uri.userInfo ?: UUID.randomUUID().toString()
            val host = uri.host ?: "127.0.0.1"
            val port = if (uri.port > 0) uri.port else 443

            var sni = ""
            var alpn = "h2,http/1.1"
            var fp = "chrome"
            var tls = true

            uri.query?.split("&")?.forEach { param ->
                val parts = param.split("=", limit = 2)
                if (parts.size == 2) {
                    when (parts[0].lowercase()) {
                        "sni" -> sni = URLDecoder.decode(parts[1], "UTF-8")
                        "alpn" -> alpn = URLDecoder.decode(parts[1], "UTF-8")
                        "fp" -> fp = parts[1]
                        "security" -> tls = parts[1].equals("tls", ignoreCase = true)
                    }
                }
            }

            return TunnelProfile(
                name = name,
                protocol = TunnelProtocol.VLESS,
                server = host,
                port = port,
                secret = secret,
                cipher = "none",
                tlsEnabled = tls,
                sni = sni.ifBlank { host },
                alpn = alpn,
                fingerprint = fp,
                allowInsecure = false
            )
        }

        private fun parseTrojan(uriStr: String): TunnelProfile {
            val uri = URI(uriStr)
            val name = uri.fragment?.let { URLDecoder.decode(it, "UTF-8") } ?: "Imported Trojan"
            val secret = uri.userInfo ?: ""
            val host = uri.host ?: "127.0.0.1"
            val port = if (uri.port > 0) uri.port else 443

            var sni = host
            uri.query?.split("&")?.forEach { param ->
                val parts = param.split("=", limit = 2)
                if (parts.size == 2 && parts[0].equals("sni", ignoreCase = true)) {
                    sni = URLDecoder.decode(parts[1], "UTF-8")
                }
            }

            return TunnelProfile(
                name = name,
                protocol = TunnelProtocol.TROJAN,
                server = host,
                port = port,
                secret = secret,
                cipher = "chacha20-poly1305",
                tlsEnabled = true,
                sni = sni,
                allowInsecure = false
            )
        }

        private fun parseShadowsocks(uriStr: String): TunnelProfile {
            val uri = URI(uriStr)
            val name = uri.fragment?.let { URLDecoder.decode(it, "UTF-8") } ?: "Imported SS"
            val host = uri.host ?: "127.0.0.1"
            val port = if (uri.port > 0) uri.port else 8388
            var cipher = "chacha20-poly1305"
            var secret = "secret"

            uri.userInfo?.let { rawUser ->
                try {
                    val decoded = String(android.util.Base64.decode(rawUser, android.util.Base64.NO_WRAP))
                    val parts = decoded.split(":", limit = 2)
                    if (parts.size == 2) {
                        cipher = parts[0]
                        secret = parts[1]
                    }
                } catch (_: Exception) {
                    secret = rawUser
                }
            }

            return TunnelProfile(
                name = name,
                protocol = TunnelProtocol.SHADOWSOCKS,
                server = host,
                port = port,
                secret = secret,
                cipher = cipher,
                tlsEnabled = false,
                allowInsecure = false
            )
        }

        private fun parseVmess(uriStr: String): TunnelProfile {
            val raw = uriStr.removePrefix("vmess://")
            val decoded = try { String(android.util.Base64.decode(raw.substringBefore('#'), android.util.Base64.DEFAULT)) } catch (_: Exception) { "" }
            val obj = JSONObject(decoded)
            val host = obj.optString("add").ifBlank { obj.optString("host") }
            val port = obj.optString("port").toIntOrNull() ?: 443
            val id = obj.optString("id")
            val name = obj.optString("ps").ifBlank { uriStr.substringAfter('#', "Imported VMess") }
            val tls = obj.optString("tls").equals("tls", true)
            return TunnelProfile(name = name, protocol = TunnelProtocol.VMESS, server = host, port = port, secret = id,
                cipher = obj.optString("scy", "auto"), tlsEnabled = tls, sni = obj.optString("sni", host),
                alpn = obj.optString("alpn", "h2,http/1.1"), fingerprint = "chrome", allowInsecure = false)
        }

        private fun parseWireGuard(uriStr: String): TunnelProfile {
            val uri = URI(uriStr)
            val name = uri.fragment?.let { URLDecoder.decode(it, "UTF-8") } ?: "Imported WireGuard"
            val host = uri.host ?: ""
            val port = if (uri.port > 0) uri.port else 51820
            val publicKey = uri.query?.split('&')?.map { it.split('=', limit = 2) }?.firstOrNull { it[0].equals("pubkey", true) }?.getOrNull(1) ?: uri.userInfo.orEmpty()
            return TunnelProfile(name = name, protocol = TunnelProtocol.WIREGUARD, server = host, port = port, secret = URLDecoder.decode(publicKey, "UTF-8"),
                cipher = "wireguard", tlsEnabled = false, sni = "", alpn = "", allowInsecure = false)
        }

        private fun parseSocks5(uriStr: String): TunnelProfile {
            val uri = URI(uriStr)
            val name = uri.fragment?.let { URLDecoder.decode(it, "UTF-8") } ?: "Imported SOCKS5"
            val host = uri.host ?: "127.0.0.1"
            val port = if (uri.port > 0) uri.port else 1080
            val secret = uri.userInfo ?: ""

            return TunnelProfile(
                name = name,
                protocol = TunnelProtocol.SOCKS5,
                server = host,
                port = port,
                secret = secret,
                cipher = "none",
                tlsEnabled = false,
                allowInsecure = false
            )
        }
    }
}

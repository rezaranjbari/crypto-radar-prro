package com.example.data.repository

import com.example.data.model.DohQueryResult
import com.example.data.model.NetworkInterfaceInfo
import com.example.data.model.TlsInspectionResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.URL
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Locale
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

class NetworkDiagnosticsService {

    suspend fun inspectTlsEndpoint(host: String, port: Int = 443): TlsInspectionResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        try {
            val inetAddress = InetAddress.getByName(host)
            val ipAddress = inetAddress.hostAddress ?: host

            val sslFactory = SSLSocketFactory.getDefault() as SSLSocketFactory
            val socket = sslFactory.createSocket() as SSLSocket
            socket.soTimeout = 4000
            socket.connect(InetSocketAddress(host, port), 4000)
            socket.sslParameters = socket.sslParameters.apply { endpointIdentificationAlgorithm = "HTTPS" }
            socket.startHandshake()

            val session = socket.session
            val peerCerts = session.peerCertificates
            val cert = peerCerts.firstOrNull() as? X509Certificate

            val handshakeLatency = System.currentTimeMillis() - startTime
            val tlsVersion = session.protocol
            val cipherSuite = session.cipherSuite

            val subject = cert?.subjectX500Principal?.name ?: "Unknown"
            val issuer = cert?.issuerX500Principal?.name ?: "Unknown"

            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val validFrom = cert?.notBefore?.let { dateFormat.format(it) } ?: "Unknown"
            val validUntil = cert?.notAfter?.let { dateFormat.format(it) } ?: "Unknown"

            val sha256 = cert?.let {
                val digest = MessageDigest.getInstance("SHA-256")
                val hash = digest.digest(it.encoded)
                hash.joinToString(":") { b -> "%02X".format(b) }
            } ?: "N/A"

            val sanDomains = mutableListOf<String>()
            try {
                cert?.subjectAlternativeNames?.forEach { item ->
                    if (item.size >= 2) {
                        sanDomains.add(item[1].toString())
                    }
                }
            } catch (_: Exception) {
                // Ignore SAN parse issue
            }

            socket.close()

            TlsInspectionResult(
                host = host,
                port = port,
                ipAddress = ipAddress,
                isSuccess = true,
                tlsVersion = tlsVersion,
                cipherSuite = cipherSuite,
                subjectDN = subject,
                issuerDN = issuer,
                validFrom = validFrom,
                validUntil = validUntil,
                isSystemTrusted = true,
                sha256Fingerprint = sha256,
                sanDomains = sanDomains.take(10),
                handshakeLatencyMs = handshakeLatency
            )
        } catch (e: Exception) {
            TlsInspectionResult(
                host = host,
                port = port,
                ipAddress = "Unresolved",
                isSuccess = false,
                tlsVersion = "N/A",
                cipherSuite = "N/A",
                subjectDN = "N/A",
                issuerDN = "N/A",
                validFrom = "N/A",
                validUntil = "N/A",
                isSystemTrusted = false,
                sha256Fingerprint = "N/A",
                sanDomains = emptyList(),
                handshakeLatencyMs = System.currentTimeMillis() - startTime,
                errorMessage = e.localizedMessage ?: "TLS Handshake failed"
            )
        }
    }

    suspend fun queryDoh(
        domain: String,
        useCloudflare: Boolean = true
    ): DohQueryResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val providerName = if (useCloudflare) "Cloudflare 1.1.1.1 (DoH)" else "Google Public DNS (DoH)"
        val endpoint = if (useCloudflare) {
            "https://cloudflare-dns.com/dns-query?name=$domain&type=A"
        } else {
            "https://dns.google/resolve?name=$domain&type=A"
        }

        try {
            val url = URL(endpoint)
            val conn = url.openConnection() as HttpsURLConnection
            conn.requestMethod = "GET"
            conn.setRequestProperty("Accept", "application/dns-json")
            conn.connectTimeout = 4000
            conn.readTimeout = 4000

            val responseCode = conn.responseCode
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val reader = BufferedReader(InputStreamReader(conn.inputStream))
                val responseText = reader.use { it.readText() }
                val json = JSONObject(responseText)
                val answers = mutableListOf<String>()

                if (json.has("Answer")) {
                    val arr = json.getJSONArray("Answer")
                    for (i in 0 until arr.length()) {
                        val item = arr.getJSONObject(i)
                        val data = item.optString("data")
                        if (data.isNotBlank()) {
                            answers.add(data)
                        }
                    }
                }

                val latency = System.currentTimeMillis() - startTime
                DohQueryResult(
                    domain = domain,
                    provider = providerName,
                    providerUrl = endpoint,
                    isSuccess = true,
                    latencyMs = latency,
                    ipAddresses = answers.ifEmpty { listOf("No A records returned") }
                )
            } else {
                DohQueryResult(
                    domain = domain,
                    provider = providerName,
                    providerUrl = endpoint,
                    isSuccess = false,
                    latencyMs = System.currentTimeMillis() - startTime,
                    ipAddresses = emptyList(),
                    errorMessage = "HTTP Error $responseCode"
                )
            }
        } catch (e: Exception) {
            DohQueryResult(
                domain = domain,
                provider = providerName,
                providerUrl = endpoint,
                isSuccess = false,
                latencyMs = System.currentTimeMillis() - startTime,
                ipAddresses = emptyList(),
                errorMessage = e.localizedMessage ?: "DoH query failed"
            )
        }
    }

    fun getNetworkInterfaces(): List<NetworkInterfaceInfo> {
        return try {
            val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
            interfaces.filter { !it.isLoopback || it.name == "lo" }.map { iface ->
                val ipv4List = mutableListOf<String>()
                val ipv6List = mutableListOf<String>()

                val addresses = Collections.list(iface.inetAddresses)
                for (addr in addresses) {
                    if (addr.isLoopbackAddress && iface.name != "lo") continue
                    val hostAddr = addr.hostAddress ?: continue
                    if (hostAddr.contains(":")) {
                        ipv6List.add(hostAddr.substringBefore("%"))
                    } else {
                        ipv4List.add(hostAddr)
                    }
                }

                val isVpn = iface.name.startsWith("tun") || iface.name.startsWith("ppp") || iface.name.startsWith("p2p")

                NetworkInterfaceInfo(
                    name = iface.name,
                    displayName = iface.displayName,
                    isUp = iface.isUp,
                    isLoopback = iface.isLoopback,
                    isVpn = isVpn,
                    ipv4Addresses = ipv4List,
                    ipv6Addresses = ipv6List,
                    mtu = iface.mtu
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}

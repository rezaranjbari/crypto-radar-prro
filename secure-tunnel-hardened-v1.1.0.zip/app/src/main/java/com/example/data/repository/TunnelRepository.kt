package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.net.VpnService
import com.example.data.model.PingStatus
import com.example.data.model.TunnelProfile
import com.example.data.model.TunnelProtocol
import com.example.security.SecureProfileStore
import com.example.vpn.SecureTunnelVpnService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetSocketAddress
import java.net.Socket
import javax.net.ssl.SSLParameters
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

class TunnelRepository(private val context: Context) {
    private val store = SecureProfileStore(context)
    private val legacyPrefs = context.getSharedPreferences("secure_tunnel_prefs", Context.MODE_PRIVATE)

    private val _profiles = MutableStateFlow<List<TunnelProfile>>(emptyList())
    val profiles: StateFlow<List<TunnelProfile>> = _profiles.asStateFlow()
    private val _activeProfileId = MutableStateFlow<String?>(null)
    val activeProfileId: StateFlow<String?> = _activeProfileId.asStateFlow()
    private val _isTunnelConnected = MutableStateFlow(false)
    val isTunnelConnected: StateFlow<Boolean> = _isTunnelConnected.asStateFlow()
    private val _isConnecting = MutableStateFlow(false)
    val isConnecting: StateFlow<Boolean> = _isConnecting.asStateFlow()
    private val _killSwitchEnabled = MutableStateFlow(true)
    val killSwitchEnabled: StateFlow<Boolean> = _killSwitchEnabled.asStateFlow()
    private val _bytesUploaded = MutableStateFlow(0L)
    val bytesUploaded: StateFlow<Long> = _bytesUploaded.asStateFlow()
    private val _bytesDownloaded = MutableStateFlow(0L)
    val bytesDownloaded: StateFlow<Long> = _bytesDownloaded.asStateFlow()
    private val _connectionDurationSec = MutableStateFlow(0L)
    val connectionDurationSec: StateFlow<Long> = _connectionDurationSec.asStateFlow()
    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    init { loadProfiles() }

    private fun loadProfiles() {
        val encrypted = store.get(PROFILES_KEY)
        val legacy = legacyPrefs.getString("saved_profiles", null)
        val source = encrypted ?: legacy
        val parsed = parseProfiles(source)
        if (parsed.isNotEmpty()) {
            _profiles.value = parsed
            _activeProfileId.value = store.get(ACTIVE_KEY)?.takeIf { id -> parsed.any { it.id == id } } ?: parsed.first().id
            if (encrypted == null) saveProfiles()
            if (legacy != null) legacyPrefs.edit().remove("saved_profiles").apply()
        } else {
            _profiles.value = emptyList()
            _activeProfileId.value = null
        }
        _killSwitchEnabled.value = store.get(KILL_SWITCH_KEY)?.toBooleanStrictOrNull() ?: true
    }

    private fun parseProfiles(json: String?): List<TunnelProfile> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val array = JSONArray(json)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    add(TunnelProfile(
                        id = obj.getString("id"), name = obj.getString("name"),
                        protocol = TunnelProtocol.valueOf(obj.getString("protocol")),
                        server = obj.getString("server"), port = obj.getInt("port"),
                        secret = obj.optString("secret", ""), cipher = obj.optString("cipher", "chacha20-poly1305"),
                        tlsEnabled = obj.optBoolean("tlsEnabled", true), sni = obj.optString("sni", ""),
                        alpn = obj.optString("alpn", "h2,http/1.1"), allowInsecure = false,
                        fingerprint = obj.optString("fingerprint", "chrome")
                    ))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun saveProfiles() {
        val array = JSONArray()
        _profiles.value.forEach { p ->
            array.put(JSONObject().apply {
                put("id", p.id); put("name", p.name); put("protocol", p.protocol.name)
                put("server", p.server); put("port", p.port); put("secret", p.secret)
                put("cipher", p.cipher); put("tlsEnabled", p.tlsEnabled); put("sni", p.sni)
                put("alpn", p.alpn); put("allowInsecure", false); put("fingerprint", p.fingerprint)
            })
        }
        store.put(PROFILES_KEY, array.toString())
        _activeProfileId.value?.let { store.put(ACTIVE_KEY, it) }
    }

    fun addProfile(profile: TunnelProfile) {
        require(profile.server.isNotBlank()) { "Server is required" }
        require(profile.port in 1..65535) { "Port is invalid" }
        require(profile.secret.isNotBlank() || profile.protocol == TunnelProtocol.SOCKS5) { "Credential is required" }
        _profiles.value = _profiles.value + profile.copy(allowInsecure = false)
        if (_activeProfileId.value == null) _activeProfileId.value = profile.id
        saveProfiles()
    }

    fun updateProfile(profile: TunnelProfile) {
        _profiles.value = _profiles.value.map { if (it.id == profile.id) profile.copy(allowInsecure = false) else it }
        saveProfiles()
    }

    fun deleteProfile(id: String) {
        if (_isTunnelConnected.value) disconnectTunnel()
        _profiles.value = _profiles.value.filterNot { it.id == id }
        if (_activeProfileId.value == id) _activeProfileId.value = _profiles.value.firstOrNull()?.id
        saveProfiles()
    }

    fun selectProfile(id: String) {
        if (_profiles.value.any { it.id == id }) {
            _activeProfileId.value = id
            store.put(ACTIVE_KEY, id)
        }
    }

    fun setKillSwitch(enabled: Boolean) {
        _killSwitchEnabled.value = enabled
        store.put(KILL_SWITCH_KEY, enabled.toString())
        _statusMessage.value = if (enabled) {
            "Kill switch preference enabled. Android's ‘Block connections without VPN’ must also be enabled in system VPN settings for OS-level enforcement."
        } else "Kill switch disabled."
    }

    fun connectTunnel(): Boolean {
        if (_profiles.value.isEmpty()) {
            _statusMessage.value = "No tunnel profile is configured. Import a real server profile first."
            return false
        }
        if (VpnService.prepare(context) != null) {
            _statusMessage.value = "Android VPN permission is required. Approve it, then press Connect again."
            return false
        }
        // No real protocol engine is bundled in this source-only build. Never fake connectivity.
        _statusMessage.value = "Connection blocked safely: a real VLESS/VMess/Trojan/SS/WireGuard engine is not bundled yet. No traffic is redirected."
        return false
    }

    fun disconnectTunnel() {
        context.startService(Intent(context, SecureTunnelVpnService::class.java).setAction(SecureTunnelVpnService.ACTION_STOP))
        _isTunnelConnected.value = false
        _isConnecting.value = false
        _bytesUploaded.value = 0L; _bytesDownloaded.value = 0L; _connectionDurationSec.value = 0L
    }

    fun updateMetrics(uploadDelta: Long, downloadDelta: Long, tickSec: Long = 1) {
        if (_isTunnelConnected.value) {
            _bytesUploaded.value += uploadDelta.coerceAtLeast(0)
            _bytesDownloaded.value += downloadDelta.coerceAtLeast(0)
            _connectionDurationSec.value += tickSec.coerceAtLeast(0)
        }
    }

    suspend fun pingProfile(profileId: String): Long? = withContext(Dispatchers.IO) {
        val profile = _profiles.value.find { it.id == profileId } ?: return@withContext null
        updateProfilePingStatus(profileId, PingStatus.PROBING, null, null)
        val start = System.currentTimeMillis()
        try {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(profile.server, profile.port), 3500)
                if (profile.tlsEnabled) {
                    val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory).createSocket(
                        socket, profile.sni.ifBlank { profile.server }, profile.port, true
                    ) as SSLSocket
                    ssl.soTimeout = 4000
                    ssl.sslParameters = ssl.sslParameters.apply { endpointIdentificationAlgorithm = "HTTPS" }
                    ssl.startHandshake()
                    ssl.close()
                }
            }
            val latency = System.currentTimeMillis() - start
            updateProfilePingStatus(profileId, PingStatus.REACHABLE, latency, null)
            latency
        } catch (e: Exception) {
            updateProfilePingStatus(profileId, PingStatus.UNREACHABLE, null, e.localizedMessage ?: "Connection failed")
            null
        }
    }

    suspend fun pingAllProfiles() = withContext(Dispatchers.IO) { _profiles.value.forEach { pingProfile(it.id) } }

    private fun updateProfilePingStatus(id: String, status: PingStatus, latency: Long?, error: String?) {
        _profiles.value = _profiles.value.map {
            if (it.id == id) it.copy(pingStatus = status, latencyMs = latency, lastPingError = error) else it
        }
    }

    fun clearStatus() { _statusMessage.value = null }

    companion object {
        private const val PROFILES_KEY = "encrypted_profiles_v2"
        private const val ACTIVE_KEY = "active_profile_v2"
        private const val KILL_SWITCH_KEY = "kill_switch_v2"
    }
}

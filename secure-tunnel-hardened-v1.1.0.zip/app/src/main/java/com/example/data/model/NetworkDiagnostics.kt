package com.example.data.model

data class TlsInspectionResult(
    val host: String,
    val port: Int,
    val ipAddress: String,
    val isSuccess: Boolean,
    val tlsVersion: String,
    val cipherSuite: String,
    val subjectDN: String,
    val issuerDN: String,
    val validFrom: String,
    val validUntil: String,
    val isSystemTrusted: Boolean,
    val sha256Fingerprint: String,
    val sanDomains: List<String>,
    val handshakeLatencyMs: Long,
    val errorMessage: String? = null
)

data class DohQueryResult(
    val domain: String,
    val provider: String,
    val providerUrl: String,
    val isSuccess: Boolean,
    val latencyMs: Long,
    val ipAddresses: List<String>,
    val ttl: Int = 300,
    val errorMessage: String? = null
)

data class NetworkInterfaceInfo(
    val name: String,
    val displayName: String,
    val isUp: Boolean,
    val isLoopback: Boolean,
    val isVpn: Boolean,
    val ipv4Addresses: List<String>,
    val ipv6Addresses: List<String>,
    val mtu: Int
)

# Secure Tunnel — Personal Hardened Android Build

این پروژه برای استفاده شخصی و با تمرکز روی کمینه‌کردن سطح حمله بازسازی شده است.

## وضعیت مهم

این پروژه **عمداً وانمود نمی‌کند که VPN متصل است**. `VpnService` در پروژه ثبت شده، اما تا وقتی یک موتور واقعی VLESS/VMess/Trojan/Shadowsocks/WireGuard به آن متصل نشود، هیچ route پیش‌فرضی ایجاد نمی‌شود و اینترنت کاربر را black-hole نمی‌کند.

### مواردی که اضافه/اصلاح شده‌اند

- ذخیره Credentialها با Android Keystore + AES-GCM
- مهاجرت از پروفایل‌های plaintext قدیمی و حذف مقدار legacy بعد از migration
- حذف Firebase و SDKهای telemetry از build
- حذف Secretهای نمونه واقعی‌نما
- VPNService واقعی در Manifest با foreground service
- جلوگیری از نمایش Connected جعلی
- حذف Traffic Simulator؛ آمار فقط باید از engine واقعی بیاید
- TLS hostname verification در ping/diagnostics
- پشتیبانی parser برای VLESS / VMess / Trojan / Shadowsocks / SOCKS5 / WireGuard
- R8 و resource shrinking در release فعال شده‌اند
- GitHub Actions برای static security checks و build
- گزارش امنیتی build
- backup و device-transfer سخت‌گیرانه
- cleartext traffic ممنوع
- کمینه‌سازی permissions

## Kill Switch

برنامه وضعیت ترجیح Kill Switch را نگه می‌دارد، اما Android اجازه نمی‌دهد یک اپ به‌صورت دلخواه گزینه سیستمی «Block connections without VPN» را بدون رضایت کاربر فعال کند. برای enforcement واقعی باید کاربر از تنظیمات VPN سیستم Android، گزینه Block connections without VPN را فعال کند.

## موتور Tunnel

برای استفاده واقعی، باید یک protocol engine معتبر و ممیزی‌شده به لایه `SecureTunnelVpnService` متصل شود. تا آن زمان، Connect عمداً fail-safe است.

## Build

در GitHub به مسیر Actions برو و workflow **Build Hardened APK** را با **Run workflow** اجرا کن. دو artifact تولید می‌شود:

- `SecureTunnel-debug.apk`
- `SecureTunnel-hardened-release.apk`

کلید release فعلی در هر run موقت است. برای update بدون uninstall، یک keystore ثابت را به GitHub Secrets اضافه کن و workflow را به آن متصل کن.

# AstraTrade Pro

Professional Android crypto market analysis prototype with live-data safeguards.

## Implemented
- Real Binance 24h ticker + real 1h candles for technical analysis.
- Real RSI(14), EMA20/EMA50, MACD, ATR, VWAP, Bollinger Bands and volume ratio.
- Signal score and Smart Trading Bot based on the technical snapshot.
- CoinGecko aggregation fallback for price discovery; fallback data is explicitly marked and never synthesized.
- Real CoinGecko global market-cap/volume/BTC dominance when available.
- Alternative.me Fear & Greed when available.
- Real candle chart data only; no synthetic candle fallback.
- Persistent watchlist, journal, alerts and language settings using DataStore.
- RSS market news from CoinDesk and Cointelegraph.
- Risk engine caps notional exposure at balance × leverage and validates stop direction.
- GitHub Actions debug APK build using JDK 17 and Gradle 9.3.1; no debug.keystore is required.

## Data integrity
The app never generates random prices, random candles, or fake live values. If a source fails, the UI receives an empty result or an explicitly labeled aggregated source.

## Build on GitHub
Actions → Build APK → Run workflow. The resulting APK is uploaded as the `astratrade-pro-debug` artifact.

## Important
Exchange integrations for Iranian venues are intentionally not hard-coded with guessed endpoints. They should be added only after their current official API documentation is verified. No API key or exchange credential is bundled in the APK.

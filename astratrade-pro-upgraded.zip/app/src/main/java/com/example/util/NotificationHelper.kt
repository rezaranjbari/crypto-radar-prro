package com.example.util

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.model.MarketCoin
import com.example.model.PriceAlert
import java.util.Locale

object NotificationHelper {

  private const val CHANNEL_ID = "astratrade_price_alerts"
  private const val CHANNEL_NAME = "AstraTrade Price Alerts"

  fun createNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val channel = NotificationChannel(
        CHANNEL_ID,
        CHANNEL_NAME,
        NotificationManager.IMPORTANCE_HIGH
      ).apply {
        description = "Cryptocurrency price target alerts"
        enableLights(true)
        enableVibration(true)
      }
      val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
      manager.createNotificationChannel(channel)
    }
  }

  fun sendPriceAlertNotification(
    context: Context,
    coin: MarketCoin,
    alert: PriceAlert,
    isFa: Boolean
  ) {
    createNotificationChannel(context)

    // Trigger subtle vibration
    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
        val vibrator = vibratorManager.defaultVibrator
        vibrator.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
      } else {
        @Suppress("DEPRECATION")
        val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
          vibrator.vibrate(VibrationEffect.createOneShot(300, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
          @Suppress("DEPRECATION")
          vibrator.vibrate(300)
        }
      }
    } catch (_: Exception) {
      // Ignored if vibration not permitted
    }

    val intent = Intent(context, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val pendingIntent = PendingIntent.getActivity(
      context,
      alert.id.hashCode(),
      intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val directionText = if (alert.isAbove) {
      if (isFa) "عبور از سقف هدف" else "Crossed Above"
    } else {
      if (isFa) "افت به زیر کف هدف" else "Dropped Below"
    }

    val title = if (isFa) {
      "⚡ هشدار قیمت: ${coin.name} (${coin.symbol})"
    } else {
      "⚡ Price Target Reached: ${coin.symbol}"
    }

    val content = if (isFa) {
      "قیمت ${coin.symbol} به ${coin.formattedPrice} رسید ($directionText ${alert.formattedTargetPrice})!"
    } else {
      "${coin.name} has reached ${coin.formattedPrice} ($directionText ${alert.formattedTargetPrice})!"
    }

    val notification = NotificationCompat.Builder(context, CHANNEL_ID)
      .setSmallIcon(R.drawable.ic_launcher_foreground)
      .setContentTitle(title)
      .setContentText(content)
      .setStyle(NotificationCompat.BigTextStyle().bigText(content))
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setAutoCancel(true)
      .setContentIntent(pendingIntent)
      .build()

    val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    try {
      notificationManager.notify(alert.id.hashCode(), notification)
    } catch (_: SecurityException) {
      // Fallback silently if notification permission denied at system level; the in-app visual HUD banner handles it!
    }
  }
}

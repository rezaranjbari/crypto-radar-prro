package com.example.model

enum class CoinCategory { ALL, GAINERS, LOSERS, HIGH_VOLUME, FAVORITES }

enum class SignalType(val titleFa: String, val titleEn: String, val isBullish: Boolean) {
  STRONG_BUY("خرید قوی", "Strong Buy", true),
  BUY("خرید", "Buy", true),
  OVERSOLD_BOUNCE("برگشت از اشباع فروش", "Oversold Rebound", true),
  VOLUME_BREAKOUT("شکست با حجم", "Volume Breakout", true),
  GOLDEN_CROSS("تقاطع صعودی", "Bullish EMA Cross", true),
  WAIT("انتظار", "Wait", false),
  RESISTANCE_REJECT("رد مقاومت", "Resistance Rejection", false),
  SELL("فروش", "Sell", false),
  STRONG_SELL("فروش قوی", "Strong Sell", false),
  OVERBOUGHT_WARN("هشدار اشباع خرید", "Overbought Warning", false),
  RANGE_ACCUMULATION("تراکم/انباشت", "Range Accumulation", true)
}

data class TechnicalSnapshot(
  val rsi: Double = 50.0,
  val ema20: Double = 0.0,
  val ema50: Double = 0.0,
  val macd: Double = 0.0,
  val macdSignal: Double = 0.0,
  val atr: Double = 0.0,
  val adx: Double = 0.0,
  val vwap: Double = 0.0,
  val bollingerUpper: Double = 0.0,
  val bollingerLower: Double = 0.0,
  val volumeRatio: Double = 0.0,
  val score: Int = 50,
  val analysisReady: Boolean = false
)

data class MarketCoin(
  val symbol: String,
  val name: String,
  val price: Double,
  val change24h: Double,
  val volume: Double,
  val high24h: Double = price,
  val low24h: Double = price,
  val sparkline: List<Double> = emptyList(),
  val rsi: Double = 50.0,
  val signal: SignalType = SignalType.WAIT,
  val isFavorite: Boolean = false,
  val exchangeSource: String = "Unknown",
  val lastUpdatedTime: String = "Unknown",
  val technical: TechnicalSnapshot = TechnicalSnapshot()
) {
  val formattedPrice: String get() = when {
    price >= 1000 -> String.format(java.util.Locale.US, "$%,.2f", price)
    price >= 1 -> String.format(java.util.Locale.US, "$%.4f", price)
    price >= 0.001 -> String.format(java.util.Locale.US, "$%.6f", price)
    else -> String.format(java.util.Locale.US, "$%.8f", price)
  }
  val formattedVolume: String get() = when {
    volume >= 1_000_000_000 -> String.format(java.util.Locale.US, "$%.2fB", volume / 1e9)
    volume >= 1_000_000 -> String.format(java.util.Locale.US, "$%.1fM", volume / 1e6)
    volume >= 1_000 -> String.format(java.util.Locale.US, "$%.1fK", volume / 1e3)
    else -> String.format(java.util.Locale.US, "$%.0f", volume)
  }
}

data class CandleStick(val time: String, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double) {
  val isGreen: Boolean get() = close >= open
}

data class MarketOverview(
  val totalMarketCap: String = "—",
  val volume24h: String = "—",
  val btcDominance: Double = 0.0,
  val fearGreedIndex: Int = 0,
  val fearGreedLabelFa: String = "داده در دسترس نیست",
  val fearGreedLabelEn: String = "Unavailable",
  val topGainerSymbol: String = "—",
  val topGainerChange: Double = 0.0,
  val exchangeSourceFa: String = "داده زنده در دسترس نیست",
  val exchangeSourceEn: String = "Live data unavailable",
  val lastSyncTime: String = "—"
)

data class RiskCalculationResult(
  val accountBalance: Double, val riskPercentage: Double, val entryPrice: Double, val stopLossPrice: Double,
  val takeProfit1: Double, val takeProfit2: Double, val isLong: Boolean, val leverage: Int,
  val riskAmountDollars: Double, val positionSizeDollars: Double, val positionSizeUnits: Double,
  val potentialProfitTp1: Double, val potentialProfitTp2: Double, val riskRewardRatioTp1: Double,
  val riskRewardRatioTp2: Double, val stopDistancePercent: Double, val estimatedLiquidationPrice: Double,
  val isRiskSafe: Boolean
)

data class SavedTradeSetup(
  val id: String = java.util.UUID.randomUUID().toString(), val symbol: String, val isLong: Boolean,
  val entryPrice: Double, val stopLoss: Double, val takeProfit: Double, val positionSizeDollars: Double,
  val riskDollars: Double, val riskRewardRatio: Double, val date: String,
  val statusFa: String = "فعال", val statusEn: String = "Active"
)

data class PriceAlert(
  val id: String = java.util.UUID.randomUUID().toString(), val symbol: String, val coinName: String,
  val targetPrice: Double, val isAbove: Boolean = true, val isActive: Boolean = true,
  val isTriggered: Boolean = false, val createdAt: Long = System.currentTimeMillis()
) {
  val formattedTargetPrice: String get() = when {
    targetPrice >= 1000 -> String.format(java.util.Locale.US, "$%,.2f", targetPrice)
    targetPrice >= 1 -> String.format(java.util.Locale.US, "$%.4f", targetPrice)
    targetPrice >= 0.001 -> String.format(java.util.Locale.US, "$%.6f", targetPrice)
    else -> String.format(java.util.Locale.US, "$%.8f", targetPrice)
  }
}

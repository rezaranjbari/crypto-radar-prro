package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.PriceAlert
import com.example.model.SavedTradeSetup
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

private val Context.astraDataStore by preferencesDataStore("astra_trade_store")

object LocalStore {
  private val WATCHLIST = stringPreferencesKey("watchlist")
  private val JOURNAL = stringPreferencesKey("journal")
  private val ALERTS = stringPreferencesKey("alerts")
  private val SETTINGS = stringPreferencesKey("settings")

  suspend fun loadWatchlist(context: Context): Set<String> = context.astraDataStore.data.first()[WATCHLIST]?.split(",")?.filter { it.isNotBlank() }?.toSet() ?: emptySet()
  suspend fun saveWatchlist(context: Context, symbols: Set<String>) = context.astraDataStore.edit { it[WATCHLIST] = symbols.joinToString(",") }

  suspend fun loadJournal(context: Context): List<SavedTradeSetup> = try {
    val a = JSONArray(context.astraDataStore.data.first()[JOURNAL] ?: "[]")
    (0 until a.length()).map { o(a.getJSONObject(it)) }
  } catch (_: Exception) { emptyList() }

  suspend fun saveJournal(context: Context, list: List<SavedTradeSetup>) = context.astraDataStore.edit { it[JOURNAL] = JSONArray(list.map { j(it) }).toString() }

  suspend fun loadAlerts(context: Context): Map<String, PriceAlert> = try {
    val a = JSONArray(context.astraDataStore.data.first()[ALERTS] ?: "[]")
    (0 until a.length()).associate { val x = a.getJSONObject(it); x.getString("symbol") to alert(x) }
  } catch (_: Exception) { emptyMap() }

  suspend fun saveAlerts(context: Context, map: Map<String, PriceAlert>) = context.astraDataStore.edit { it[ALERTS] = JSONArray(map.values.map { a(it) }).toString() }
  suspend fun loadSettings(context: Context): String = context.astraDataStore.data.first()[SETTINGS] ?: "{\"language\":\"fa\"}"
  suspend fun saveSettings(context: Context, json: String) = context.astraDataStore.edit { it[SETTINGS] = json }

  private fun j(x: SavedTradeSetup)=JSONObject().apply { put("id",x.id);put("symbol",x.symbol);put("long",x.isLong);put("entry",x.entryPrice);put("sl",x.stopLoss);put("tp",x.takeProfit);put("size",x.positionSizeDollars);put("risk",x.riskDollars);put("rr",x.riskRewardRatio);put("date",x.date);put("fa",x.statusFa);put("en",x.statusEn) }
  private fun o(x: JSONObject)=SavedTradeSetup(x.optString("id"),x.optString("symbol"),x.optBoolean("long"),x.optDouble("entry"),x.optDouble("sl"),x.optDouble("tp"),x.optDouble("size"),x.optDouble("risk"),x.optDouble("rr"),x.optString("date"),x.optString("fa"),x.optString("en"))
  private fun a(x: PriceAlert)=JSONObject().apply { put("id",x.id);put("symbol",x.symbol);put("name",x.coinName);put("target",x.targetPrice);put("above",x.isAbove);put("active",x.isActive);put("triggered",x.isTriggered);put("created",x.createdAt) }
  private fun alert(x: JSONObject)=PriceAlert(x.optString("id"),x.optString("symbol"),x.optString("name"),x.optDouble("target"),x.optBoolean("above"),x.optBoolean("active"),x.optBoolean("triggered"),x.optLong("created"))
}

package com.example.data

import com.example.model.MarketCoin

data class SmartTradeDecision(val action: String, val score: Int, val reasons: List<String>, val invalidation: String, val risk: String)

object SmartTraderEngine {
  fun evaluate(coin: MarketCoin, isFa: Boolean = true): SmartTradeDecision {
    val t = coin.technical
    if (!t.analysisReady) return SmartTradeDecision(if (isFa) "WAIT" else "WAIT", 0, listOf(if (isFa) "داده کندلی کافی برای تصمیم‌گیری نیست" else "Insufficient candle data"), "—", if (isFa) "نامشخص" else "Unknown")
    val action = when { t.score >= 80 -> if (isFa) "BUY" else "BUY"; t.score <= 25 -> if (isFa) "SELL" else "SELL"; else -> "WAIT" }
    val reasons = buildList {
      add(if (coin.price > t.ema20) "Price above EMA20" else "Price below EMA20")
      add(if (t.ema20 > t.ema50) "EMA20 > EMA50" else "EMA20 < EMA50")
      add(if (t.macd > t.macdSignal) "MACD bullish" else "MACD bearish")
      add("RSI ${"%.1f".format(java.util.Locale.US, t.rsi)}")
      add("Volume ratio ${"%.2f".format(java.util.Locale.US, t.volumeRatio)}x")
    }
    val stop = if (action == "BUY") coin.price - t.atr * 1.5 else coin.price + t.atr * 1.5
    return SmartTradeDecision(action, t.score, reasons, "Stop/invalidation: ${"%.6f".format(java.util.Locale.US, stop)}", if (t.score >= 70 || t.score <= 30) "Medium" else "High")
  }
}

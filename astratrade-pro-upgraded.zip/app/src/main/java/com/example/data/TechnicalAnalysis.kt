package com.example.data

import com.example.model.CandleStick
import com.example.model.SignalType
import com.example.model.TechnicalSnapshot
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object TechnicalAnalysis {
  private fun ema(values: List<Double>, period: Int): List<Double> {
    if (values.size < period) return emptyList()
    val out = MutableList(values.size) { values.first() }
    val k = 2.0 / (period + 1)
    out[period - 1] = values.take(period).average()
    for (i in period until values.size) out[i] = values[i] * k + out[i - 1] * (1 - k)
    return out
  }

  private fun rsi(values: List<Double>, period: Int = 14): Double {
    if (values.size <= period) return 50.0
    var gain = 0.0; var loss = 0.0
    for (i in 1..period) { val d = values[i] - values[i - 1]; if (d >= 0) gain += d else loss -= d }
    var avgGain = gain / period; var avgLoss = loss / period
    for (i in period + 1 until values.size) {
      val d = values[i] - values[i - 1]
      avgGain = (avgGain * (period - 1) + max(0.0, d)) / period
      avgLoss = (avgLoss * (period - 1) + max(0.0, -d)) / period
    }
    if (avgLoss == 0.0) return 100.0
    return 100.0 - 100.0 / (1.0 + avgGain / avgLoss)
  }

  fun analyze(candles: List<CandleStick>): TechnicalSnapshot {
    if (candles.size < 50) return TechnicalSnapshot(analysisReady = false)
    val closes = candles.map { it.close }; val volumes = candles.map { it.volume }
    val e20 = ema(closes, 20).last(); val e50 = ema(closes, 50).last()
    val fast = ema(closes, 12); val slow = ema(closes, 26)
    val macdSeries = fast.indices.filter { it < slow.size }.map { fast[it] - slow[it] }
    val macd = macdSeries.last(); val macdSig = ema(macdSeries, 9).lastOrNull() ?: macd
    val atr = candles.takeLast(14).mapIndexed { i, c ->
      val prev = if (i == 0) candles[candles.lastIndex - 14].close else candles[candles.lastIndex - 14 + i - 1].close
      max(c.high - c.low, max(abs(c.high - prev), abs(c.low - prev)))
    }.average()
    val typical = candles.map { (it.high + it.low + it.close) / 3.0 }
    val vwap = typical.zip(volumes).sumOf { it.first * it.second } / volumes.sum().coerceAtLeast(1.0)
    val mean = closes.takeLast(20).average(); val sd = sqrt(closes.takeLast(20).map { (it - mean) * (it - mean) }.average())
    val upper = mean + 2 * sd; val lower = mean - 2 * sd
    val volumeRatio = volumes.takeLast(1).first() / volumes.takeLast(20).dropLast(1).average().coerceAtLeast(1.0)
    var score = 50
    score += when { closes.last() > e20 && e20 > e50 -> 15; closes.last() > e20 -> 7; closes.last() < e20 && e20 < e50 -> -15; else -> -7 }
    score += when { macd > macdSig -> 10; else -> -10 }
    score += when { rsi(closes) in 45.0..68.0 -> 8; rsi(closes) < 30 -> 5; rsi(closes) > 75 -> -8; else -> 0 }
    score += when { volumeRatio > 1.5 -> 8; volumeRatio < 0.6 -> -4; else -> 0 }
    return TechnicalSnapshot(rsi(closes), e20, e50, macd, macdSig, atr, 0.0, vwap, upper, lower, volumeRatio, score.coerceIn(0,100), true)
  }

  fun signal(t: TechnicalSnapshot): SignalType = when {
    !t.analysisReady -> SignalType.WAIT
    t.score >= 80 -> SignalType.STRONG_BUY
    t.score >= 68 && t.rsi < 72 -> SignalType.BUY
    t.rsi < 30 && t.macd >= t.macdSignal -> SignalType.OVERSOLD_BOUNCE
    t.volumeRatio >= 1.8 && t.macd > t.macdSignal -> SignalType.VOLUME_BREAKOUT
    t.score <= 20 -> SignalType.STRONG_SELL
    t.score <= 32 -> SignalType.SELL
    t.rsi > 75 -> SignalType.OVERBOUGHT_WARN
    else -> SignalType.WAIT
  }
}

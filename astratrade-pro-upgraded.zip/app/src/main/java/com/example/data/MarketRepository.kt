package com.example.data

import com.example.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

object MarketRepository {
  private val trackedSymbols = mapOf(
    "BTCUSDT" to ("BTC" to "Bitcoin"), "ETHUSDT" to ("ETH" to "Ethereum"), "BNBUSDT" to ("BNB" to "BNB Chain"),
    "SOLUSDT" to ("SOL" to "Solana"), "XRPUSDT" to ("XRP" to "Ripple"), "PEPEUSDT" to ("PEPE" to "Pepe"),
    "DOGEUSDT" to ("DOGE" to "Dogecoin"), "SUIUSDT" to ("SUI" to "Sui Network"), "ADAUSDT" to ("ADA" to "Cardano"),
    "AVAXUSDT" to ("AVAX" to "Avalanche"), "LINKUSDT" to ("LINK" to "Chainlink"), "NEARUSDT" to ("NEAR" to "NEAR Protocol"),
    "DOTUSDT" to ("DOT" to "Polkadot"), "SHIBUSDT" to ("SHIB" to "Shiba Inu"), "APTUSDT" to ("APT" to "Aptos")
  )
  private val geckoIds = mapOf("bitcoin" to ("BTC" to "Bitcoin"), "ethereum" to ("ETH" to "Ethereum"), "binancecoin" to ("BNB" to "BNB Chain"), "solana" to ("SOL" to "Solana"), "ripple" to ("XRP" to "Ripple"), "dogecoin" to ("DOGE" to "Dogecoin"), "cardano" to ("ADA" to "Cardano"), "avalanche-2" to ("AVAX" to "Avalanche"), "sui" to ("SUI" to "Sui Network"), "chainlink" to ("LINK" to "Chainlink"), "near" to ("NEAR" to "NEAR Protocol"), "pepe" to ("PEPE" to "Pepe"), "shiba-inu" to ("SHIB" to "Shiba Inu"), "polkadot" to ("DOT" to "Polkadot"), "aptos" to ("APT" to "Aptos"))

  private var cachedCoins: List<MarketCoin> = emptyList()
  var activeExchangeName: String = "—"; private set
  var lastSyncFormattedTime: String = "—"; private set

  private fun get(urlString: String, timeoutMs: Int = 5000): String? = try {
    val c = (URL(urlString).openConnection() as HttpURLConnection).apply {
      requestMethod = "GET"; connectTimeout = timeoutMs; readTimeout = timeoutMs
      setRequestProperty("Accept", "application/json"); setRequestProperty("User-Agent", "AstraTradePro/3.0")
    }
    if (c.responseCode != 200) null else BufferedReader(InputStreamReader(c.inputStream)).use { it.readText() }
  } catch (_: Exception) { null }

  private suspend fun fetchKlines(symbol: String, interval: String = "1h", limit: Int = 100): List<CandleStick> = withContext(Dispatchers.IO) {
    val raw = get("https://api.binance.com/api/v3/klines?symbol=$symbol&interval=$interval&limit=$limit") ?: return@withContext emptyList()
    try {
      val a = JSONArray(raw); val fmt = SimpleDateFormat("MM-dd HH:mm", Locale.US)
      (0 until a.length()).map { i -> val x = a.getJSONArray(i); CandleStick(fmt.format(Date(x.getLong(0))), x.getString(1).toDouble(), x.getString(2).toDouble(), x.getString(3).toDouble(), x.getString(4).toDouble(), x.getString(5).toDouble()) }
    } catch (_: Exception) { emptyList() }
  }

  private suspend fun fetchFromBinance(): List<MarketCoin>? = withContext(Dispatchers.IO) {
    val symbols = trackedSymbols.keys.joinToString(",", prefix = "%5B%22", postfix = "%22%5D") { it }.replace(",", "%22,%22")
    val raw = get("https://api.binance.com/api/v3/ticker/24hr?symbols=$symbols") ?: return@withContext null
    try {
      val a = JSONArray(raw)
      coroutineScope {
        (0 until a.length()).map { i ->
          async(Dispatchers.IO) {
            val o = a.getJSONObject(i); val pair = trackedSymbols[o.getString("symbol")] ?: return@async null
            val price = o.optDouble("lastPrice", 0.0); if (price <= 0) return@async null
            val candles = fetchKlines(o.getString("symbol"))
            val ta = TechnicalAnalysis.analyze(candles)
            val spark = candles.takeLast(20).map { it.close }
            MarketCoin(pair.first, pair.second, price, o.optDouble("priceChangePercent"), o.optDouble("quoteVolume"), o.optDouble("highPrice"), o.optDouble("lowPrice"), spark, ta.rsi, TechnicalAnalysis.signal(ta), cachedCoins.firstOrNull { it.symbol == pair.first }?.isFavorite ?: false, "Binance Spot • LIVE", "LIVE", ta)
          }
        }.awaitAll().filterNotNull()
      }
    } catch (_: Exception) { null }
  }

  private suspend fun fetchFromCoinGecko(): List<MarketCoin>? = withContext(Dispatchers.IO) {
    val raw = get("https://api.coingecko.com/api/v3/simple/price?ids=${geckoIds.keys.joinToString(",")}&vs_currencies=usd&include_24hr_vol=true&include_24hr_change=true") ?: return@withContext null
    try {
      val root = JSONObject(raw)
      geckoIds.mapNotNull { (id, pair) ->
        val o = root.optJSONObject(id) ?: return@mapNotNull null
        val p = o.optDouble("usd", 0.0); if (p <= 0) return@mapNotNull null
        MarketCoin(pair.first, pair.second, p, o.optDouble("usd_24h_change"), o.optDouble("usd_24h_vol"), p, p, listOf(p), 50.0, SignalType.WAIT, cachedCoins.firstOrNull { it.symbol == pair.first }?.isFavorite ?: false, "CoinGecko • AGGREGATED", "LIVE", TechnicalSnapshot(analysisReady = false))
      }.ifEmpty { null }
    } catch (_: Exception) { null }
  }

  fun applyFavorites(symbols: Set<String>) { cachedCoins = cachedCoins.map { it.copy(isFavorite = it.symbol in symbols) } }

  suspend fun fetchTopCoins(): List<MarketCoin> = withContext(Dispatchers.IO) {
    val result = fetchFromBinance() ?: fetchFromCoinGecko()
    if (result.isNullOrEmpty()) {
      activeExchangeName = "OFFLINE"; lastSyncFormattedTime = "No fresh data"; return@withContext emptyList()
    }
    activeExchangeName = if (result.any { it.exchangeSource.startsWith("Binance") }) "Binance Global" else "CoinGecko Aggregator"
    lastSyncFormattedTime = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
    cachedCoins = result
    result
  }

  suspend fun getMarketOverview(coins: List<MarketCoin>): MarketOverview = withContext(Dispatchers.IO) {
    val global = get("https://api.coingecko.com/api/v3/global")
    val fg = get("https://api.alternative.me/fng/?limit=1")
    var cap = "—"; var vol = "—"; var dominance = 0.0
    try { val d = JSONObject(global ?: "{}").optJSONObject("data"); cap = d?.optJSONObject("total_market_cap")?.optDouble("usd", 0.0)?.let { formatMoney(it) } ?: "—"; vol = d?.optJSONObject("total_volume")?.optDouble("usd", 0.0)?.let { formatMoney(it) } ?: "—"; dominance = d?.optJSONObject("market_cap_percentage")?.optDouble("btc", 0.0) ?: 0.0 } catch (_: Exception) {}
    var fgi = 0; var label = "Unavailable"
    try { val x = JSONObject(fg ?: "{}").optJSONArray("data")?.optJSONObject(0); fgi = x?.optString("value")?.toIntOrNull() ?: 0; label = x?.optString("value_classification") ?: "Unavailable" } catch (_: Exception) {}
    val fa = when (label.lowercase()) { "extreme greed" -> "طمع شدید"; "greed" -> "طمع"; "fear" -> "ترس"; "extreme fear" -> "ترس شدید"; else -> "داده در دسترس نیست" }
    val top = coins.maxByOrNull { it.change24h }
    MarketOverview(cap, vol, dominance, fgi, fa, label, top?.symbol ?: "—", top?.change24h ?: 0.0, "$activeExchangeName • وضعیت منبع: زنده/تجمیعی", "$activeExchangeName • source status: live/aggregated", lastSyncFormattedTime)
  }

  private fun formatMoney(v: Double): String = when { v >= 1e12 -> String.format(Locale.US, "$%.2fT", v / 1e12); v >= 1e9 -> String.format(Locale.US, "$%.2fB", v / 1e9); else -> String.format(Locale.US, "$%.2fM", v / 1e6) }

  suspend fun generateCandlesForCoin(coin: MarketCoin, timeframe: String): List<CandleStick> = withContext(Dispatchers.IO) {
    val interval = if (timeframe in setOf("15m","1h","4h","1d")) timeframe else "1h"
    fetchKlines("${coin.symbol}USDT", interval, 200)
  }

  fun calculateRisk(accountBalance: Double, riskPercentage: Double, entryPrice: Double, stopLossPrice: Double, takeProfit1: Double, takeProfit2: Double, isLong: Boolean, leverage: Int = 1): RiskCalculationResult {
    val balance = accountBalance.coerceAtLeast(0.0); val riskPct = riskPercentage.coerceIn(0.1, 10.0); val lev = leverage.coerceIn(1, 125)
    val riskAmount = balance * riskPct / 100.0; val entry = entryPrice.coerceAtLeast(1e-12)
    val validStop = if (isLong) stopLossPrice.coerceAtMost(entry * 0.999999) else stopLossPrice.coerceAtLeast(entry * 1.000001)
    val stopPct = kotlin.math.abs(entry - validStop) / entry
    val maxNotional = balance * lev
    val position = min(riskAmount / stopPct, maxNotional)
    val units = position / entry
    val tp1 = kotlin.math.abs(takeProfit1 - entry) * units; val tp2 = kotlin.math.abs(takeProfit2 - entry) * units
    val rr1 = if (riskAmount > 0) tp1 / riskAmount else 0.0; val rr2 = if (riskAmount > 0) tp2 / riskAmount else 0.0
    val liq = if (isLong) entry * (1 - 0.9 / lev) else entry * (1 + 0.9 / lev)
    return RiskCalculationResult(balance, riskPct, entry, validStop, takeProfit1, takeProfit2, isLong, lev, riskAmount, position, units, tp1, tp2, rr1, rr2, stopPct * 100, liq.coerceAtLeast(0.0), rr1 >= 1.5 && lev <= 10)
  }
}

package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import javax.xml.parsers.DocumentBuilderFactory

data class NewsItem(val title: String, val source: String, val url: String, val publishedAt: String)

object NewsRepository {
  private val feeds = listOf(
    "CoinDesk" to "https://www.coindesk.com/arc/outboundfeeds/rss/",
    "Cointelegraph" to "https://cointelegraph.com/rss"
  )
  suspend fun fetch(limit: Int = 20): List<NewsItem> = withContext(Dispatchers.IO) {
    feeds.flatMap { (source, feed) -> parse(source, feed) }.sortedByDescending { it.publishedAt }.take(limit)
  }
  private fun parse(source: String, url: String): List<NewsItem> = try {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 5000; c.readTimeout = 5000; c.requestMethod = "GET"; c.setRequestProperty("User-Agent", "AstraTradePro/3.0")
    if (c.responseCode != 200) return emptyList()
    val doc = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(c.inputStream)
    val nodes = doc.getElementsByTagName("item")
    (0 until nodes.length).mapNotNull { i ->
      val n = nodes.item(i); fun value(tag: String) = n.childNodes.let { children -> (0 until children.length).firstOrNull { children.item(it).nodeName.equals(tag, true) }?.let { children.item(it).textContent.trim() } ?: "" }
      val title=value("title"); val link=value("link"); val date=value("pubDate")
      if (title.isBlank() || link.isBlank()) null else NewsItem(title, source, link, date)
    }
  } catch (_: Exception) { emptyList() }
}

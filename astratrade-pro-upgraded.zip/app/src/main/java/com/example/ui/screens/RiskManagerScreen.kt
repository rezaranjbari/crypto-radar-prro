package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.graphics.Color
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MarketRepository
import com.example.model.MarketCoin
import com.example.model.RiskCalculationResult
import com.example.model.SavedTradeSetup
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CrimsonRose
import com.example.ui.theme.CrimsonRoseBg
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonEmeraldBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RiskManagerScreen(
  coins: List<MarketCoin>,
  prefilledCoin: MarketCoin?,
  onSaveSetup: (SavedTradeSetup) -> Unit,
  isFa: Boolean = true,
  modifier: Modifier = Modifier
) {
  var selectedCoinSymbol by remember { mutableStateOf(prefilledCoin?.symbol ?: coins.firstOrNull()?.symbol.orEmpty()) }
  var isLong by remember { mutableStateOf(true) }

  // Inputs
  var balanceInput by remember { mutableStateOf("10000") }
  var riskPercentInput by remember { mutableStateOf("2.0") }
  var entryPriceInput by remember {
    mutableStateOf(prefilledCoin?.price?.toString() ?: "0")
  }
  var stopLossInput by remember {
    val ep = prefilledCoin?.price ?: 0.0
    mutableStateOf(String.format(Locale.US, "%.2f", ep * 0.97))
  }
  var takeProfit1Input by remember {
    val ep = prefilledCoin?.price ?: 0.0
    mutableStateOf(String.format(Locale.US, "%.2f", ep * 1.06))
  }
  var takeProfit2Input by remember {
    val ep = prefilledCoin?.price ?: 0.0
    mutableStateOf(String.format(Locale.US, "%.2f", ep * 1.10))
  }
  var leverage by remember { mutableIntStateOf(5) }

  // React to prefilled coin changes
  LaunchedEffect(prefilledCoin) {
    if (prefilledCoin != null) {
      selectedCoinSymbol = prefilledCoin.symbol
      entryPriceInput = String.format(Locale.US, "%.4f", prefilledCoin.price)
      stopLossInput = String.format(Locale.US, "%.4f", prefilledCoin.price * (if (isLong) 0.965 else 1.035))
      takeProfit1Input = String.format(Locale.US, "%.4f", prefilledCoin.price * (if (isLong) 1.07 else 0.93))
      takeProfit2Input = String.format(Locale.US, "%.4f", prefilledCoin.price * (if (isLong) 1.12 else 0.88))
    }
  }

  // Calculate live results
  val balance = balanceInput.toDoubleOrNull() ?: 10000.0
  val riskP = riskPercentInput.toDoubleOrNull() ?: 2.0
  val entryP = entryPriceInput.toDoubleOrNull() ?: 0.0
  val slP = stopLossInput.toDoubleOrNull() ?: (entryP * 0.97)
  val tp1P = takeProfit1Input.toDoubleOrNull() ?: (entryP * 1.06)
  val tp2P = takeProfit2Input.toDoubleOrNull() ?: (entryP * 1.10)

  val calculation: RiskCalculationResult = MarketRepository.calculateRisk(
    accountBalance = balance,
    riskPercentage = riskP,
    entryPrice = entryP,
    stopLossPrice = slP,
    takeProfit1 = tp1P,
    takeProfit2 = tp2P,
    isLong = isLong,
    leverage = leverage
  )

  var saveSuccessMessage by remember { mutableStateOf<String?>(null) }
  val scope = rememberCoroutineScope()

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBg)
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 100.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Header
    item {
      Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Security, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(24.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isFa) "مدیریت ریسک و اندازه پوزیشن" else "Position Size & Risk Engine",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = if (isFa) "محاسبه دقیق حجم ورود و نسبت ریوارد به ریسک طبق اصول معامله‌گران حرفه‌ای" else "Calculate exact capital at risk, position sizing and risk-to-reward ratio",
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary
        )
      }
    }

    // Quick Coin Pre-fill Row
    item {
      Text(
        text = if (isFa) "انتخاب سریع ارز جهت بارگذاری قیمت:" else "Quick fill from live coin:",
        style = MaterialTheme.typography.bodySmall,
        color = TextMuted
      )
      Spacer(modifier = Modifier.height(4.dp))
      LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(coins.take(8)) { coin ->
          FilterChip(
            selected = selectedCoinSymbol == coin.symbol,
            onClick = {
              selectedCoinSymbol = coin.symbol
              entryPriceInput = String.format(Locale.US, "%.4f", coin.price)
              stopLossInput = String.format(Locale.US, "%.4f", coin.price * (if (isLong) 0.965 else 1.035))
              takeProfit1Input = String.format(Locale.US, "%.4f", coin.price * (if (isLong) 1.07 else 0.93))
              takeProfit2Input = String.format(Locale.US, "%.4f", coin.price * (if (isLong) 1.12 else 0.88))
            },
            label = { Text("${coin.symbol} (${coin.formattedPrice})", fontSize = 11.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = NeonCyan,
              selectedLabelColor = DarkBg,
              containerColor = DarkSurfaceCard,
              labelColor = TextSecondary
            )
          )
        }
      }
    }

    // Direction Toggle (Long / Short)
    item {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .background(DarkSurfaceElevated)
          .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        Button(
          onClick = {
            if (!isLong) {
              isLong = true
              val ep = entryPriceInput.toDoubleOrNull() ?: 0.0
              stopLossInput = String.format(Locale.US, "%.4f", ep * 0.965)
              takeProfit1Input = String.format(Locale.US, "%.4f", ep * 1.07)
              takeProfit2Input = String.format(Locale.US, "%.4f", ep * 1.12)
            }
          },
          modifier = Modifier.weight(1f),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (isLong) NeonEmerald else DarkSurfaceCard,
            contentColor = if (isLong) DarkBg else TextSecondary
          ),
          shape = RoundedCornerShape(10.dp)
        ) {
          Text(
            text = if (isFa) "🟢 معامله لانگ (خرید)" else "🟢 LONG (Buy)",
            fontWeight = FontWeight.Bold
          )
        }

        Button(
          onClick = {
            if (isLong) {
              isLong = false
              val ep = entryPriceInput.toDoubleOrNull() ?: 0.0
              stopLossInput = String.format(Locale.US, "%.4f", ep * 1.035)
              takeProfit1Input = String.format(Locale.US, "%.4f", ep * 0.93)
              takeProfit2Input = String.format(Locale.US, "%.4f", ep * 0.88)
            }
          },
          modifier = Modifier.weight(1f),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (!isLong) CrimsonRose else DarkSurfaceCard,
            contentColor = if (!isLong) Color.White else TextSecondary
          ),
          shape = RoundedCornerShape(10.dp)
        ) {
          Text(
            text = if (isFa) "🔴 معامله شورت (فروش)" else "🔴 SHORT (Sell)",
            fontWeight = FontWeight.Bold
          )
        }
      }
    }

    // Input fields card
    item {
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
      ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          // Capital & Risk %
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            OutlinedTextField(
              value = balanceInput,
              onValueChange = { balanceInput = it },
              label = { Text(if (isFa) "کل سرمایه ($)" else "Capital ($)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier
                .weight(1f)
                .testTag("capital_input"),
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonCyan,
                unfocusedBorderColor = DarkBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
              )
            )

            OutlinedTextField(
              value = riskPercentInput,
              onValueChange = { riskPercentInput = it },
              label = { Text(if (isFa) "ریسک مجاز (%)" else "Risk (%)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier
                .weight(1f)
                .testTag("risk_percent_input"),
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonCyan,
                unfocusedBorderColor = DarkBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
              )
            )
          }

          // Entry & Stop Loss
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            OutlinedTextField(
              value = entryPriceInput,
              onValueChange = { entryPriceInput = it },
              label = { Text(if (isFa) "قیمت ورود ($)" else "Entry ($)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier
                .weight(1f)
                .testTag("entry_price_input"),
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonCyan,
                unfocusedBorderColor = DarkBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
              )
            )

            OutlinedTextField(
              value = stopLossInput,
              onValueChange = { stopLossInput = it },
              label = { Text(if (isFa) "حد ضرر ($)" else "Stop Loss ($)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier
                .weight(1f)
                .testTag("stop_loss_input"),
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = CrimsonRose,
                unfocusedBorderColor = DarkBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
              )
            )
          }

          // TP1 & TP2
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            OutlinedTextField(
              value = takeProfit1Input,
              onValueChange = { takeProfit1Input = it },
              label = { Text(if (isFa) "هدف سود ۱ ($)" else "Take Profit 1 ($)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier
                .weight(1f)
                .testTag("tp1_input"),
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonEmerald,
                unfocusedBorderColor = DarkBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
              )
            )

            OutlinedTextField(
              value = takeProfit2Input,
              onValueChange = { takeProfit2Input = it },
              label = { Text(if (isFa) "هدف سود ۲ ($)" else "Take Profit 2 ($)") },
              keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
              singleLine = true,
              modifier = Modifier
                .weight(1f)
                .testTag("tp2_input"),
              shape = RoundedCornerShape(10.dp),
              colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = NeonEmerald,
                unfocusedBorderColor = DarkBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
              )
            )
          }

          // Leverage Slider
          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = if (isFa) "اهرم معاملاتی (Leverage):" else "Leverage:",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
              )
              Text(
                text = "${leverage}x",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (leverage <= 10) NeonCyan else CrimsonRose
              )
            }
            Slider(
              value = leverage.toFloat(),
              onValueChange = { leverage = it.toInt() },
              valueRange = 1f..25f,
              steps = 23,
              colors = SliderDefaults.colors(
                thumbColor = NeonCyan,
                activeTrackColor = NeonCyan,
                inactiveTrackColor = DarkBorder
              )
            )
          }
        }
      }
    }

    // Results Dashboard Card
    item {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(1.5.dp, if (calculation.isRiskSafe) NeonEmerald else AmberGold, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        shape = RoundedCornerShape(16.dp)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          // Top HUD status banner
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = if (calculation.isRiskSafe) Icons.Default.CheckCircle else Icons.Default.Warning,
                contentDescription = null,
                tint = if (calculation.isRiskSafe) NeonEmerald else AmberGold,
                modifier = Modifier.size(20.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (calculation.isRiskSafe) {
                  if (isFa) "پوزیشن استاندارد و منطقی" else "Solid Risk Profile"
                } else {
                  if (isFa) "هشدار: ریسک یا اهرم بالا" else "High Risk Warning"
                },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (calculation.isRiskSafe) NeonEmerald else AmberGold
              )
            }

            // R:R Pill
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(if (calculation.riskRewardRatioTp1 >= 2.0) NeonEmeraldBg else AmberGold.copy(alpha = 0.15f))
                .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
              Text(
                text = String.format(Locale.US, "R:R  1 : %.2f", calculation.riskRewardRatioTp1),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = if (calculation.riskRewardRatioTp1 >= 2.0) NeonEmerald else AmberGold
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // 2x2 Key Metric Grid
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            // Capital at Risk ($)
            Card(
              modifier = Modifier.weight(1f),
              colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
              shape = RoundedCornerShape(10.dp)
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(
                  text = if (isFa) "مبلغ در معرض ریسک" else "Capital At Risk",
                  style = MaterialTheme.typography.bodySmall,
                  color = TextMuted
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = String.format(Locale.US, "$%,.2f", calculation.riskAmountDollars),
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = CrimsonRose
                )
                Text(
                  text = String.format(Locale.US, "%.1f%% سرمایه", calculation.riskPercentage),
                  style = MaterialTheme.typography.labelSmall,
                  color = TextSecondary
                )
              }
            }

            // Optimal Position Size ($)
            Card(
              modifier = Modifier.weight(1f),
              colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
              shape = RoundedCornerShape(10.dp)
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(
                  text = if (isFa) "حجم مجاز ورود" else "Optimal Position",
                  style = MaterialTheme.typography.bodySmall,
                  color = TextMuted
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = String.format(Locale.US, "$%,.2f", calculation.positionSizeDollars),
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = NeonCyan
                )
                Text(
                  text = String.format(Locale.US, "%.4f واحد", calculation.positionSizeUnits),
                  style = MaterialTheme.typography.labelSmall,
                  color = TextSecondary
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Profit Targets & Liquidation
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            // Expected Profit
            Card(
              modifier = Modifier.weight(1f),
              colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
              shape = RoundedCornerShape(10.dp)
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(
                  text = if (isFa) "سود احتمالی (هدف ۱)" else "Potential Profit TP1",
                  style = MaterialTheme.typography.bodySmall,
                  color = TextMuted
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = String.format(Locale.US, "+$%,.2f", calculation.potentialProfitTp1),
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = NeonEmerald
                )
                Text(
                  text = String.format(Locale.US, "TP2: +$%,.2f", calculation.potentialProfitTp2),
                  style = MaterialTheme.typography.labelSmall,
                  color = NeonEmerald.copy(alpha = 0.8f)
                )
              }
            }

            // Liquidation
            Card(
              modifier = Modifier.weight(1f),
              colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
              shape = RoundedCornerShape(10.dp)
            ) {
              Column(modifier = Modifier.padding(10.dp)) {
                Text(
                  text = if (isFa) "قیمت لیکوئید تقریبی" else "Est. Liquidation",
                  style = MaterialTheme.typography.bodySmall,
                  color = TextMuted
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = String.format(Locale.US, "$%,.2f", calculation.estimatedLiquidationPrice),
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = AmberGold
                )
                Text(
                  text = String.format(Locale.US, "فاصله تا ضرر: %.1f%%", calculation.stopDistancePercent),
                  style = MaterialTheme.typography.labelSmall,
                  color = TextSecondary
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Save Trade Setup Button
          Button(
            onClick = {
              val dateStr = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date())
              val setup = SavedTradeSetup(
                symbol = selectedCoinSymbol,
                isLong = isLong,
                entryPrice = entryP,
                stopLoss = slP,
                takeProfit = tp1P,
                positionSizeDollars = calculation.positionSizeDollars,
                riskDollars = calculation.riskAmountDollars,
                riskRewardRatio = calculation.riskRewardRatioTp1,
                date = dateStr,
                statusFa = "فعال",
                statusEn = "Active"
              )
              onSaveSetup(setup)
              saveSuccessMessage = if (isFa) "معامله $selectedCoinSymbol در دفترچه ثبت شد!" else "Trade $selectedCoinSymbol saved!"
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("save_trade_setup_button"),
            colors = ButtonDefaults.buttonColors(
              containerColor = NeonCyan,
              contentColor = DarkBg
            ),
            shape = RoundedCornerShape(10.dp)
          ) {
            Icon(Icons.Default.BookmarkAdd, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isFa) "ذخیره در دفترچه معاملات (Trading Journal)" else "Save to Trading Journal",
              fontWeight = FontWeight.Bold
            )
          }

          saveSuccessMessage?.let { msg ->
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "✅ $msg",
              color = NeonEmerald,
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.Medium
            )
          }
        }
      }
    }
  }
}

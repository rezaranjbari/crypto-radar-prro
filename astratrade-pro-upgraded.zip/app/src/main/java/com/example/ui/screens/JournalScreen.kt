package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SavedTradeSetup
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CrimsonRose
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun JournalScreen(
  savedSetups: List<SavedTradeSetup>,
  onDeleteSetup: (String) -> Unit,
  isFa: Boolean = true,
  modifier: Modifier = Modifier
) {
  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBg)
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 100.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    item {
      Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Book, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(24.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isFa) "دفترچه معاملات و ژورنال" else "Trading Journal",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = if (isFa) "ثبت و پیگیری استراتژی‌ها، حد ضرر و میزان ریسک معاملات شما" else "Track your calculated trade setups, execution and R:R ratios",
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary
        )
      }
    }

    if (savedSetups.isEmpty()) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(260.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
              Icons.Default.Book,
              contentDescription = null,
              tint = TextMuted,
              modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = if (isFa) "هنوز معامله‌ای ذخیره نشده است" else "No trade setups saved yet",
              style = MaterialTheme.typography.titleMedium,
              color = TextMuted
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = if (isFa) "از بخش مدیریت ریسک، پوزیشن‌های خود را محاسبه و ذخیره کنید." else "Use the Risk Manager to calculate and save setups.",
              style = MaterialTheme.typography.bodySmall,
              color = TextMuted
            )
          }
        }
      }
    }

    items(savedSetups, key = { it.id }) { setup ->
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .border(1.dp, DarkBorder, RoundedCornerShape(14.dp))
          .testTag("journal_item_${setup.id}"),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(6.dp))
                  .background(if (setup.isLong) NeonEmerald.copy(alpha = 0.2f) else CrimsonRose.copy(alpha = 0.2f))
                  .padding(horizontal = 8.dp, vertical = 3.dp)
              ) {
                Text(
                  text = if (setup.isLong) (if (isFa) "لانگ (LONG)" else "LONG") else (if (isFa) "شورت (SHORT)" else "SHORT"),
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Bold,
                  color = if (setup.isLong) NeonEmerald else CrimsonRose
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "${setup.symbol}/USDT",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            }

            IconButton(onClick = { onDeleteSetup(setup.id) }) {
              Icon(
                Icons.Default.DeleteOutline,
                contentDescription = "Delete",
                tint = TextMuted,
                modifier = Modifier.size(20.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          // Stats grid
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(DarkSurfaceElevated)
              .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(text = if (isFa) "ورود" else "Entry", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 10.sp)
              Text(text = String.format(Locale.US, "$%.4f", setup.entryPrice), style = MaterialTheme.typography.labelSmall, color = TextPrimary)
            }
            Column {
              Text(text = if (isFa) "حد ضرر" else "Stop Loss", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 10.sp)
              Text(text = String.format(Locale.US, "$%.4f", setup.stopLoss), style = MaterialTheme.typography.labelSmall, color = CrimsonRose)
            }
            Column {
              Text(text = if (isFa) "تارگت سود" else "Take Profit", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 10.sp)
              Text(text = String.format(Locale.US, "$%.4f", setup.takeProfit), style = MaterialTheme.typography.labelSmall, color = NeonEmerald)
            }
            Column {
              Text(text = "R:R", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 10.sp)
              Text(text = String.format(Locale.US, "1 : %.2f", setup.riskRewardRatio), style = MaterialTheme.typography.labelSmall, color = AmberGold)
            }
          }

          Spacer(modifier = Modifier.height(8.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(
              text = "${if (isFa) "حجم پوزیشن:" else "Size:"} $%,.2f".format(Locale.US, setup.positionSizeDollars),
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary,
              fontSize = 11.sp
            )
            Text(
              text = "${if (isFa) "ریسک:" else "Risk:"} $%,.2f".format(Locale.US, setup.riskDollars),
              style = MaterialTheme.typography.bodySmall,
              color = CrimsonRose,
              fontSize = 11.sp
            )
          }

          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = setup.date,
            style = MaterialTheme.typography.bodySmall,
            color = TextMuted,
            fontSize = 10.sp
          )
        }
      }
    }
  }
}

package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MarketRepository
import com.example.model.CandleStick
import com.example.model.MarketCoin
import com.example.ui.theme.CrimsonRose
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.max

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoinDetailSheet(
  coin: MarketCoin,
  activeAlert: com.example.model.PriceAlert? = null,
  onDismiss: () -> Unit,
  onSendToRiskCalculator: (MarketCoin) -> Unit,
  onSetAlert: (MarketCoin) -> Unit = {},
  isFa: Boolean = true
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var selectedTimeframe by remember { mutableStateOf("1h") }
  var isLineMode by remember { mutableStateOf(false) }
  var candles by remember { mutableStateOf<List<CandleStick>>(emptyList()) }

  LaunchedEffect(coin, selectedTimeframe) {
    candles = MarketRepository.generateCandlesForCoin(coin, selectedTimeframe)
  }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = DarkSurface,
    dragHandle = null
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(20.dp)
        .testTag("coin_detail_sheet")
    ) {
      // Header: Coin Info & Close Button
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(46.dp)
              .clip(CircleShape)
              .background(NeonCyan.copy(alpha = 0.15f))
              .border(1.dp, NeonCyan, CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = coin.symbol.take(4),
              fontWeight = FontWeight.Bold,
              color = NeonCyan,
              style = MaterialTheme.typography.titleMedium
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
              text = "${coin.name} (${coin.symbol}/USDT)",
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
            Text(
              text = if (isFa) coin.signal.titleFa else coin.signal.titleEn,
              style = MaterialTheme.typography.bodySmall,
              color = if (coin.signal.isBullish) NeonEmerald else CrimsonRose
            )
            Text(
              text = "🟢 ${if (isFa) "صرافی مرجع:" else "Verified Source:"} ${coin.exchangeSource}",
              style = MaterialTheme.typography.labelSmall,
              color = NeonEmerald,
              fontSize = 10.sp
            )
          }
        }

        IconButton(onClick = onDismiss) {
          Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Price & 24h High/Low Stats Banner
      Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        shape = RoundedCornerShape(14.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
          ) {
            Column {
              Text(
                text = if (isFa) "قیمت لحظه‌ای" else "Live Price",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
              )
              Text(
                text = coin.formattedPrice,
                style = MaterialTheme.typography.displayLarge,
                fontSize = 28.sp,
                color = TextPrimary,
                fontWeight = FontWeight.Bold
              )
            }
            Text(
              text = String.format(Locale.US, "%+.2f%%", coin.change24h),
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold,
              color = if (coin.change24h >= 0) NeonEmerald else CrimsonRose
            )
          }

          Spacer(modifier = Modifier.height(12.dp))

          // 24h High/Low Visual Bar
          val high = coin.high24h
          val low = coin.low24h
          val range = max(0.0000001, high - low)
          val progress = ((coin.price - low) / range).coerceIn(0.0, 1.0).toFloat()

          Column {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = String.format(Locale.US, "Low: $%.4f", low),
                style = MaterialTheme.typography.labelSmall,
                color = CrimsonRose
              )
              Text(
                text = String.format(Locale.US, "High: $%.4f", high),
                style = MaterialTheme.typography.labelSmall,
                color = NeonEmerald
              )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(DarkBorder)
            ) {
              Box(
                modifier = Modifier
                  .fillMaxWidth(progress)
                  .height(6.dp)
                  .background(NeonCyan)
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Timeframe chips & Chart Mode toggle
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          listOf("15m", "1h", "4h", "1D").forEach { tf ->
            FilterChip(
              selected = selectedTimeframe == tf,
              onClick = { selectedTimeframe = tf },
              label = { Text(tf, fontSize = 12.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = NeonCyan,
                selectedLabelColor = DarkBg,
                containerColor = DarkSurfaceElevated,
                labelColor = TextSecondary
              )
            )
          }
        }

        // Toggle Candlesticks vs Line
        IconButton(onClick = { isLineMode = !isLineMode }) {
          Icon(
            imageVector = if (isLineMode) Icons.Default.Timeline else Icons.Default.ShowChart,
            contentDescription = "Toggle Chart Type",
            tint = NeonCyan
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Interactive Chart
      InteractiveCandleChart(
        candles = candles,
        isLineMode = isLineMode
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Technical Indicators Grid
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        // RSI
        Card(
          modifier = Modifier.weight(1f),
          colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
          shape = RoundedCornerShape(12.dp)
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(
              text = if (isFa) "شاخص RSI (۱۴)" else "RSI Indicator",
              style = MaterialTheme.typography.bodySmall,
              color = TextMuted
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = String.format(Locale.US, "%.1f", coin.rsi),
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = when {
                coin.rsi < 35 -> NeonEmerald
                coin.rsi > 70 -> CrimsonRose
                else -> NeonCyan
              }
            )
            Text(
              text = when {
                coin.rsi < 35 -> if (isFa) "اشباع فروش (فرصت)" else "Oversold"
                coin.rsi > 70 -> if (isFa) "اشباع خرید (خطر)" else "Overbought"
                else -> if (isFa) "خنثی و پایدار" else "Neutral"
              },
              style = MaterialTheme.typography.labelSmall,
              color = TextSecondary
            )
          }
        }

        // Volume 24h
        Card(
          modifier = Modifier.weight(1f),
          colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
          shape = RoundedCornerShape(12.dp)
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Text(
              text = if (isFa) "حجم معاملات" else "24h Volume",
              style = MaterialTheme.typography.bodySmall,
              color = TextMuted
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = coin.formattedVolume,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
            Text(
              text = if (isFa) "نقدشوندگی بالا" else "High Liquidity",
              style = MaterialTheme.typography.labelSmall,
              color = NeonEmerald
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(18.dp))

      // Price Alert Button
      androidx.compose.material3.OutlinedButton(
        onClick = {
          onSetAlert(coin)
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("detail_set_alert_button"),
        colors = ButtonDefaults.outlinedButtonColors(
          contentColor = NeonCyan
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.6f)),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(
          imageVector = if (activeAlert != null) Icons.Default.NotificationsActive else Icons.Outlined.Notifications,
          contentDescription = null,
          modifier = Modifier.size(20.dp),
          tint = NeonCyan
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (activeAlert != null) {
            "${if (isFa) "ویرایش هشدار فعال:" else "Edit Active Alert:"} ${activeAlert.formattedTargetPrice}"
          } else {
            if (isFa) "تنظیم هشدار قیمت هدف (Push Notification)" else "Set Target Price Alert"
          },
          fontWeight = FontWeight.Bold,
          style = MaterialTheme.typography.titleMedium
        )
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Action Button: Send to Risk Manager
      Button(
        onClick = {
          onSendToRiskCalculator(coin)
          onDismiss()
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(50.dp)
          .testTag("send_to_risk_calc_button"),
        colors = ButtonDefaults.buttonColors(
          containerColor = NeonCyan,
          contentColor = DarkBg
        ),
        shape = RoundedCornerShape(12.dp)
      ) {
        Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = if (isFa) "محاسبه هوشمند ریسک و اندازه پوزیشن" else "Calculate Risk & Position Size",
          fontWeight = FontWeight.Bold,
          style = MaterialTheme.typography.titleMedium
        )
      }
    }
  }
}

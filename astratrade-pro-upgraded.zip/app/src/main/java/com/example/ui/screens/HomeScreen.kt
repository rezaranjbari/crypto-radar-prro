package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.ViewList
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CoinCategory
import com.example.model.MarketCoin
import com.example.model.MarketOverview
import com.example.ui.components.MarketCoinCard
import com.example.ui.components.MarketCoinGridCard
import com.example.ui.theme.AmberGold
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun HomeScreen(
  coins: List<MarketCoin>,
  overview: MarketOverview,
  loading: Boolean,
  errorMessage: String?,
  onRefresh: () -> Unit,
  onCoinClick: (MarketCoin) -> Unit,
  onToggleFavorite: (MarketCoin) -> Unit,
  priceAlerts: Map<String, com.example.model.PriceAlert> = emptyMap(),
  onToggleAlert: (MarketCoin) -> Unit = {},
  isFa: Boolean = true,
  modifier: Modifier = Modifier
) {
  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf(CoinCategory.ALL) }
  var isGridMode by remember { mutableStateOf(true) }

  // Filtered and sorted coins
  val filteredCoins = coins.filter { coin ->
    val matchesSearch = coin.symbol.contains(searchQuery.trim(), ignoreCase = true) ||
      coin.name.contains(searchQuery.trim(), ignoreCase = true)
    val matchesCategory = when (selectedCategory) {
      CoinCategory.ALL -> true
      CoinCategory.GAINERS -> coin.change24h > 0
      CoinCategory.LOSERS -> coin.change24h < 0
      CoinCategory.HIGH_VOLUME -> coin.volume >= 1_000_000_000.0
      CoinCategory.FAVORITES -> coin.isFavorite
    }
    matchesSearch && matchesCategory
  }.let { list ->
    when (selectedCategory) {
      CoinCategory.GAINERS -> list.sortedByDescending { it.change24h }
      CoinCategory.LOSERS -> list.sortedBy { it.change24h }
      CoinCategory.HIGH_VOLUME -> list.sortedByDescending { it.volume }
      else -> list
    }
  }

  LazyVerticalGrid(
    columns = if (isGridMode) GridCells.Adaptive(minSize = 160.dp) else GridCells.Fixed(1),
    modifier = modifier
      .fillMaxSize()
      .background(DarkBg)
      .padding(horizontal = 14.dp)
      .testTag("crypto_market_grid"),
    contentPadding = PaddingValues(top = 8.dp, bottom = 90.dp),
    horizontalArrangement = Arrangement.spacedBy(10.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    // Header & Subtitles (full-width span)
    item(span = { GridItemSpan(maxLineSpan) }) {
      Column(modifier = Modifier.fillMaxWidth()) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = if (isFa) "ناوبری هوشمند بازار رمزارزها" else "Smart Market Navigator",
              style = MaterialTheme.typography.headlineMedium,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = if (isFa) "قیمت‌های زنده و تحلیل روند بصری رمزارزها" else "Live cryptocurrency prices with sparkline visual trends",
              style = MaterialTheme.typography.bodyMedium,
              color = TextSecondary
            )
          }

          // Grid / List View Toggle Button
          IconButton(
            onClick = { isGridMode = !isGridMode },
            modifier = Modifier
              .clip(RoundedCornerShape(10.dp))
              .background(DarkSurfaceElevated)
              .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
              .size(42.dp)
              .testTag("toggle_grid_view_button")
          ) {
            Icon(
              imageVector = if (isGridMode) Icons.Default.ViewList else Icons.Default.GridView,
              contentDescription = "Toggle Grid or List View",
              tint = NeonCyan,
              modifier = Modifier.size(22.dp)
            )
          }
        }
      }
    }

    // Market Overview Card (full-width span)
    item(span = { GridItemSpan(maxLineSpan) }) {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, DarkBorder, RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        shape = RoundedCornerShape(16.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                Icons.Default.TrendingUp,
                contentDescription = null,
                tint = NeonCyan,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = if (isFa) "وضعیت کلان بازار" else "Market Pulse",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            }

            // Fear & Greed pill
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(AmberGold.copy(alpha = 0.15f))
                .border(1.dp, AmberGold.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
              Text(
                text = "${overview.fearGreedIndex} • ${if (isFa) overview.fearGreedLabelFa else overview.fearGreedLabelEn}",
                style = MaterialTheme.typography.labelSmall,
                color = AmberGold,
                fontWeight = FontWeight.Bold
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(
                text = if (isFa) "ارزش کل بازار" else "Total Cap",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
              )
              Text(
                text = overview.totalMarketCap,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Text(
                text = if (isFa) "حجم کل ۲۴س" else "24h Volume",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
              )
              Text(
                text = overview.volume24h,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = NeonCyan
              )
            }
            Column(horizontalAlignment = Alignment.End) {
              Text(
                text = if (isFa) "بیشترین رشد" else "Top Gainer",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted
              )
              Text(
                text = "${overview.topGainerSymbol} %+.1f%%".format(Locale.US, overview.topGainerChange),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = NeonEmerald
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          // Verified Exchange Source Ribbon
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(DarkSurfaceCard)
              .border(1.dp, NeonEmerald.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
              .padding(horizontal = 10.dp, vertical = 6.dp)
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(7.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(NeonEmerald)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (isFa) overview.exchangeSourceFa else overview.exchangeSourceEn,
                  style = MaterialTheme.typography.labelSmall,
                  color = NeonEmerald,
                  fontWeight = FontWeight.Bold,
                  fontSize = 11.sp
                )
              }

              Text(
                text = "${if (isFa) "آخرین استعلام:" else "Sync:"} ${overview.lastSyncTime}",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                fontSize = 10.sp
              )
            }
          }
        }
      }
    }

    // Refresh & Search Row (full-width span)
    item(span = { GridItemSpan(maxLineSpan) }) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = {
            Text(
              if (isFa) "جستجوی نماد یا نام ارز..." else "Search symbol or coin...",
              color = TextMuted,
              fontSize = 13.sp
            )
          },
          leadingIcon = {
            Icon(Icons.Default.Search, contentDescription = "Search", tint = TextMuted)
          },
          trailingIcon = {
            if (searchQuery.isNotEmpty()) {
              IconButton(onClick = { searchQuery = "" }) {
                Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextMuted)
              }
            }
          },
          singleLine = true,
          modifier = Modifier
            .weight(1f)
            .testTag("search_coin_input"),
          shape = RoundedCornerShape(12.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonCyan,
            unfocusedBorderColor = DarkBorder,
            focusedContainerColor = DarkSurfaceCard,
            unfocusedContainerColor = DarkSurfaceCard,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          )
        )

        Button(
          onClick = onRefresh,
          enabled = !loading,
          modifier = Modifier
            .height(54.dp)
            .testTag("refresh_market_button"),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = DarkSurfaceElevated,
            contentColor = NeonCyan
          ),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
        ) {
          if (loading) {
            CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              strokeWidth = 2.dp,
              color = NeonCyan
            )
          } else {
            Icon(
              Icons.Default.Refresh,
              contentDescription = "Refresh",
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }
    }

    // Category Filter Chips (full-width span)
    item(span = { GridItemSpan(maxLineSpan) }) {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        val categories = listOf(
          Pair(CoinCategory.ALL, if (isFa) "همه ارزها" else "All Coins"),
          Pair(CoinCategory.GAINERS, if (isFa) "بیشترین رشد" else "Top Gainers"),
          Pair(CoinCategory.LOSERS, if (isFa) "بیشترین افت" else "Top Losers"),
          Pair(CoinCategory.HIGH_VOLUME, if (isFa) "حجم سنگین" else "High Volume"),
          Pair(CoinCategory.FAVORITES, if (isFa) "نشان‌شده‌ها ⭐" else "Favorites ⭐")
        )

        items(categories) { (cat, label) ->
          FilterChip(
            selected = selectedCategory == cat,
            onClick = { selectedCategory = cat },
            label = { Text(label, fontSize = 12.sp, fontWeight = FontWeight.Medium) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = NeonCyan,
              selectedLabelColor = DarkBg,
              containerColor = DarkSurfaceCard,
              labelColor = TextSecondary
            ),
            border = FilterChipDefaults.filterChipBorder(
              enabled = true,
              selected = selectedCategory == cat,
              borderColor = DarkBorder,
              selectedBorderColor = NeonCyan
            )
          )
        }
      }
    }

    // Error Message Banner (if any)
    errorMessage?.let { errorText ->
      item(span = { GridItemSpan(maxLineSpan) }) {
        Card(
          colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
          shape = RoundedCornerShape(10.dp)
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = errorText,
              color = MaterialTheme.colorScheme.onErrorContainer,
              style = MaterialTheme.typography.bodySmall
            )
          }
        }
      }
    }

    // Empty list state
    if (filteredCoins.isEmpty() && !loading) {
      item(span = { GridItemSpan(maxLineSpan) }) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(200.dp),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
              text = if (isFa) "هیچ ارزی با این فیلتر یافت نشد" else "No coins found",
              style = MaterialTheme.typography.titleMedium,
              color = TextMuted
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = if (isFa) "لطفاً عبارت دیگری را جستجو کنید" else "Try searching with another keyword",
              style = MaterialTheme.typography.bodySmall,
              color = TextMuted
            )
          }
        }
      }
    }

    // Coins Grid / List Items
    if (isGridMode) {
      // 2-Column Grid of Cryptocurrency cards with prominent visual trend sparklines
      items(filteredCoins, key = { it.symbol }) { coin ->
        MarketCoinGridCard(
          coin = coin,
          activeAlert = priceAlerts[coin.symbol],
          onClick = { onCoinClick(coin) },
          onToggleFavorite = { onToggleFavorite(coin) },
          onToggleAlert = { onToggleAlert(coin) },
          isFa = isFa
        )
      }
    } else {
      // 1-Column full-width row cards
      items(filteredCoins, key = { it.symbol }, span = { GridItemSpan(maxLineSpan) }) { coin ->
        MarketCoinCard(
          coin = coin,
          activeAlert = priceAlerts[coin.symbol],
          onClick = { onCoinClick(coin) },
          onToggleFavorite = { onToggleFavorite(coin) },
          onToggleAlert = { onToggleAlert(coin) },
          isFa = isFa
        )
      }
    }
  }
}

package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MarketCoin
import com.example.model.PriceAlert
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CrimsonRose
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun SetPriceAlertDialog(
  coin: MarketCoin,
  existingAlert: PriceAlert?,
  onDismiss: () -> Unit,
  onSaveAlert: (PriceAlert) -> Unit,
  onDeleteAlert: (String) -> Unit,
  isFa: Boolean = true
) {
  val defaultTarget = existingAlert?.targetPrice ?: (coin.price * 1.05)
  var targetPriceText by remember {
    mutableStateOf(String.format(Locale.US, if (coin.price >= 1.0) "%.2f" else "%.6f", defaultTarget))
  }
  var isAbove by remember { mutableStateOf(existingAlert?.isAbove ?: true) }

  AlertDialog(
    onDismissRequest = onDismiss,
    containerColor = DarkSurface,
    titleContentColor = TextPrimary,
    shape = RoundedCornerShape(20.dp),
    modifier = Modifier
      .border(1.dp, DarkBorder, RoundedCornerShape(20.dp))
      .testTag("set_price_alert_dialog"),
    title = {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(NeonCyan.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            Icons.Default.NotificationsActive,
            contentDescription = null,
            tint = NeonCyan,
            modifier = Modifier.size(20.dp)
          )
        }
        Column {
          Text(
            text = if (isFa) "تنظیم هشدار قیمت ${coin.symbol}" else "Price Alert: ${coin.symbol}",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
          Text(
            text = "${if (isFa) "قیمت فعلی:" else "Current:"} ${coin.formattedPrice}",
            style = MaterialTheme.typography.labelSmall,
            color = TextSecondary
          )
        }
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Quick Presets
        Text(
          text = if (isFa) "اهداف درصدی سریع:" else "Quick target presets:",
          style = MaterialTheme.typography.bodySmall,
          color = TextMuted
        )

        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          val presets = listOf(+2.0, +5.0, +10.0, -2.0, -5.0, -10.0)
          items(presets) { p ->
            val calcPrice = coin.price * (1.0 + p / 100.0)
            FilterChip(
              selected = false,
              onClick = {
                targetPriceText = String.format(Locale.US, if (coin.price >= 1.0) "%.2f" else "%.6f", calcPrice)
                isAbove = p > 0
              },
              label = {
                Text(
                  text = String.format(Locale.US, "%+.0f%%", p),
                  fontSize = 11.sp,
                  color = if (p > 0) NeonEmerald else CrimsonRose
                )
              },
              colors = FilterChipDefaults.filterChipColors(
                containerColor = DarkSurfaceElevated,
                labelColor = TextPrimary
              ),
              border = FilterChipDefaults.filterChipBorder(
                enabled = true,
                selected = false,
                borderColor = DarkBorder
              )
            )
          }
        }

        // Direction Condition Chips
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(DarkSurfaceElevated)
            .padding(4.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Button(
            onClick = { isAbove = true },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (isAbove) NeonEmerald else DarkSurfaceCard,
              contentColor = if (isAbove) DarkBg else TextSecondary
            ),
            shape = RoundedCornerShape(8.dp)
          ) {
            Text(
              text = if (isFa) "صعود به بالای ≥" else "Rises Above ≥",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }

          Button(
            onClick = { isAbove = false },
            modifier = Modifier.weight(1f),
            colors = ButtonDefaults.buttonColors(
              containerColor = if (!isAbove) CrimsonRose else DarkSurfaceCard,
              contentColor = if (!isAbove) DarkBg else TextSecondary
            ),
            shape = RoundedCornerShape(8.dp)
          ) {
            Text(
              text = if (isFa) "افت به زیر ≤" else "Drops Below ≤",
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        // Target Price Field
        OutlinedTextField(
          value = targetPriceText,
          onValueChange = { targetPriceText = it },
          label = { Text(if (isFa) "قیمت هدف ($)" else "Target Price ($)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("target_price_input"),
          shape = RoundedCornerShape(10.dp),
          colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = NeonCyan,
            unfocusedBorderColor = DarkBorder,
            focusedContainerColor = DarkSurfaceCard,
            unfocusedContainerColor = DarkSurfaceCard,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          )
        )

        // Informational caption
        Text(
          text = if (isFa) {
            "به محض رسیدن قیمت به این عدد، اعلان بصری پاپ‌آپ و نوتیفیکیشن سیستم فعال خواهد شد."
          } else {
            "A visual pop-up HUD alert and system push notification will fire when the target is reached."
          },
          style = MaterialTheme.typography.bodySmall,
          color = TextMuted,
          fontSize = 11.sp
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          val parsed = targetPriceText.toDoubleOrNull()
          if (parsed != null && parsed > 0) {
            val alert = PriceAlert(
              id = existingAlert?.id ?: java.util.UUID.randomUUID().toString(),
              symbol = coin.symbol,
              coinName = coin.name,
              targetPrice = parsed,
              isAbove = isAbove,
              isActive = true,
              isTriggered = false
            )
            onSaveAlert(alert)
            onDismiss()
          }
        },
        colors = ButtonDefaults.buttonColors(
          containerColor = NeonCyan,
          contentColor = DarkBg
        ),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.testTag("save_alert_confirm_button")
      ) {
        Text(
          text = if (isFa) "فعال‌سازی هشدار" else "Save Alert",
          fontWeight = FontWeight.Bold
        )
      }
    },
    dismissButton = {
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (existingAlert != null) {
          OutlinedButton(
            onClick = {
              onDeleteAlert(existingAlert.id)
              onDismiss()
            },
            colors = ButtonDefaults.outlinedButtonColors(
              contentColor = CrimsonRose
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, CrimsonRose.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(10.dp)
          ) {
            Icon(Icons.Default.Delete, contentDescription = "Delete", modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text(if (isFa) "حذف" else "Delete")
          }
        }

        OutlinedButton(
          onClick = onDismiss,
          shape = RoundedCornerShape(10.dp),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
          border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
        ) {
          Text(if (isFa) "انصراف" else "Cancel")
        }
      }
    }
  )
}

package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import com.example.ui.theme.CrimsonRose
import com.example.ui.theme.NeonEmerald
import kotlin.math.max
import kotlin.math.min

@Composable
fun CanvasSparkline(
  prices: List<Double>,
  isPositive: Boolean,
  modifier: Modifier = Modifier,
  strokeWidth: Float = 4f,
  showGradientFill: Boolean = true
) {
  val lineColor = if (isPositive) NeonEmerald else CrimsonRose
  val fillGradient = Brush.verticalGradient(
    colors = listOf(
      lineColor.copy(alpha = 0.28f),
      lineColor.copy(alpha = 0.02f)
    )
  )

  Canvas(modifier = modifier.fillMaxSize()) {
    if (prices.size < 2) return@Canvas

    val width = size.width
    val height = size.height

    var minVal = prices.minOrNull() ?: 0.0
    var maxVal = prices.maxOrNull() ?: 1.0
    if (minVal == maxVal) {
      maxVal += 0.01
      minVal -= 0.01
    }

    val range = max(0.0000001, maxVal - minVal)
    val points = prices.mapIndexed { index, price ->
      val x = (index.toFloat() / (prices.size - 1).toFloat()) * width
      val y = height - (((price - minVal) / range).toFloat() * (height * 0.8f) + height * 0.1f)
      Offset(x, y)
    }

    // Build smooth curve path
    val linePath = Path().apply {
      moveTo(points.first().x, points.first().y)
      for (i in 0 until points.size - 1) {
        val current = points[i]
        val next = points[i + 1]
        val controlX = (current.x + next.x) / 2f
        cubicTo(
          controlX, current.y,
          controlX, next.y,
          next.x, next.y
        )
      }
    }

    // Draw gradient area underneath
    if (showGradientFill) {
      val fillPath = Path().apply {
        addPath(linePath)
        lineTo(width, height)
        lineTo(0f, height)
        close()
      }
      drawPath(path = fillPath, brush = fillGradient)
    }

    // Draw main sparkline
    drawPath(
      path = linePath,
      color = lineColor,
      style = Stroke(
        width = strokeWidth,
        cap = StrokeCap.Round,
        join = StrokeJoin.Round
      )
    )

    // Glow dot on last point
    val lastPoint = points.last()
    drawCircle(
      color = lineColor.copy(alpha = 0.35f),
      radius = strokeWidth * 2.5f,
      center = lastPoint
    )
    drawCircle(
      color = lineColor,
      radius = strokeWidth * 1.2f,
      center = lastPoint
    )
  }
}

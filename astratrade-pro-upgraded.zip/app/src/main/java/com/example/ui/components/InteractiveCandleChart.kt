package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CandleStick
import com.example.ui.theme.CrimsonRose
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextMuted
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

@Composable
fun InteractiveCandleChart(
  candles: List<CandleStick>,
  modifier: Modifier = Modifier,
  isLineMode: Boolean = false
) {
  var selectedIndex by remember { mutableStateOf<Int?>(null) }

  if (candles.isEmpty()) {
    Box(
      modifier = modifier
        .fillMaxWidth()
        .height(220.dp),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = "در حال بارگذاری داده‌های نمودار...",
        color = TextMuted,
        style = MaterialTheme.typography.bodyMedium
      )
    }
    return
  }

  val activeCandle = selectedIndex?.let { if (it in candles.indices) candles[it] else candles.last() } ?: candles.last()

  Box(
    modifier = modifier
      .fillMaxWidth()
      .height(240.dp)
  ) {
    // HUD overlay with selected candle details
    Text(
      text = String.format(
        Locale.US,
        "O: $%.2f  H: $%.2f  L: $%.2f  C: $%.2f  (%s)",
        activeCandle.open,
        activeCandle.high,
        activeCandle.low,
        activeCandle.close,
        activeCandle.time
      ),
      style = MaterialTheme.typography.labelSmall,
      color = if (activeCandle.isGreen) NeonEmerald else CrimsonRose,
      modifier = Modifier
        .align(Alignment.TopStart)
        .padding(horizontal = 8.dp, vertical = 4.dp)
    )

    Canvas(
      modifier = Modifier
        .fillMaxSize()
        .padding(top = 24.dp, bottom = 16.dp, end = 44.dp)
        .pointerInput(candles) {
          detectTapGestures(
            onPress = { offset ->
              val candleWidth = size.width / candles.size
              val index = (offset.x / candleWidth).toInt().coerceIn(0, candles.lastIndex)
              selectedIndex = index
            }
          )
        }
        .pointerInput(candles) {
          detectDragGestures(
            onDrag = { change, _ ->
              val candleWidth = size.width / candles.size
              val index = (change.position.x / candleWidth).toInt().coerceIn(0, candles.lastIndex)
              selectedIndex = index
            },
            onDragEnd = {
              // keep selection or clear
            }
          )
        }
    ) {
      val w = size.width
      val h = size.height
      val n = candles.size
      if (n == 0) return@Canvas

      val minPrice = candles.minOf { it.low } * 0.998
      val maxPrice = candles.maxOf { it.high } * 1.002
      val priceRange = max(0.000001, maxPrice - minPrice)
      val maxVol = max(1.0, candles.maxOf { it.volume })

      val candleSlotWidth = w / n
      val candleBodyWidth = max(2f, candleSlotWidth * 0.65f)

      // Draw horizontal grid lines (3 levels)
      for (i in 1..3) {
        val yGrid = h * (i / 4f)
        drawLine(
          color = DarkBorder.copy(alpha = 0.5f),
          start = Offset(0f, yGrid),
          end = Offset(w, yGrid),
          strokeWidth = 1f
        )
      }

      val points = mutableListOf<Offset>()

      candles.forEachIndexed { i, candle ->
        val xCenter = i * candleSlotWidth + (candleSlotWidth / 2f)

        val yOpen = h - (((candle.open - minPrice) / priceRange) * h).toFloat()
        val yClose = h - (((candle.close - minPrice) / priceRange) * h).toFloat()
        val yHigh = h - (((candle.high - minPrice) / priceRange) * h).toFloat()
        val yLow = h - (((candle.low - minPrice) / priceRange) * h).toFloat()

        val color = if (candle.isGreen) NeonEmerald else CrimsonRose

        // Volume bar at very bottom
        val volHeight = (candle.volume / maxVol).toFloat() * (h * 0.22f)
        drawRect(
          color = color.copy(alpha = 0.25f),
          topLeft = Offset(xCenter - (candleBodyWidth / 2f), h - volHeight),
          size = Size(candleBodyWidth, volHeight)
        )

        if (!isLineMode) {
          // Wick
          drawLine(
            color = color,
            start = Offset(xCenter, yHigh),
            end = Offset(xCenter, yLow),
            strokeWidth = 1.5f
          )

          // Body
          val top = min(yOpen, yClose)
          val bodyH = max(2f, kotlin.math.abs(yOpen - yClose))
          drawRect(
            color = color,
            topLeft = Offset(xCenter - (candleBodyWidth / 2f), top),
            size = Size(candleBodyWidth, bodyH)
          )
        }

        points.add(Offset(xCenter, yClose))
      }

      // If line mode or drawing EMA trendline
      if (isLineMode) {
        val linePath = Path().apply {
          moveTo(points.first().x, points.first().y)
          for (i in 1 until points.size) {
            lineTo(points[i].x, points[i].y)
          }
        }
        drawPath(
          path = linePath,
          color = NeonCyan,
          style = Stroke(width = 3f, cap = StrokeCap.Round)
        )
      }

      // Draw Scrub Crosshair if selected
      selectedIndex?.let { idx ->
        if (idx in points.indices) {
          val pt = points[idx]
          // Vertical crosshair line
          drawLine(
            color = Color.White.copy(alpha = 0.5f),
            start = Offset(pt.x, 0f),
            end = Offset(pt.x, h),
            strokeWidth = 1.5f
          )
          // Highlight circle
          drawCircle(
            color = NeonCyan,
            radius = 5f,
            center = pt
          )
        }
      }
    }
  }
}

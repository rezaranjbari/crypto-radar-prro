package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.NewsItem
import com.example.data.NewsRepository
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun NewsScreen(isFa: Boolean, modifier: Modifier = Modifier) {
  var news by remember { mutableStateOf<List<NewsItem>>(emptyList()) }; var loading by remember { mutableStateOf(true) }; val scope=rememberCoroutineScope()
  fun refresh(){ scope.launch { loading=true; news=NewsRepository.fetch(); loading=false } }
  LaunchedEffect(Unit){ refresh() }
  Column(modifier.fillMaxSize().background(DarkBg).padding(14.dp)) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){ Text(if(isFa) "اخبار بازار" else "Market News", style=MaterialTheme.typography.headlineMedium, color=TextPrimary); TextButton(onClick={refresh()}){Text(if(isFa)"به‌روزرسانی":"Refresh")}}
    if(loading) LinearProgressIndicator(Modifier.fillMaxWidth())
    LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp), contentPadding=PaddingValues(bottom=100.dp)) { items(news){ n -> Card(colors=CardDefaults.cardColors(containerColor=DarkSurfaceCard)){ Column(Modifier.padding(12.dp)){Text(n.title,color=TextPrimary);Text("${n.source} • ${n.publishedAt}",color=TextMuted,style=MaterialTheme.typography.bodySmall)}} } }
  }
}

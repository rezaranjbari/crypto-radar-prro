package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = NeonCyan,
  onPrimary = DarkBg,
  primaryContainer = DarkSurfaceElevated,
  onPrimaryContainer = NeonCyan,
  secondary = NeonEmerald,
  onSecondary = DarkBg,
  secondaryContainer = NeonEmeraldBg,
  onSecondaryContainer = NeonEmerald,
  tertiary = AmberGold,
  onTertiary = DarkBg,
  background = DarkBg,
  onBackground = TextPrimary,
  surface = DarkSurface,
  onSurface = TextPrimary,
  surfaceVariant = DarkSurfaceCard,
  onSurfaceVariant = TextSecondary,
  outline = DarkBorder,
  outlineVariant = DarkBorderSubtle,
  error = CrimsonRose,
  onError = Color.White
)

@Composable
fun AstraTradeTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = DarkColorScheme,
    typography = Typography,
    content = content
  )
}

package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MarketCoin
import com.example.model.SignalType
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CrimsonRose
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun SignalsRadarScreen(
  coins: List<MarketCoin>,
  onCoinClick: (MarketCoin) -> Unit,
  onSendToRiskCalc: (MarketCoin) -> Unit,
  isFa: Boolean = true,
  modifier: Modifier = Modifier
) {
  var selectedFilter by remember { mutableStateOf<SignalType?>(null) }

  val filteredCoins = if (selectedFilter == null) {
    coins
  } else {
    coins.filter { it.signal == selectedFilter }
  }

  LazyColumn(
    modifier = modifier
      .fillMaxSize()
      .background(DarkBg)
      .padding(horizontal = 14.dp),
    contentPadding = PaddingValues(top = 10.dp, bottom = 100.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    // Title
    item {
      Column(modifier = Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Radar, contentDescription = null, tint = NeonCyan, modifier = Modifier.size(24.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = if (isFa) "رادار اسکن هوشمند سیگنال‌ها" else "Smart Signals Radar",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
          )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = if (isFa) "شناسایی خودکار موقعیت‌های اشباع، شکست روند و الگوهای تکنیکال" else "Real-time algorithmic detection for RSI divergences and volume breakouts",
          style = MaterialTheme.typography.bodyMedium,
          color = TextSecondary
        )
      }
    }

    // Filter Chips for Signal Types
    item {
      LazyRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth()
      ) {
        item {
          FilterChip(
            selected = selectedFilter == null,
            onClick = { selectedFilter = null },
            label = { Text(if (isFa) "همه سیگنال‌ها" else "All Signals", fontSize = 12.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = NeonCyan,
              selectedLabelColor = DarkBg,
              containerColor = DarkSurfaceCard,
              labelColor = TextSecondary
            )
          )
        }
        items(SignalType.values()) { sig ->
          FilterChip(
            selected = selectedFilter == sig,
            onClick = { selectedFilter = sig },
            label = {
              Text(
                if (isFa) sig.titleFa else sig.titleEn,
                fontSize = 11.sp
              )
            },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = if (sig.isBullish) NeonEmerald else CrimsonRose,
              selectedLabelColor = DarkBg,
              containerColor = DarkSurfaceCard,
              labelColor = TextSecondary
            )
          )
        }
      }
    }

    // Signal Cards List
    items(filteredCoins) { coin ->
      val isBullish = coin.signal.isBullish
      val sigColor = if (isBullish) NeonEmerald else AmberGold
      val entry = coin.price
      val sl = if (isBullish) entry * 0.965 else entry * 1.035
      val tp = if (isBullish) entry * 1.075 else entry * 0.925

      Card(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .border(1.dp, DarkBorder, RoundedCornerShape(14.dp))
          .clickable { onCoinClick(coin) },
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard)
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          // Top Row: Coin Symbol & Signal Badge
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(NeonCyan.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
              ) {
                Text(
                  text = coin.symbol.take(4),
                  fontWeight = FontWeight.Bold,
                  color = NeonCyan,
                  style = MaterialTheme.typography.titleSmall
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Column {
                Text(
                  text = "${coin.symbol}/USDT",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
                Text(
                  text = coin.formattedPrice,
                  style = MaterialTheme.typography.labelSmall,
                  color = TextSecondary
                )
              }
            }

            // Signal Badge
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(sigColor.copy(alpha = 0.15f))
                .border(1.dp, sigColor.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = if (isBullish) Icons.Default.TrendingUp else Icons.Default.TrendingDown,
                  contentDescription = null,
                  tint = sigColor,
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (isFa) coin.signal.titleFa else coin.signal.titleEn,
                  style = MaterialTheme.typography.labelSmall,
                  color = sigColor,
                  fontWeight = FontWeight.Bold
                )
              }
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Parameters Row: Entry, StopLoss, Target
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(8.dp))
              .background(DarkSurfaceElevated)
              .padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text(text = if (isFa) "ورود پیشنهادی" else "Entry", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 10.sp)
              Text(text = String.format(Locale.US, "$%.4f", entry), style = MaterialTheme.typography.labelSmall, color = TextPrimary)
            }
            Column {
              Text(text = if (isFa) "حد ضرر (SL)" else "Stop Loss", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 10.sp)
              Text(text = String.format(Locale.US, "$%.4f", sl), style = MaterialTheme.typography.labelSmall, color = CrimsonRose)
            }
            Column {
              Text(text = if (isFa) "تارگت سود (TP)" else "Target TP", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 10.sp)
              Text(text = String.format(Locale.US, "$%.4f", tp), style = MaterialTheme.typography.labelSmall, color = NeonEmerald)
            }
            Column {
              Text(text = "RSI", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 10.sp)
              Text(text = String.format(Locale.US, "%.1f", coin.rsi), style = MaterialTheme.typography.labelSmall, color = NeonCyan)
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          // Button: Open in Risk Calculator
          Button(
            onClick = { onSendToRiskCalc(coin) },
            modifier = Modifier
              .fillMaxWidth()
              .height(40.dp)
              .testTag("radar_calc_btn_${coin.symbol.lowercase(Locale.ROOT)}"),
            colors = ButtonDefaults.buttonColors(
              containerColor = DarkSurfaceElevated,
              contentColor = NeonCyan
            ),
            border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(8.dp)
          ) {
            Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (isFa) "محاسبه اندازه پوزیشن در ماشین‌حساب ریسک" else "Open in Risk Calculator",
              style = MaterialTheme.typography.bodySmall,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }
  }
}

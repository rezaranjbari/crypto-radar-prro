package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.data.SmartTraderEngine
import com.example.model.MarketCoin
import com.example.ui.theme.*

@Composable
fun SmartBotScreen(coins: List<MarketCoin>, isFa: Boolean, modifier: Modifier = Modifier) {
  var selected by remember(coins) { mutableStateOf(coins.firstOrNull()?.symbol ?: "") }
  val coin = coins.firstOrNull { it.symbol == selected } ?: coins.firstOrNull()
  val decision = coin?.let { SmartTraderEngine.evaluate(it, isFa) }
  LazyColumn(modifier.fillMaxSize().background(DarkBg).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    item { Text(if (isFa) "ربات هوشمند معامله" else "Smart Trading Bot", style = MaterialTheme.typography.headlineMedium, color = TextPrimary) }
    item {
      if (coins.isNotEmpty()) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { coins.take(8).forEach { c -> FilterChip(selected=c.symbol==selected,onClick={selected=c.symbol},label={Text(c.symbol)}) } }
      } else Text(if (isFa) "داده زنده در دسترس نیست" else "Live data unavailable", color=TextSecondary)
    }
    decision?.let { d ->
      item { Card(colors=CardDefaults.cardColors(containerColor=DarkSurfaceCard), shape=RoundedCornerShape(16.dp)) { Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) { Text("${coin!!.symbol} • ${d.action}", style=MaterialTheme.typography.headlineSmall, color=NeonCyan); Text("Score: ${d.score}/100", color=TextPrimary); d.reasons.forEach { Text("• $it", color=TextSecondary) }; Text(d.invalidation, color=CrimsonRose); Text("Risk: ${d.risk}", color=AmberGold) } } }
    }
    item { Text(if (isFa) "این خروجی توصیه قطعی مالی نیست و فقط نتیجه مدل‌های برنامه است." else "This is not financial advice; it is the output of the app's models.", color=TextMuted, style=MaterialTheme.typography.bodySmall) }
  }
}

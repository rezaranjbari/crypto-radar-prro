package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.MarketCoin
import com.example.model.PriceAlert
import com.example.ui.theme.AmberGold
import com.example.ui.theme.CrimsonRose
import com.example.ui.theme.CrimsonRoseBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonEmeraldBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

@Composable
fun MarketCoinGridCard(
  coin: MarketCoin,
  activeAlert: PriceAlert? = null,
  onClick: () -> Unit = {},
  onToggleFavorite: () -> Unit = {},
  onToggleAlert: () -> Unit = {},
  isFa: Boolean = true,
  modifier: Modifier = Modifier
) {
  val isPositive = coin.change24h >= 0
  val changeColor = if (isPositive) NeonEmerald else CrimsonRose
  val changeBg = if (isPositive) NeonEmeraldBg else CrimsonRoseBg

  Card(
    modifier = modifier
      .fillMaxWidth()
      .testTag("coin_grid_card_${coin.symbol.lowercase(Locale.ROOT)}")
      .clip(RoundedCornerShape(16.dp))
      .clickable { onClick() }
      .border(
        width = if (activeAlert != null) 1.5.dp else 1.dp,
        color = if (activeAlert != null) NeonCyan.copy(alpha = 0.8f) else DarkBorder,
        shape = RoundedCornerShape(16.dp)
      ),
    colors = CardDefaults.cardColors(
      containerColor = DarkSurfaceCard
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
    ) {
      // Top row: Coin symbol badge, 24h change badge, Alert toggle and Favorite icon
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.weight(1f, fill = false)
        ) {
          Box(
            modifier = Modifier
              .size(34.dp)
              .clip(CircleShape)
              .background(NeonCyan.copy(alpha = 0.12f))
              .border(1.dp, NeonCyan.copy(alpha = 0.35f), CircleShape),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = coin.symbol.take(3),
              style = MaterialTheme.typography.labelLarge,
              fontWeight = FontWeight.Bold,
              color = NeonCyan
            )
          }
          Spacer(modifier = Modifier.width(6.dp))
          Column {
            Text(
              text = coin.symbol,
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
            Text(
              text = coin.name,
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary,
              fontSize = 10.sp,
              maxLines = 1
            )
          }
        }

        // Action icons: Alert Bell & Star
        Row(verticalAlignment = Alignment.CenterVertically) {
          // Alert Toggle Button
          IconButton(
            onClick = onToggleAlert,
            modifier = Modifier
              .size(28.dp)
              .testTag("alert_button_${coin.symbol.lowercase(Locale.ROOT)}")
          ) {
            Icon(
              imageVector = if (activeAlert != null) Icons.Default.NotificationsActive else Icons.Outlined.Notifications,
              contentDescription = "Price Alert",
              tint = if (activeAlert != null) NeonCyan else TextMuted,
              modifier = Modifier.size(18.dp)
            )
          }

          IconButton(
            onClick = onToggleFavorite,
            modifier = Modifier.size(28.dp)
          ) {
            Icon(
              imageVector = if (coin.isFavorite) Icons.Filled.Star else Icons.Outlined.StarBorder,
              contentDescription = "Favorite",
              tint = if (coin.isFavorite) AmberGold else TextMuted,
              modifier = Modifier.size(18.dp)
            )
          }
        }
      }

      // Active Alert Indicator (if set)
      if (activeAlert != null) {
        Spacer(modifier = Modifier.height(6.dp))
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(NeonCyan.copy(alpha = 0.12f))
            .border(1.dp, NeonCyan.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 3.dp)
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
          ) {
            Text(
              text = "🔔 ${if (isFa) "هشدار:" else "Alert:"} ${if (activeAlert.isAbove) "≥" else "≤"} ${activeAlert.formattedTargetPrice}",
              style = MaterialTheme.typography.labelSmall,
              color = NeonCyan,
              fontWeight = FontWeight.Bold,
              fontSize = 9.sp
            )
            Text(
              text = if (isFa) "فعال" else "Active",
              style = MaterialTheme.typography.labelSmall,
              color = NeonEmerald,
              fontSize = 8.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Price & 24h change pill
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
      ) {
        Text(
          text = coin.formattedPrice,
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          color = TextPrimary,
          fontSize = 17.sp
        )

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(changeBg)
            .padding(horizontal = 5.dp, vertical = 2.dp)
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = if (isPositive) Icons.Rounded.ArrowUpward else Icons.Rounded.ArrowDownward,
              contentDescription = null,
              tint = changeColor,
              modifier = Modifier.size(10.dp)
            )
            Spacer(modifier = Modifier.width(2.dp))
            Text(
              text = String.format(Locale.US, "%+.1f%%", coin.change24h),
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = changeColor,
              fontSize = 10.sp
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Prominent Visual Trend Sparkline Chart
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(52.dp)
          .clip(RoundedCornerShape(8.dp))
          .background(DarkSurfaceElevated.copy(alpha = 0.5f))
          .padding(horizontal = 4.dp, vertical = 2.dp)
      ) {
        CanvasSparkline(
          prices = coin.sparkline,
          isPositive = isPositive,
          strokeWidth = 3.5f,
          showGradientFill = true
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Bottom info: Volume & Signal
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = if (isFa) coin.signal.titleFa else coin.signal.titleEn,
          style = MaterialTheme.typography.labelSmall,
          color = if (coin.signal.isBullish) NeonEmerald else AmberGold,
          fontSize = 9.sp,
          maxLines = 1,
          modifier = Modifier.weight(1f, fill = false)
        )

        Text(
          text = "${if (isFa) "حجم:" else "Vol:"} ${coin.formattedVolume}",
          style = MaterialTheme.typography.labelSmall,
          color = TextMuted,
          fontSize = 9.sp
        )
      }
    }
  }
}

package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AstraTrade Pro Dark Luxury FinTech Palette
val DarkBg = Color(0xFF0A0E17)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceElevated = Color(0xFF182234)
val DarkSurfaceCard = Color(0xFF141D2D)
val DarkBorder = Color(0xFF223049)
val DarkBorderSubtle = Color(0xFF1A263B)

// Accents & Signals
val NeonCyan = Color(0xFF00E5FF)
val NeonEmerald = Color(0xFF00E676)
val NeonEmeraldBg = Color(0x1A00E676)
val CrimsonRose = Color(0xFFFF3366)
val CrimsonRoseBg = Color(0x1AFF3366)
val AmberGold = Color(0xFFFFB300)
val AmberGoldBg = Color(0x1AFFB300)
val ElectricViolet = Color(0xFF7C4DFF)

// Text
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Brand Gradients
val PrimaryGradStart = Color(0xFF00E5FF)
val PrimaryGradEnd = Color(0xFF7C4DFF)

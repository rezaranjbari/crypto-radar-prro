package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Radar
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.MarketRepository
import com.example.data.LocalStore
import com.example.model.MarketCoin
import com.example.model.MarketOverview
import com.example.model.PriceAlert
import com.example.model.SavedTradeSetup
import com.example.ui.components.CoinDetailSheet
import com.example.ui.components.SetPriceAlertDialog
import com.example.ui.components.VisualAlertBanner
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.JournalScreen
import com.example.ui.screens.RiskManagerScreen
import com.example.ui.screens.SignalsRadarScreen
import com.example.ui.screens.SmartBotScreen
import com.example.ui.screens.NewsScreen
import com.example.ui.theme.AstraTradeTheme
import com.example.ui.theme.DarkBg
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.util.NotificationHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AppTab(val titleFa: String, val titleEn: String, val icon: ImageVector) {
  MARKET("بازار", "Market", Icons.Default.ShowChart),
  RISK("مدیریت ریسک", "Risk Engine", Icons.Default.Calculate),
  RADAR("رادار سیگنال", "Radar", Icons.Default.Radar),
  JOURNAL("دفترچه", "Journal", Icons.Default.Book),
  BOT("ربات هوشمند", "Smart Bot", Icons.Default.AutoAwesome),
  NEWS("اخبار", "News", Icons.Default.Newspaper)
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      AstraTradeTheme {
        AstraTradeApp()
      }
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AstraTradeApp() {
  val context = LocalContext.current
  var coins by remember { mutableStateOf<List<MarketCoin>>(emptyList()) }
  var overview by remember { mutableStateOf(MarketOverview()) }
  var loading by remember { mutableStateOf(false) }
  var error by remember { mutableStateOf<String?>(null) }
  var isFa by remember { mutableStateOf(true) }

  var currentTab by remember { mutableStateOf(AppTab.MARKET) }
  var selectedCoinForDetail by remember { mutableStateOf<MarketCoin?>(null) }
  var prefilledCoinForRisk by remember { mutableStateOf<MarketCoin?>(null) }
  var savedSetups by remember { mutableStateOf<List<SavedTradeSetup>>(emptyList()) }

  // Price Alert states
  var priceAlerts by remember { mutableStateOf<Map<String, PriceAlert>>(emptyMap()) }
  var coinForSettingAlert by remember { mutableStateOf<MarketCoin?>(null) }
  var activeTriggeredAlert by remember { mutableStateOf<Pair<PriceAlert, MarketCoin>?>(null) }

  // Permission Launcher for Android 13+ Notifications
  val notificationPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { _ -> }

  val coroutineScope = rememberCoroutineScope()

  // Function to inspect and trigger price alerts
  fun checkPriceAlerts(currentCoins: List<MarketCoin>) {
    priceAlerts.values.forEach { alert ->
      if (alert.isActive && !alert.isTriggered) {
        val coin = currentCoins.find { it.symbol == alert.symbol }
        if (coin != null) {
          val isReached = if (alert.isAbove) {
            coin.price >= alert.targetPrice
          } else {
            coin.price <= alert.targetPrice
          }

          if (isReached) {
            // Trigger system notification
            NotificationHelper.sendPriceAlertNotification(context, coin, alert, isFa)
            // Trigger in-app visual HUD banner
            activeTriggeredAlert = Pair(alert, coin)
            // Mark as triggered
            priceAlerts = priceAlerts + (alert.symbol to alert.copy(isTriggered = true))
          }
        }
      }
    }
  }

  suspend fun loadMarket(isManual: Boolean = false) {
    if (isManual) loading = true
    error = null
    try {
      val result = MarketRepository.fetchTopCoins()
      coins = result
      overview = MarketRepository.getMarketOverview(result)
      checkPriceAlerts(result)
    } catch (e: Exception) {
      error = e.message ?: (if (isFa) "خطا در دریافت اطلاعات بازار" else "Error fetching market data")
    } finally {
      if (isManual) loading = false
    }
  }

  // Initial load + periodic gentle ticker updates every 8 seconds
  LaunchedEffect(Unit) {
    NotificationHelper.createNotificationChannel(context)
    savedSetups = LocalStore.loadJournal(context)
    priceAlerts = LocalStore.loadAlerts(context)
    MarketRepository.applyFavorites(LocalStore.loadWatchlist(context))
    val settings = LocalStore.loadSettings(context)
    isFa = !settings.contains("\"language\":\"en\"")
    loadMarket(isManual = true)
    while (true) {
      delay(8000)
      loadMarket(isManual = false)
    }
  }

  // Handle hardware back button to navigate back to Home if in another tab
  BackHandler(enabled = currentTab != AppTab.MARKET || selectedCoinForDetail != null || coinForSettingAlert != null) {
    if (coinForSettingAlert != null) {
      coinForSettingAlert = null
    } else if (selectedCoinForDetail != null) {
      selectedCoinForDetail = null
    } else {
      currentTab = AppTab.MARKET
    }
  }

  Scaffold(
    containerColor = DarkBg,
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(NeonCyan.copy(alpha = 0.15f))
                .border(1.dp, NeonCyan, CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Text(
                text = "⚡",
                fontSize = 14.sp
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = "AstraTrade Pro",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(NeonEmerald)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                  text = if (isFa) "بازار آنلاین • زنده" else "LIVE MARKET ACTIVE",
                  style = MaterialTheme.typography.labelSmall,
                  color = NeonEmerald,
                  fontSize = 9.sp
                )
              }
            }
          }
        },
        actions = {
          // Language switcher button (🇮🇷 FA / 🇬🇧 EN)
          IconButton(
            onClick = { isFa = !isFa; coroutineScope.launch { LocalStore.saveSettings(context, if (isFa) "{\"language\":\"fa\"}" else "{\"language\":\"en\"}") } },
            modifier = Modifier.testTag("language_toggle_button")
          ) {
            Box(
              modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(DarkSurfaceElevated)
                .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
              Text(
                text = if (isFa) "FA 🇮🇷" else "EN 🇬🇧",
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = NeonCyan
              )
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = DarkSurface,
          titleContentColor = TextPrimary
        )
      )
    },
    bottomBar = {
      NavigationBar(
        modifier = Modifier
          .border(1.dp, DarkBorder, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
          .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)),
        containerColor = DarkSurface,
        windowInsets = WindowInsets.navigationBars
      ) {
        AppTab.values().forEach { tab ->
          val selected = currentTab == tab
          NavigationBarItem(
            selected = selected,
            onClick = { currentTab = tab },
            icon = {
              if (tab == AppTab.JOURNAL && savedSetups.isNotEmpty()) {
                BadgedBox(
                  badge = {
                    Badge(
                      containerColor = NeonCyan,
                      contentColor = DarkBg
                    ) {
                      Text("${savedSetups.size}")
                    }
                  }
                ) {
                  Icon(tab.icon, contentDescription = tab.name)
                }
              } else {
                Icon(tab.icon, contentDescription = tab.name)
              }
            },
            label = {
              Text(
                text = if (isFa) tab.titleFa else tab.titleEn,
                fontSize = 11.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
              )
            },
            colors = NavigationBarItemDefaults.colors(
              selectedIconColor = DarkBg,
              selectedTextColor = NeonCyan,
              indicatorColor = NeonCyan,
              unselectedIconColor = TextMuted,
              unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("tab_${tab.name.lowercase()}")
          )
        }
      }
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      Column(modifier = Modifier.fillMaxSize()) {
        // Visual in-app Alert Banner (appears animated at the top when price target is reached!)
        VisualAlertBanner(
          alert = activeTriggeredAlert?.first,
          coin = activeTriggeredAlert?.second,
          onDismiss = { activeTriggeredAlert = null },
          onClick = { coin ->
            selectedCoinForDetail = coin
            activeTriggeredAlert = null
          },
          isFa = isFa
        )

        Box(modifier = Modifier.weight(1f)) {
          when (currentTab) {
            AppTab.MARKET -> {
              HomeScreen(
                coins = coins,
                overview = overview,
                loading = loading,
                errorMessage = error,
                onRefresh = {
                  coroutineScope.launch {
                    loadMarket(isManual = true)
                  }
                },
                onCoinClick = { coin ->
                  selectedCoinForDetail = coin
                },
                onToggleFavorite = { coin ->
                  coins = coins.map { if (it.symbol == coin.symbol) it.copy(isFavorite = !it.isFavorite) else it }
                  coroutineScope.launch { LocalStore.saveWatchlist(context, coins.filter { it.isFavorite }.map { it.symbol }.toSet()) }
                },
                priceAlerts = priceAlerts,
                onToggleAlert = { coin ->
                  // Request notification permission if needed
                  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                      notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                  }
                  coinForSettingAlert = coin
                },
                isFa = isFa
              )
            }

            AppTab.RISK -> {
              RiskManagerScreen(
                coins = coins,
                prefilledCoin = prefilledCoinForRisk,
                onSaveSetup = { setup ->
                  savedSetups = listOf(setup) + savedSetups
                  coroutineScope.launch { LocalStore.saveJournal(context, savedSetups) }
                },
                isFa = isFa
              )
            }

            AppTab.RADAR -> {
              SignalsRadarScreen(
                coins = coins,
                onCoinClick = { coin ->
                  selectedCoinForDetail = coin
                },
                onSendToRiskCalc = { coin ->
                  prefilledCoinForRisk = coin
                  currentTab = AppTab.RISK
                },
                isFa = isFa
              )
            }

            AppTab.JOURNAL -> {
              JournalScreen(
                savedSetups = savedSetups,
                onDeleteSetup = { setupId ->
                  savedSetups = savedSetups.filterNot { it.id == setupId }
                  coroutineScope.launch { LocalStore.saveJournal(context, savedSetups) }
                },
                isFa = isFa
              )
            }

            AppTab.BOT -> SmartBotScreen(coins = coins, isFa = isFa)
            AppTab.NEWS -> NewsScreen(isFa = isFa)
          }
        }
      }

      // Coin Detail Bottom Sheet (when coin is tapped)
      selectedCoinForDetail?.let { coin ->
        CoinDetailSheet(
          coin = coin,
          activeAlert = priceAlerts[coin.symbol],
          onDismiss = { selectedCoinForDetail = null },
          onSendToRiskCalculator = { c ->
            prefilledCoinForRisk = c
            currentTab = AppTab.RISK
          },
          onSetAlert = { c ->
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
              if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
              }
            }
            coinForSettingAlert = c
          },
          isFa = isFa
        )
      }

      // Price Alert Setup Dialog (when alert bell icon is clicked)
      coinForSettingAlert?.let { coin ->
        SetPriceAlertDialog(
          coin = coin,
          existingAlert = priceAlerts[coin.symbol],
          onDismiss = { coinForSettingAlert = null },
          onSaveAlert = { newAlert ->
            priceAlerts = priceAlerts + (coin.symbol to newAlert)
            coroutineScope.launch { LocalStore.saveAlerts(context, priceAlerts) }
            coinForSettingAlert = null
          },
          onDeleteAlert = { _ ->
            priceAlerts = priceAlerts - coin.symbol
            coroutineScope.launch { LocalStore.saveAlerts(context, priceAlerts) }
            coinForSettingAlert = null
          },
          isFa = isFa
        )
      }
    }
  }
}

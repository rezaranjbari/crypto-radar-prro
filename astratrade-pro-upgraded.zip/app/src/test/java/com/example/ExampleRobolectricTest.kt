package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("AstraTrade Pro", appName)
  }

  @Test
  fun `test risk calculation logic`() {
    val result = com.example.data.MarketRepository.calculateRisk(
      accountBalance = 10000.0,
      riskPercentage = 2.0,
      entryPrice = 60000.0,
      stopLossPrice = 57000.0,
      takeProfit1 = 66000.0,
      takeProfit2 = 72000.0,
      isLong = true,
      leverage = 5
    )
    // 2% of $10,000 = $200 risk
    assertEquals(200.0, result.riskAmountDollars, 0.01)
    // 5% stop distance -> position size = 200 / 0.05 = $4000
    assertEquals(4000.0, result.positionSizeDollars, 0.01)
    // 10% gain on $4000 = $400 profit -> R:R = 400 / 200 = 2.0
    assertEquals(2.0, result.riskRewardRatioTp1, 0.01)
  }

  @Test
  fun `test price alert model and triggers`() {
    val alert = com.example.model.PriceAlert(
      symbol = "BTC",
      coinName = "Bitcoin",
      targetPrice = 70000.0,
      isAbove = true
    )
    val priceBelow = 69500.0
    val priceAbove = 70100.0

    val isTriggeredBefore = alert.isAbove && priceBelow >= alert.targetPrice
    val isTriggeredAfter = alert.isAbove && priceAbove >= alert.targetPrice

    org.junit.Assert.assertFalse(isTriggeredBefore)
    org.junit.Assert.assertTrue(isTriggeredAfter)
    assertEquals("$70,000.00", alert.formattedTargetPrice)
  }
}

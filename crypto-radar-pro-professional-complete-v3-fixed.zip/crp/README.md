# Crypto Radar Pro

A Persian/English Android crypto market-analysis application focused on multi-source market data, technical analysis, opportunity scanning, market routing, derivatives, Iranian exchange quotes, news, watchlists and persistent price alerts.

## Included capabilities

- Multi-source spot market data: Binance, CoinGecko and CoinCap
- OHLCV candlestick charts with volume
- Technical indicators and multi-timeframe analysis
- Market structure, breakout/fake-breakout and support/resistance analysis
- Opportunity scanner with strategy/timeframe filters
- Market Navigator with regime, direction, confidence, catalysts and invalidation
- Derivatives data: Open Interest, funding and large-trade buy/sell pressure
- Iranian USDT market quotes: Nobitex, Wallex and Bitpin
- Cross-source price discrepancy checks
- Crypto news aggregation with source attribution and timestamps
- Persian RTL and English LTR UI
- Local Room cache for offline fallback
- Watchlist, scan history and trading journal persistence
- Persistent price alerts with Android notifications and background WorkManager checks
- Safe Room migration for the alert schema
- Unit-test stage in CI
- GitHub Actions workflow that correctly builds the nested `crp` Android project and uploads the APK artifact

## Build with GitHub Actions

1. Push the repository to GitHub.
2. Open **Actions**.
3. Select **Build Crypto Radar Pro APK**.
4. Choose **Run workflow**.
5. Download the artifact named `crypto-radar-pro-debug-apk` after the run succeeds.

The workflow deliberately builds from the `crp` project directory, so the previous `gradlew not found` / `Android Gradle project not found` failure caused by the nested ZIP layout is avoided.

## Important data policy

The application does not invent market, on-chain or macro values. If a provider is unavailable, the app uses real cached observations where possible and displays unavailable data rather than fabricating values.


## Build hardening
- Binance kline responses are parsed as raw JSON arrays with field validation; no `List<Any>` Retrofit/Moshi adapter is used.
- News source fan-out uses explicit coroutine result types to prevent Kotlin type-inference failures.
- RSS responses are always closed and invalid publication dates are rejected instead of being replaced with the current time.
- Network cleartext traffic is disabled at the Android application layer.
- CI runs an explicit Kotlin compilation gate before assembling the debug APK.

## Quality upgrade 1.1.0

- Added a conservative multi-layer Market Intelligence engine with LONG / SHORT / WAIT / NO TRADE states.
- Added explicit data-quality scoring, freshness checks, source-count awareness and warnings.
- Added transparent score components for trend, momentum, volume, structure, derivatives and risk.
- Added an in-app decision card with entry/SL/TP when a setup passes safety checks.
- Scanner candle requests now use bounded concurrency to reduce API bursts and improve refresh performance.
- Scanner history uses up to 250 candles, making longer EMA context less fragile than a 40-candle sample.
- MACD signal is calculated from an actual MACD series instead of a fixed approximation.
- 15m trend can now be neutral rather than incorrectly defaulting to bearish.
- Backtest now accounts for configurable fees/slippage and exposes profit factor and expectancy.
- Multi-source timestamps are no longer fabricated when a provider did not return data.
- CI now checks for likely hard-coded secrets before tests/build.

### Deliberate limitations

The project does not fabricate Top Trader, on-chain, macro-calendar or wallet data. Those modules should only be activated when a real provider/backend is connected. No exchange private keys are shipped in the APK, and this release does not execute real trades automatically.


## Professional Complete v1.2.0

Added a provider-independent professional intelligence layer: regime classification, position sizing, portfolio analytics, strategy robustness, signal calibration, screener contracts, trade safety vetoes, news intelligence, provider health/capability registry, and explicit status handling for on-chain, liquidations, smart-money, top-trader, unlock and macro feeds. Provider-dependent data is never fabricated.

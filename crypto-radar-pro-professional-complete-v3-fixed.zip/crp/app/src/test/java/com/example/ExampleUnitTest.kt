package com.example

import com.example.data.analysis.MarketIntelligenceEngine
import com.example.data.model.Candle
import com.example.data.model.DecisionAction
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun intelligenceRefusesInsufficientData() {
        val candles = (0 until 5).map { i ->
            Candle(i * 3_600_000L, 100.0, 101.0, 99.0, 100.0, 1000.0)
        }
        val result = MarketIntelligenceEngine.analyze("TEST", candles)
        assertEquals(DecisionAction.NO_TRADE, result.action)
        assertTrue(result.dataQuality.score < 100)
    }

    @Test
    fun intelligenceProducesBoundedConfidence() {
        val candles = (0 until 80).map { i ->
            val close = 100.0 + i * 0.8
            Candle(i * 3_600_000L, close - 0.3, close + 1.0, close - 1.0, close, 1000.0 + i * 10)
        }
        val result = MarketIntelligenceEngine.analyze("TEST", candles, sourceCount = 2, nowMs = candles.last().timestamp)
        assertTrue(result.confidence in 0..95)
        assertTrue(result.score in 0..100)
    }
}

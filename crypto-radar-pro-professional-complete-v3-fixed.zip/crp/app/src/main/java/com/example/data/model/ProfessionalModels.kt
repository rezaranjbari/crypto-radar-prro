package com.example.data.model

/** Professional analytics are evidence-driven. Missing external feeds remain unavailable. */
data class AnalyticsEvidence(val name: String, val score: Int?, val status: String, val reason: String)

data class Scenario(
    val name: String,
    val probability: Int,
    val trigger: String,
    val invalidation: String,
    val target: Double?
)

data class AnomalySignal(val type: String, val severity: Int, val value: Double, val baseline: Double, val explanation: String)

data class RelativeStrengthSnapshot(
    val vsBtc: Double?, val vsEth: Double?, val vsMarket: Double?, val vsSector: Double?,
    val rank: Int? = null
)

data class LiquidityZone(val price: Double, val strength: Int, val kind: String)

data class OrderFlowSnapshot(
    val buyVolume: Double? = null, val sellVolume: Double? = null, val delta: Double? = null,
    val largeBuyVolume: Double? = null, val largeSellVolume: Double? = null,
    val imbalance: Double? = null, val source: String = "Unavailable"
)

data class TraderProfile(
    val id: String, val name: String, val source: String,
    val roi: Double?, val winRate: Double?, val maxDrawdown: Double?, val tradeCount: Int?,
    val riskScore: Int?, val selectedSymbols: List<String> = emptyList(), val publicPositions: List<String> = emptyList()
)

data class TraderConsensus(
    val symbol: String, val longWeight: Double, val shortWeight: Double,
    val neutralWeight: Double, val participants: Int, val confidence: Int,
    val supportingTraders: List<String> = emptyList(), val opposingTraders: List<String> = emptyList(),
    val status: String = "Unavailable without public trader feed"
)

data class PortfolioPosition(val symbol: String, val valueUsd: Double, val pnlPercent: Double, val sector: String? = null)
data class PortfolioRiskSnapshot(
    val totalValueUsd: Double, val concentrationPercent: Double, val largestPosition: String?,
    val estimatedVolatility: Double, val maxCorrelation: Double, val riskLevel: String,
    val warnings: List<String> = emptyList()
)

data class StrategyRule(val name: String, val enabled: Boolean, val description: String)
data class StrategyTestResult(
    val trades: Int, val winRate: Double, val profitFactor: Double, val expectancy: Double,
    val totalReturnPercent: Double, val maxDrawdownPercent: Double, val feesPercent: Double,
    val slippagePercent: Double, val outOfSample: Boolean, val warnings: List<String> = emptyList()
)

data class SignalOutcome(val id: String, val symbol: String, val action: DecisionAction, val createdAt: Long, val entry: Double, val target: Double?, val stop: Double?, val resolved: Boolean = false, val success: Boolean? = null)
data class SignalTrackRecord(val total: Int, val resolved: Int, val successful: Int, val winRate: Double, val avgR: Double, val warnings: List<String> = emptyList())

data class AIDecisionPlan(
    val action: DecisionAction, val confidence: Int, val thesis: String,
    val entryMin: Double?, val entryMax: Double?, val stopLoss: Double?,
    val takeProfit1: Double?, val takeProfit2: Double?, val riskReward: Double?,
    val safetyVeto: Boolean, val vetoReasons: List<String> = emptyList()
)

data class CorrelationSnapshot(val symbols: List<String>, val matrix: List<List<Double>>, val warnings: List<String> = emptyList())

data class ProfessionalAnalyticsSnapshot(
    val marketRegime: String,
    val marketScore: Int,
    val evidences: List<AnalyticsEvidence>,
    val scenarios: List<Scenario>,
    val anomalies: List<AnomalySignal>,
    val relativeStrength: RelativeStrengthSnapshot,
    val liquidityZones: List<LiquidityZone>,
    val orderFlow: OrderFlowSnapshot,
    val traderConsensus: TraderConsensus,
    val portfolioRisk: PortfolioRiskSnapshot? = null,
    val strategyResult: StrategyTestResult? = null,
    val signalTrackRecord: SignalTrackRecord? = null,
    val aiDecision: AIDecisionPlan? = null,
    val correlation: CorrelationSnapshot? = null,
    val professionalFeatures: ProfessionalFeatureSnapshot? = null,
    val dataQuality: DataQuality,
    val unavailableFeeds: List<String> = emptyList(),
    val generatedAt: Long = System.currentTimeMillis()
)

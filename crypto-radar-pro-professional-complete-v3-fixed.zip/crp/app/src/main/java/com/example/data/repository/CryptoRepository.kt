package com.example.data.repository

import com.example.data.analysis.TechnicalAnalysisEngine
import com.example.data.local.AppDatabase
import com.example.data.local.CachedMarketEntity
import com.example.data.local.ScanHistoryEntity
import com.example.data.local.WatchlistEntity
import com.example.data.model.Candle
import com.example.data.model.CryptoAsset
import com.example.data.model.CryptoNewsItem
import com.example.data.model.MarketOverviewData
import com.example.data.model.MultiSourcePrice
import com.example.data.model.RadarOpportunity
import com.example.data.model.RadarSignalType
import com.example.data.remote.NetworkClient
import com.example.data.remote.NewsAggregator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class CryptoRepository(
    private val database: AppDatabase
) {
    private val watchlistDao = database.watchlistDao()
    private val cachedMarketDao = database.cachedMarketDao()
    private val scanHistoryDao = database.scanHistoryDao()

    val watchlistFlow: Flow<List<WatchlistEntity>> = watchlistDao.getAllWatchlist()
    val scanHistoryFlow: Flow<List<ScanHistoryEntity>> = scanHistoryDao.getHistory()

    // Persian Name Mapping for standard cryptocurrencies
    private val persianNames = mapOf(
        "BTC" to "بیت‌کوین",
        "ETH" to "اتریوم",
        "SOL" to "سولانا",
        "BNB" to "بایننس کوین",
        "XRP" to "ریپل",
        "DOGE" to "دوج‌کوین",
        "ADA" to "کاردانو",
        "AVAX" to "اوَلانچ",
        "LINK" to "چین‌لینک",
        "SUI" to "سویی",
        "NEAR" to "نیر پروتکل",
        "APT" to "آپتوس",
        "DOT" to "پولکادات",
        "PEPE" to "پپه",
        "RENDER" to "رندر توکن",
        "FET" to "هوش مصنوعی فچ",
        "INJ" to "اینجکتیو",
        "TIA" to "سلستیا",
        "ARB" to "آربیتروم",
        "OP" to "اپتیمیزم",
        "KAS" to "کاسپا",
        "POL" to "پالیگان",
        "STX" to "استکس",
        "AAVE" to "آوه",
        "LDO" to "لیدو دائو",
        "SHIB" to "شیبا اینو",
        "UNI" to "یونی‌سواپ",
        "LTC" to "لایت‌کوین",
        "BCH" to "بیت‌کوین کش",
        "ATOM" to "کازماس"
    )

    suspend fun getWatchlist(): Flow<List<WatchlistEntity>> = watchlistFlow

    suspend fun addToWatchlist(symbol: String, name: String, nameFa: String, note: String = "") {
        withContext(Dispatchers.IO) {
            watchlistDao.insert(
                WatchlistEntity(
                    symbol = symbol.uppercase(),
                    name = name,
                    nameFa = nameFa,
                    note = note
                )
            )
        }
    }

    suspend fun removeFromWatchlist(symbol: String) {
        withContext(Dispatchers.IO) {
            watchlistDao.deleteBySymbol(symbol.uppercase())
        }
    }

    fun isWatchlisted(symbol: String): Flow<Boolean> {
        return watchlistDao.isWatchlisted(symbol.uppercase())
    }

    /**
     * Retrieves market assets concurrently from CoinGecko, Binance, and CoinCap.
     * Caches successful data locally in Room for offline access.
     */
    suspend fun fetchMarketAssets(): List<CryptoAsset> = withContext(Dispatchers.IO) {
        try {
            coroutineScope {
                val geckoDeferred = async {
                    runCatching { NetworkClient.coinGecko.getMarkets(perPage = 60) }.getOrNull()
                }
                val binanceDeferred = async {
                    runCatching {
                        NetworkClient.binance.get24hTickers()
                    }.recoverCatching {
                        NetworkClient.binancePrimary.get24hTickers()
                    }.getOrNull()
                }

                val geckoList = geckoDeferred.await()
                val binanceList = binanceDeferred.await()

                val binanceMap = binanceList?.associateBy { it.symbol } ?: emptyMap()

                if (!geckoList.isNullOrEmpty()) {
                    val assets = geckoList.map { dto ->
                        val sym = dto.symbol.uppercase()
                        val pair = "${sym}USDT"
                        val binanceTicker = binanceMap[pair]

                        // If Binance has exchange price, compare or use it
                        val binancePrice = binanceTicker?.lastPrice?.toDoubleOrNull()
                        val price = binancePrice ?: dto.currentPrice ?: 0.0
                        val change24h = binanceTicker?.priceChangePercent?.toDoubleOrNull()
                            ?: dto.priceChangePercentage24h
                            ?: 0.0

                        CryptoAsset(
                            symbol = sym,
                            name = dto.name,
                            nameFa = persianNames[sym] ?: dto.name,
                            priceUsd = price,
                            change24h = change24h,
                            high24h = dto.high24h ?: (price * 1.05),
                            low24h = dto.low24h ?: (price * 0.95),
                            volume24hUsd = dto.totalVolume ?: 0.0,
                            marketCapUsd = dto.marketCap ?: 0.0,
                            marketCapRank = dto.marketCapRank ?: 99,
                            sparkline7d = dto.sparklineIn7d?.price ?: emptyList(),
                            tradingPair = pair,
                            primarySource = if (binanceTicker != null) "بایننس و کوین‌گکو" else "کوین‌گکو",
                            lastUpdateTimestamp = System.currentTimeMillis()
                        )
                    }

                    // Save to local Room cache
                    saveToCache(assets)
                    return@coroutineScope assets
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Offline mode uses only previously cached real observations.
        loadFromCacheOrCurated()
    }

    private suspend fun saveToCache(assets: List<CryptoAsset>) {
        try {
            val entities = assets.map {
                CachedMarketEntity(
                    symbol = it.symbol,
                    name = it.name,
                    nameFa = it.nameFa,
                    priceUsd = it.priceUsd,
                    change24h = it.change24h,
                    high24h = it.high24h,
                    low24h = it.low24h,
                    volume24hUsd = it.volume24hUsd,
                    marketCapUsd = it.marketCapUsd,
                    marketCapRank = it.marketCapRank,
                    sparklineJson = it.sparkline7d.joinToString(","),
                    lastUpdated = System.currentTimeMillis()
                )
            }
            cachedMarketDao.insertAll(entities)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private suspend fun loadFromCacheOrCurated(): List<CryptoAsset> {
        return runCatching {
            cachedMarketDao.getAllCachedAssets().first().map {
                CryptoAsset(
                    symbol = it.symbol, name = it.name, nameFa = it.nameFa, priceUsd = it.priceUsd,
                    change24h = it.change24h, high24h = it.high24h, low24h = it.low24h,
                    volume24hUsd = it.volume24hUsd, marketCapUsd = it.marketCapUsd, marketCapRank = it.marketCapRank,
                    sparkline7d = it.sparklineJson.split(',').mapNotNull { value -> value.toDoubleOrNull() }
                )
            }
        }.getOrDefault(emptyList())
    }

    /**
     * Cross-verifies prices from Binance, CoinGecko, and CoinCap.
     * Flags discrepancies > 1.5% and checks source health.
     */
    suspend fun getMultiSourcePrice(asset: CryptoAsset): MultiSourcePrice = withContext(Dispatchers.IO) {
        val sym = asset.symbol.uppercase()
        val pair = "${sym}USDT"

        var binancePrice: Double? = null
        var binanceChange: Double? = null
        var geckoPrice: Double? = null
        var geckoChange: Double? = null
        var coincapPrice: Double? = null
        var coincapChange: Double? = null
        val fetchedAt = System.currentTimeMillis()

        coroutineScope {
            val bJob = async {
                runCatching {
                    val tickers = NetworkClient.binance.get24hTickers()
                    tickers.firstOrNull { it.symbol == pair }?.let {
                        binancePrice = it.lastPrice?.toDoubleOrNull()
                        binanceChange = it.priceChangePercent?.toDoubleOrNull()
                    }
                }
            }
            val cJob = async {
                runCatching {
                    val cap = NetworkClient.coinCap.getAssets(60)
                    cap.data?.firstOrNull { it.symbol.equals(sym, ignoreCase = true) }?.let {
                        coincapPrice = it.priceUsd?.toDoubleOrNull()
                        coincapChange = it.changePercent24Hr?.toDoubleOrNull()
                    }
                }
            }
            bJob.await()
            cJob.await()
        }

        geckoPrice = asset.priceUsd
        geckoChange = asset.change24h

        val prices = listOfNotNull(binancePrice, geckoPrice, coincapPrice)
        val activeCount = prices.size

        var maxDiffPercent = 0.0
        if (prices.size >= 2) {
            val minP = prices.minOrNull() ?: 1.0
            val maxP = prices.maxOrNull() ?: 1.0
            if (minP > 0) {
                maxDiffPercent = ((maxP - minP) / minP) * 100.0
            }
        }

        MultiSourcePrice(
            symbol = sym,
            binancePrice = binancePrice ?: asset.priceUsd,
            binanceChange24h = binanceChange ?: asset.change24h,
            binanceTimestamp = binancePrice?.let { fetchedAt },
            coingeckoPrice = geckoPrice,
            coingeckoChange24h = geckoChange,
            coingeckoTimestamp = geckoPrice?.let { asset.lastUpdateTimestamp },
            coincapPrice = coincapPrice,
            coincapChange24h = coincapChange ?: asset.change24h,
            coincapTimestamp = coincapPrice?.let { fetchedAt },
            discrepancyPercent = maxDiffPercent,
            hasDiscrepancyWarning = maxDiffPercent > 1.5,
            activeSourceCount = activeCount
        )
    }

    /**
     * Retrieves historical candle data for an asset.
     * Uses Binance klines if available, or derives candles from sparkline/high/low.
     */
    suspend fun getCandles(symbol: String, timeframe: String = "4h"): List<Candle> = withContext(Dispatchers.IO) {
        val binanceInterval = when (timeframe) {
            "1m" -> "1m"
            "5m" -> "5m"
            "15m" -> "15m"
            "1h" -> "1h"
            "4h" -> "4h"
            "1D", "1d" -> "1d"
            "1W", "1w" -> "1w"
            else -> "4h"
        }

        try {
            val pair = "${symbol.uppercase()}USDT"
            val klines = runCatching {
                NetworkClient.binance.getKlinesRaw(pair, binanceInterval, 250).use { it.string() }
            }.recoverCatching {
                NetworkClient.binancePrimary.getKlinesRaw(pair, binanceInterval, 250).use { it.string() }
            }.getOrNull()

            if (klines != null) {
                val root = runCatching { JSONArray(klines) }.getOrNull()
                val list = root?.let { rows ->
                    buildList {
                        for (index in 0 until rows.length()) {
                            val row = rows.optJSONArray(index) ?: continue
                            val time = row.optLong(0, 0L)
                            val open = row.optString(1).toDoubleOrNull() ?: continue
                            val high = row.optString(2).toDoubleOrNull() ?: continue
                            val low = row.optString(3).toDoubleOrNull() ?: continue
                            val close = row.optString(4).toDoubleOrNull() ?: continue
                            val volume = row.optString(5).toDoubleOrNull() ?: continue
                            if (time > 0L && high >= low && high > 0.0 && low > 0.0 && close > 0.0) {
                                add(Candle(time, open, high, low, close, volume.coerceAtLeast(0.0)))
                            }
                        }
                    }
                }.orEmpty()
                if (list.size >= 30) {
                    return@withContext list.sortedBy { it.timestamp }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return@withContext emptyList()
    }

    suspend fun runRadarScan(
        timeframe: String = "4h",
        strategyFilter: String = "ALL",
        searchQuery: String = ""
    ): List<RadarOpportunity> = withContext(Dispatchers.IO) {
        val assets = fetchMarketAssets()
        val btc = assets.firstOrNull { it.symbol == "BTC" }
        val btcChange = btc?.change24h ?: 2.0

        val candidates = assets.filter { asset ->
            val matchesSearch = searchQuery.isBlank() ||
                asset.symbol.contains(searchQuery, ignoreCase = true) ||
                asset.name.contains(searchQuery, ignoreCase = true) ||
                asset.nameFa.contains(searchQuery, ignoreCase = true)
            val liquidEnough = asset.volume24hUsd >= 2_000_000.0 || asset.symbol == "BTC" || asset.symbol == "ETH"
            matchesSearch && liquidEnough
        }

        // Candle requests are the expensive part of the scanner. Keep concurrency bounded so a
        // refresh does not create an API burst or exhaust sockets on mobile devices.
        val semaphore = Semaphore(permits = 6)
        val opportunities = coroutineScope {
            candidates.map { asset ->
                async(Dispatchers.IO) {
                    semaphore.withPermit {
                        runCatching {
                            val candles = getCandles(asset.symbol, timeframe)
                            val opp = TechnicalAnalysisEngine.evaluateOpportunity(asset, candles, btcChange, timeframe)
                            val matchesStrategy = when (strategyFilter) {
                                "ALL" -> true
                                "BREAKOUT" -> opp.signalType == RadarSignalType.BREAKOUT
                                "VOLUME_SPIKE" -> opp.signalType == RadarSignalType.VOLUME_SPIKE
                                "REVERSAL" -> opp.signalType == RadarSignalType.REVERSAL
                                "OVERSOLD" -> opp.signalType == RadarSignalType.OVERSOLD_BOUNCE
                                "SQUEEZE" -> opp.signalType == RadarSignalType.SQUEEZE
                                else -> true
                            }
                            opp.takeIf { matchesStrategy }
                        }.getOrNull()
                    }
                }
            }.awaitAll().filterNotNull()
        }

        // Rank by transparent radar score
        val sorted = opportunities.sortedByDescending { it.score }

        // Record scan history
        if (sorted.isNotEmpty()) {
            val top = sorted.first()
            scanHistoryDao.insert(
                ScanHistoryEntity(
                    timeframe = timeframe,
                    topPicksCount = sorted.size,
                    topSymbol = top.asset.symbol,
                    topScore = top.score,
                    summaryFa = "رصد ${sorted.size} دارایی مستعد در تایم‌فریم $timeframe با پیشتازی ${top.asset.nameFa} (${top.asset.symbol})"
                )
            )
        }

        sorted
    }

    suspend fun fetchNews(): List<CryptoNewsItem> = withContext(Dispatchers.IO) {
        try {
            NewsAggregator.fetch()
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    suspend fun getMarketOverview(): MarketOverviewData = withContext(Dispatchers.IO) {
        val assets = fetchMarketAssets()
        val btc = assets.firstOrNull { it.symbol == "BTC" }
        val eth = assets.firstOrNull { it.symbol == "ETH" }

        val btcPrice = btc?.priceUsd ?: 0.0
        val btcChange = btc?.change24h ?: 0.0
        val ethPrice = eth?.priceUsd ?: 0.0
        val ethChange = eth?.change24h ?: 0.0
        val globalResult = runCatching { NetworkClient.coinGecko.getGlobal().data }
        val global = globalResult.getOrNull()
        val totalVol = global?.totalVolume?.get("usd") ?: assets.sumOf { it.volume24hUsd }
        val totalCap = global?.totalMarketCap?.get("usd") ?: assets.sumOf { it.marketCapUsd }
        val dominance = global?.marketCapPercentage?.get("btc") ?: 0.0
        val sourceCount = listOf(
            btc?.priceUsd?.takeIf { it > 0 },
            eth?.priceUsd?.takeIf { it > 0 },
            totalCap.takeIf { it > 0 }
        ).count { it != null }
        val warnings = buildList {
            if (assets.isEmpty()) add("هیچ داده بازار زنده‌ای دریافت نشد")
            if (global == null) add("داده Global از CoinGecko در دسترس نیست")
            if (btc == null || btcPrice <= 0) add("داده معتبر BTC موجود نیست")
        }
        val quality = (sourceCount * 30 + if (global != null) 30 else 0).coerceIn(0, 100)

        val regimeFa = when {
            btcChange > 3.0 -> "فاز صعودی قوی (رالی شتابان بیت‌کوین)"
            btcChange in 0.5..3.0 -> "روند صعودی آرام با ثبات آلت‌کوین‌ها"
            btcChange in -1.5..0.5 -> "فاز رنج و تثبیت در محدوده تراکم"
            else -> "فاز اصلاحی کوتاه‌مدت و احتیاط در بازار"
        }

        MarketOverviewData(
            btcDominance = dominance,
            totalMarketCapUsd = totalCap,
            totalVolume24hUsd = totalVol,
            btcPrice = btcPrice,
            btcChange24h = btcChange,
            ethPrice = ethPrice,
            ethChange24h = ethChange,
            marketRegimeFa = regimeFa,
            binanceHealthy = true,
            coingeckoHealthy = true,
            coincapHealthy = true,
            dataQualityScore = quality,
            dataWarnings = warnings,
            lastSyncTimestamp = System.currentTimeMillis()
        )
    }
}

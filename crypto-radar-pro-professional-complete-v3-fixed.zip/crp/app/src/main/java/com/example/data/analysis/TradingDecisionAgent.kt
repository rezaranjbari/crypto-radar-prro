package com.example.data.analysis

import com.example.data.model.*

/** Conservative decision agent: it may veto a technically attractive setup. */
object TradingDecisionAgent {
    fun decide(intelligence: MarketIntelligence, professional: ProfessionalAnalyticsSnapshot? = null): AIDecisionPlan {
        val veto = mutableListOf<String>()
        if (intelligence.dataQuality.score < 70) veto += "Data quality below safety threshold"
        if (intelligence.riskScore < 35) veto += "Risk score too low"
        if (intelligence.riskReward != null && intelligence.riskReward < 1.5) veto += "Risk/reward below minimum"
        professional?.anomalies?.filter { it.severity >= 90 }?.forEach { veto += "Severe anomaly: ${it.type}" }
        val finalAction = if (veto.isNotEmpty()) DecisionAction.NO_TRADE else intelligence.action
        val confidence = if (veto.isNotEmpty()) minOf(intelligence.confidence, 35) else intelligence.confidence
        val thesis = when (finalAction) {
            DecisionAction.LONG -> "Trend, momentum and structure support a bullish scenario; confirmation is still required."
            DecisionAction.SHORT -> "Trend, momentum and structure support a bearish scenario; confirmation is still required."
            DecisionAction.WAIT -> "Evidence is mixed; wait for a higher-quality trigger."
            DecisionAction.NO_TRADE -> "Safety checks vetoed the setup because the evidence/risk profile is insufficient."
        }
        return AIDecisionPlan(finalAction, confidence, thesis, intelligence.entryMin, intelligence.entryMax, intelligence.stopLoss, intelligence.takeProfit1, intelligence.takeProfit2, intelligence.riskReward, veto.isNotEmpty(), veto)
    }
}

package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        WatchlistEntity::class,
        CachedMarketEntity::class,
        ScanHistoryEntity::class,
        TradingJournalEntity::class,
        AlertEntity::class,
        PaperTradeEntity::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun watchlistDao(): WatchlistDao
    abstract fun cachedMarketDao(): CachedMarketDao
    abstract fun scanHistoryDao(): ScanHistoryDao
    abstract fun tradingJournalDao(): TradingJournalDao
    abstract fun alertDao(): AlertDao
    abstract fun paperTradeDao(): PaperTradeDao

    companion object {
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE price_alerts ADD COLUMN lastTriggeredAt INTEGER")
            }
        }

        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("CREATE TABLE IF NOT EXISTS paper_trades (id TEXT NOT NULL PRIMARY KEY, symbol TEXT NOT NULL, side TEXT NOT NULL, entry REAL NOT NULL, stop REAL NOT NULL, target REAL NOT NULL, quantity REAL NOT NULL, openedAt INTEGER NOT NULL, closedAt INTEGER, exit REAL, pnlUsd REAL, status TEXT NOT NULL)")
            }
        }

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "crypto_radar_pro.db"
                )
                    .addMigrations(MIGRATION_2_3, MIGRATION_3_4)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

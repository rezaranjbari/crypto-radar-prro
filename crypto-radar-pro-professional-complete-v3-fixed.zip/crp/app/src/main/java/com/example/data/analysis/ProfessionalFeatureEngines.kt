package com.example.data.analysis

import com.example.data.model.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object MarketRegimeEngine {
    fun classify(candles: List<Candle>, btcCandles: List<Candle> = emptyList(), breadth: Double? = null): MarketRegimeSnapshot {
        if (candles.size < 30) return MarketRegimeSnapshot("DATA_INSUFFICIENT", 0, 0.0, breadth, TrendDirection.NEUTRAL, listOf("حداقل ۳۰ کندل لازم است"))
        val recent = candles.takeLast(20)
        val ret = recent.first().close.takeIf { it > 0 }?.let { recent.last().close / it - 1.0 } ?: 0.0
        val ranges = recent.map { (it.high - it.low) / it.close.coerceAtLeast(1e-12) }
        val vol = ranges.average() * 100
        val maFast = candles.takeLast(20).map { it.close }.average()
        val maSlow = candles.takeLast(50).map { it.close }.average()
        val btcTrend = trend(btcCandles)
        val regime = when {
            ret > 0.08 && maFast > maSlow -> "BULL_TREND"
            ret < -0.08 && maFast < maSlow -> "BEAR_TREND"
            vol > 6.0 -> "HIGH_VOLATILITY"
            else -> "RANGE_TRANSITION"
        }
        val confidence = ((abs(ret) * 500) + abs(maFast / maSlow - 1) * 1000 + min(vol, 10.0) * 4).toInt().coerceIn(0, 95)
        return MarketRegimeSnapshot(regime, confidence, vol, breadth, btcTrend, listOf("Return20=${"%.2f".format(ret * 100)}%", "Volatility=${"%.2f".format(vol)}%"))
    }
    private fun trend(c: List<Candle>): TrendDirection {
        if (c.size < 10) return TrendDirection.NEUTRAL
        val fast = c.takeLast(10).map { it.close }.average()
        val slow = c.takeLast(min(c.size, 30)).map { it.close }.average()
        return when { fast > slow * 1.01 -> TrendDirection.BULLISH; fast < slow * .99 -> TrendDirection.BEARISH; else -> TrendDirection.NEUTRAL }
    }
}

object PositionSizingEngine {
    fun simulate(symbol: String, side: TradeSide, capital: Double, riskPercent: Double, leverage: Double, entry: Double, stop: Double, target: Double): PositionSimulation {
        val riskUsd = capital * riskPercent.coerceIn(0.01, 10.0) / 100.0
        val distance = abs(entry - stop).coerceAtLeast(entry * 0.0001)
        val quantity = riskUsd / distance
        val targetProfit = quantity * abs(target - entry)
        val rr = targetProfit / riskUsd.coerceAtLeast(1e-12)
        val liqBuffer = if (leverage > 0) (100.0 / leverage) - abs(entry - stop) / entry * 100 else null
        return PositionSimulation(symbol, side, capital, riskPercent, leverage, entry, stop, target, quantity, riskUsd, targetProfit, liqBuffer, rr)
    }
}

object PortfolioAnalyticsEngine {
    fun analyze(positions: List<PortfolioPosition>, candlesBySymbol: Map<String, List<Candle>> = emptyMap()): PortfolioAnalytics? {
        if (positions.isEmpty()) return null
        val total = positions.sumOf { it.valueUsd }.coerceAtLeast(1e-9)
        val largest = positions.maxOf { it.valueUsd } / total * 100
        val weightedPnl = positions.sumOf { it.pnlPercent * it.valueUsd } / total
        val sectors = positions.groupBy { it.sector ?: "Unknown" }.mapValues { (_, v) -> v.sumOf { it.valueUsd } / total * 100 }
        val warnings = buildList { if (largest > 40) add("تمرکز یک موقعیت بیش از ۴۰٪ است") ; if (sectors["Unknown"] ?: 0.0 > 50) add("بخش بزرگی از پرتفوی بدون دسته‌بندی است") }
        val corr = CorrelationEngine.calculate(candlesBySymbol)
        return PortfolioAnalytics(total, weightedPnl, largest, sectors, warnings, corr)
    }
}

object SignalCalibrationEngine {
    fun calibrate(outcomes: List<Pair<Int, Boolean>>): SignalCalibration {
        if (outcomes.size < 30) return SignalCalibration(outcomes.size, null, null, emptyMap(), FeedStatus.DEGRADED, listOf("حداقل ۳۰ سیگنال حل‌شده برای کالیبراسیون لازم است"))
        val brier = outcomes.map { (confidence, success) -> val p = confidence / 100.0; (p - if (success) 1.0 else 0.0) * (p - if (success) 1.0 else 0.0) }.average()
        val buckets = outcomes.groupBy { (it.first / 20).coerceIn(0, 4) }.mapValues { (_, v) -> v.count { it.second } * 100.0 / v.size }
        return SignalCalibration(outcomes.size, brier, brier, buckets.mapKeys { "${it.key * 20}-${it.key * 20 + 19}" }, FeedStatus.LIVE)
    }
}

object StrategyRobustnessEngine {
    fun evaluate(name: String, inSample: StrategyTestResult, outSample: StrategyTestResult): StrategyEvaluation {
        val returnRatio = if (inSample.totalReturnPercent != 0.0) abs(outSample.totalReturnPercent / inSample.totalReturnPercent) else 0.0
        val degradation = (1.0 - returnRatio).coerceIn(0.0, 1.0)
        val overfit = (degradation * 100).toInt().coerceIn(0, 100)
        val robust = (100 - overfit).coerceIn(0, 100)
        return StrategyEvaluation(name, inSample, outSample, robust, overfit, listOf("مقایسه عملکرد داخل/خارج نمونه انجام شد", if (overfit > 40) "ریسک بیش‌برازش بالاست" else "شواهد بیش‌برازش محدود است"))
    }
}

object ScreenerEngine {
    fun filter(assets: List<CryptoAsset>, intelligence: Map<String, MarketIntelligence>, minScore: Int = 70, action: DecisionAction? = null): List<CryptoAsset> = assets.filter { a -> val i = intelligence[a.symbol] ?: return@filter false; i.score >= minScore && (action == null || i.action == action) }.sortedByDescending { intelligence[it.symbol]?.score ?: 0 }
}

object TradeSafetyEngine {
    fun veto(intelligence: MarketIntelligence, position: PositionSimulation? = null, eventRisk: Int = 0): List<String> = buildList {
        if (intelligence.dataQuality.score < 60) add("کیفیت داده پایین است")
        if (intelligence.riskReward != null && intelligence.riskReward < 1.5) add("R:R کمتر از 1.5")
        if (eventRisk >= 80) add("ریسک رویداد بسیار بالا است")
        if (position != null && position.rr < 1.5) add("محاسبه موقعیت R:R مناسب نیست")
        if (position?.liquidationBufferPercent != null && position.liquidationBufferPercent!! < 1.0) add("فاصله تا لیکوییدیشن برای اهرم انتخابی کم است")
    }
}

object NewsIntelligenceEngine {
    fun score(title: String, source: String): NewsInsight {
        val t = title.lowercase()
        val positive = listOf("approve", "adoption", "partnership", "launch", "inflow", "approval", "رشد", "تصویب", "همکاری")
        val negative = listOf("hack", "exploit", "lawsuit", "ban", "outflow", "liquidation", "هک", "ممنوع", "خروج")
        val pos = positive.count { t.contains(it) }
        val neg = negative.count { t.contains(it) }
        val sentiment = ((pos - neg) / 3.0).coerceIn(-1.0, 1.0)
        val impact = ((pos + neg) * 25).coerceIn(0, 100)
        return NewsInsight(title, source, sentiment, impact)
    }
}

object CapabilityRegistry {
    fun all(): List<FeatureCapability> = listOf(
        FeatureCapability("trend_navigator", "Trend Navigator", FeedStatus.LIVE, "Multi-timeframe trend, momentum and structure"),
        FeatureCapability("ai_agent", "AI Trading Agent", FeedStatus.LIVE, "Deterministic decision-support with LONG/SHORT/WAIT/NO_TRADE"),
        FeatureCapability("risk_engine", "Trade Safety Engine", FeedStatus.LIVE, "R:R, data quality, event and leverage vetoes"),
        FeatureCapability("screener", "Advanced Screener", FeedStatus.LIVE, "Score/action based filtering"),
        FeatureCapability("backtest", "Strategy Lab", FeedStatus.LIVE, "Fee/slippage and out-of-sample evaluation"),
        FeatureCapability("paper_trading", "Paper Trading", FeedStatus.LIVE, "Local simulation model; execution is disabled"),
        FeatureCapability("derivatives", "Derivatives", FeedStatus.LIVE, "Funding/OI/aggTrade from supported exchange feed"),
        FeatureCapability("iran_exchanges", "Iran Exchanges", FeedStatus.LIVE, "Nobitex/Wallex/Bitpin quote comparison"),
        FeatureCapability("order_flow", "Order Flow", FeedStatus.DEGRADED, "OHLCV/aggTrade proxy unless tick-level feed is configured"),
        FeatureCapability("liquidations", "Liquidation Intelligence", FeedStatus.CONFIG_REQUIRED, "Requires a liquidation data provider", true),
        FeatureCapability("onchain", "On-chain Intelligence", FeedStatus.CONFIG_REQUIRED, "Requires a trusted on-chain provider", true),
        FeatureCapability("smart_money", "Smart Money", FeedStatus.CONFIG_REQUIRED, "Requires wallet/entity provider", true),
        FeatureCapability("top_traders", "Top Traders", FeedStatus.CONFIG_REQUIRED, "Requires public trader leaderboard/provider", true),
        FeatureCapability("token_unlocks", "Token Unlocks", FeedStatus.CONFIG_REQUIRED, "Requires unlock calendar provider", true),
        FeatureCapability("macro_calendar", "Economic Calendar", FeedStatus.CONFIG_REQUIRED, "Requires trusted macro event feed", true),
        FeatureCapability("confidence_calibration", "Confidence Calibration", FeedStatus.DEGRADED, "Activates after enough resolved signals"),
        FeatureCapability("cross_exchange", "Cross Exchange", FeedStatus.DEGRADED, "Uses supported public quote sources; coverage varies"),
        FeatureCapability("auto_trade", "Automatic Trading", FeedStatus.UNAVAILABLE, "Intentionally disabled in this release for safety")
    )
}

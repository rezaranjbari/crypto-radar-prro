package com.example.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.R
import com.example.data.local.AppDatabase
import com.example.data.repository.CryptoRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs

class PriceAlertWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            createChannel(applicationContext)
            val db = AppDatabase.getInstance(applicationContext)
            val repository = CryptoRepository(db)
            val alerts = db.alertDao().getActive()
            if (alerts.isEmpty()) {
                return@withContext Result.success()
            }

            val assets = repository.fetchMarketAssets()
            val prices = assets.associateBy { it.symbol.uppercase() }
            val now = System.currentTimeMillis()

            alerts.forEach { alert ->
                val asset = prices[alert.symbol.uppercase()] ?: return@forEach
                val price = asset.priceUsd
                val direction = alert.direction.uppercase()
                val triggered = when (direction) {
                    "ABOVE", "UP", "بالا", "بیشتر" -> price >= alert.targetPrice
                    "BELOW", "DOWN", "پایین", "کمتر" -> price <= alert.targetPrice
                    else -> alert.targetPrice != 0.0 &&
                        abs(price - alert.targetPrice) / abs(alert.targetPrice) <= 0.0025
                }

                val cooldownPassed =
                    alert.lastTriggeredAt == null ||
                        now - alert.lastTriggeredAt >= 30 * 60 * 1000L

                if (triggered && cooldownPassed) {
                    val title = "هشدار قیمت ${asset.symbol}"
                    val body = String.format(
                        Locale.US,
                        "قیمت به %,.8f USD رسید (هدف: %,.8f)",
                        price,
                        alert.targetPrice
                    )
                    showNotification(applicationContext, alert.id.toInt(), title, body)
                    db.alertDao().markTriggered(alert.id, now)
                }
            }

            Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            Result.retry()
        }
    }

    companion object {
        const val CHANNEL_ID = "price_alerts"

        private fun createChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val manager = context.getSystemService(NotificationManager::class.java)
                manager.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "هشدار قیمت", NotificationManager.IMPORTANCE_HIGH).apply {
                        description = "اعلان رسیدن ارز به قیمت هدف"
                    }
                )
            }
        }

        private fun showNotification(context: Context, id: Int, title: String, body: String) {
            if (Build.VERSION.SDK_INT >= 33 &&
                androidx.core.content.ContextCompat.checkSelfPermission(
                    context, android.Manifest.permission.POST_NOTIFICATIONS
                ) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) return

            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(context).notify(id, notification)
        }
    }
}

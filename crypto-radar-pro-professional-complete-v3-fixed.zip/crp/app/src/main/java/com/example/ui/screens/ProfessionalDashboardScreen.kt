package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.PaperTradeEntity
import com.example.data.analysis.CapabilityRegistry
import com.example.data.model.FeedStatus
import com.example.ui.localization.AppLanguage
import com.example.ui.theme.BullishGreen
import com.example.ui.theme.NeutralAmber
import com.example.ui.theme.RadarBg
import com.example.ui.theme.RadarBorder
import com.example.ui.theme.RadarSurface
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ProfessionalDashboardScreen(language: AppLanguage, paperTrades: List<PaperTradeEntity>, modifier: Modifier = Modifier) {
    val caps = CapabilityRegistry.all()
    LazyColumn(modifier.fillMaxSize().background(RadarBg), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(if (language == AppLanguage.PERSIAN) "مرکز حرفه‌ای CRP" else "CRP Professional Center", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(if (language == AppLanguage.PERSIAN) "وضعیت واقعی قابلیت‌ها، Paper Trading و محدودیت Providerها" else "Real capability status, paper trading and provider coverage", color = TextSecondary, fontSize = 11.sp)
        }
        item {
            StatusCard("Paper Trading", "${paperTrades.count { it.status == "OPEN" }} open / ${paperTrades.size} total", FeedStatus.LIVE)
        }
        items(caps) { cap -> StatusCard(cap.name, cap.detail, cap.status) }
    }
}

@Composable
private fun StatusCard(title: String, detail: String, status: FeedStatus) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(RadarSurface).border(1.dp, RadarBorder, RoundedCornerShape(14.dp)).padding(13.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(title, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(status.name, color = if (status == FeedStatus.LIVE) BullishGreen else NeutralAmber, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(4.dp))
        Text(detail, color = TextSecondary, fontSize = 10.sp)
    }
}

package com.example.data.analysis

import com.example.data.model.*
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Central professional analytics layer. It derives only from supplied evidence and explicitly
 * marks unavailable provider-dependent features instead of inventing values.
 */
object ProfessionalAnalyticsEngine {
    fun analyze(
        symbol: String,
        candles: List<Candle>,
        intelligence: MarketIntelligence,
        derivatives: DerivativesSnapshot? = null,
        btcCandles: List<Candle> = emptyList(),
        ethCandles: List<Candle> = emptyList(),
        marketCandles: List<Candle> = emptyList(),
        traderProfiles: List<TraderProfile> = emptyList(),
        portfolio: List<PortfolioPosition> = emptyList(),
        nowMs: Long = System.currentTimeMillis()
    ): ProfessionalAnalyticsSnapshot {
        val valid = candles.filter { valid(it) }
        val anomalies = anomalySignals(valid)
        val zones = liquidityZones(valid)
        val orderFlow = deriveOrderFlow(valid)
        val relative = relativeStrength(valid, btcCandles, ethCandles, marketCandles)
        val scenarios = scenarios(valid, intelligence, zones)
        val regime = when {
            intelligence.trendScore >= 70 && intelligence.momentumScore >= 60 -> "BULLISH_TREND"
            intelligence.trendScore <= 30 && intelligence.momentumScore <= 45 -> "BEARISH_TREND"
            else -> "RANGE_TRANSITION"
        }
        val evidence = listOf(
            AnalyticsEvidence("Trend", intelligence.trendScore, "Available", "Multi-timeframe trend structure"),
            AnalyticsEvidence("Momentum", intelligence.momentumScore, "Available", "RSI/MACD momentum"),
            AnalyticsEvidence("Volume", intelligence.volumeScore, "Available", "Relative volume"),
            AnalyticsEvidence("Structure", intelligence.structureScore, "Available", "Breakout/BOS/support-resistance"),
            AnalyticsEvidence("Derivatives", intelligence.derivativesScore, if (derivatives == null) "Unavailable" else "Available", "Funding/OI feed"),
            AnalyticsEvidence("On-chain", null, "Unavailable", "No trusted on-chain provider supplied"),
            AnalyticsEvidence("Top Traders", null, "Unavailable", "No public trader leaderboard feed supplied"),
            AnalyticsEvidence("Liquidations", null, "Unavailable", "No liquidation feed supplied")
        )
        val quality = intelligence.dataQuality.copy(
            warnings = (intelligence.dataQuality.warnings + anomalies.filter { it.severity >= 80 }.map { it.explanation }).distinct()
        )
        val traderConsensus = traderConsensus(symbol, traderProfiles)
        val aiDecision = TradingDecisionAgent.decide(intelligence)
        val regimeSnapshot = MarketRegimeEngine.classify(valid, btcCandles)
        val positionSimulation = if (aiDecision.entryMin != null && aiDecision.stopLoss != null && aiDecision.takeProfit1 != null) {
            PositionSizingEngine.simulate(symbol, if (aiDecision.action == DecisionAction.SHORT) TradeSide.SHORT else TradeSide.LONG, 1000.0, 1.0, 1.0, (aiDecision.entryMin + (aiDecision.entryMax ?: aiDecision.entryMin)) / 2.0, aiDecision.stopLoss, aiDecision.takeProfit1)
        } else null
        val safetyReasons = TradeSafetyEngine.veto(intelligence, positionSimulation)
        val safeDecision = if (safetyReasons.isNotEmpty() && aiDecision.action != DecisionAction.WAIT) aiDecision.copy(action = DecisionAction.NO_TRADE, safetyVeto = true, vetoReasons = safetyReasons, thesis = aiDecision.thesis + " | Safety veto") else aiDecision
        val professionalFeatures = ProfessionalFeatureSnapshot(
            regime = regimeSnapshot,
            liquidation = LiquidationSnapshot(),
            smartMoney = SmartMoneySnapshot(),
            onChain = OnChainIntelligence(),
            crossExchange = CrossExchangeSnapshot(symbol, emptyMap(), null, null, false, FeedStatus.UNAVAILABLE),
            unlocks = emptyList(),
            events = emptyList(),
            news = emptyList(),
            traderIntelligence = TraderIntelligenceSnapshot(traderProfiles, traderConsensus, if (traderProfiles.isEmpty()) FeedStatus.CONFIG_REQUIRED else FeedStatus.LIVE, if (traderProfiles.isEmpty()) "No public trader provider" else "Supplied profiles"),
            portfolio = portfolio.takeIf { it.isNotEmpty() }?.let { PortfolioAnalyticsEngine.analyze(it) },
            signalCalibration = SignalCalibrationEngine.calibrate(emptyList()),
            strategyEvaluations = emptyList(),
            providerHealth = listOf(ProviderHealth("Core market data", FeedStatus.LIVE, message = "Local analytics")),
            capabilities = CapabilityRegistry.all()
        )
        val portfolioRisk = portfolio.takeIf { it.isNotEmpty() }?.let { portfolioRisk(it) }
        val unavailable = evidence.filter { it.status == "Unavailable" }.map { it.name }
        return ProfessionalAnalyticsSnapshot(
            marketRegime = regime,
            marketScore = intelligence.score,
            evidences = evidence,
            scenarios = scenarios,
            anomalies = anomalies,
            relativeStrength = relative,
            liquidityZones = zones,
            orderFlow = orderFlow,
            traderConsensus = traderConsensus,
            portfolioRisk = portfolioRisk,
            aiDecision = safeDecision,
            correlation = null,
            professionalFeatures = professionalFeatures,
            dataQuality = quality,
            unavailableFeeds = unavailable,
            generatedAt = nowMs
        )
    }

    fun backtest(candles: List<Candle>, rules: List<StrategyRule>, feePercent: Double = .1, slippagePercent: Double = .05): StrategyTestResult {
        val valid = candles.filter { valid(it) }
        if (valid.size < 80) return StrategyTestResult(0, 0.0, 0.0, 0.0, 0.0, 0.0, feePercent, slippagePercent, false, listOf("داده تاریخی کافی نیست"))
        val split = (valid.size * .7).toInt().coerceAtLeast(40)
        val test = valid.drop(split)
        val trades = mutableListOf<Double>()
        var equity = 1.0
        var peak = 1.0
        var maxDd = 0.0
        for (i in 1 until test.size) {
            val prev = test[i - 1]
            val cur = test[i]
            val change = cur.close / prev.close - 1.0
            val fee = (feePercent + slippagePercent) / 100.0
            val adjusted = change - fee
            if (rules.none { it.enabled } || rules.any { it.enabled && it.name.contains("trend", true) }) {
                trades += adjusted
                equity *= 1.0 + adjusted
                peak = max(peak, equity)
                maxDd = max(maxDd, (peak - equity) / peak * 100.0)
            }
        }
        val wins = trades.count { it > 0 }
        val losses = trades.filter { it < 0 }
        val grossWin = trades.filter { it > 0 }.sum()
        val grossLoss = -losses.sum()
        val pf = if (grossLoss > 0) grossWin / grossLoss else 0.0
        return StrategyTestResult(trades.size, if (trades.isEmpty()) 0.0 else wins * 100.0 / trades.size, pf,
            if (trades.isEmpty()) 0.0 else trades.average() * 100.0, (equity - 1) * 100, maxDd, feePercent, slippagePercent, true,
            listOf("Out-of-sample result؛ برای تصمیم واقعی هزینه، اسلیپیج و رژیم بازار را جداگانه بررسی کنید"))
    }

    private fun valid(c: Candle) = c.open > 0 && c.high >= max(c.open, c.close) && c.low <= min(c.open, c.close) && c.close > 0 && c.volume >= 0
    private fun anomalySignals(c: List<Candle>): List<AnomalySignal> {
        if (c.size < 30) return emptyList()
        val recent = c.takeLast(20)
        val avgVol = recent.dropLast(1).map { it.volume }.average().coerceAtLeast(1e-12)
        val last = recent.last()
        val volRatio = last.volume / avgVol
        val avgRange = recent.dropLast(1).map { it.high - it.low }.average().coerceAtLeast(1e-12)
        val rangeRatio = (last.high - last.low) / avgRange
        return buildList {
            if (volRatio >= 3) add(AnomalySignal("VOLUME_SPIKE", 85, volRatio, 1.0, "حجم غیرعادی نسبت به میانگین"))
            if (rangeRatio >= 3) add(AnomalySignal("RANGE_EXPANSION", 80, rangeRatio, 1.0, "گسترش غیرعادی دامنه کندل"))
        }
    }
    private fun liquidityZones(c: List<Candle>): List<LiquidityZone> {
        if (c.size < 20) return emptyList()
        val recent = c.takeLast(100)
        val levels = recent.flatMap { listOf(it.high, it.low) }
        val bins = levels.groupingBy { kotlin.math.round(it / (recent.last().close * .005)).toInt() }.eachCount()
        return bins.entries.sortedByDescending { it.value }.take(8).map {
            LiquidityZone(it.key * recent.last().close * .005, (it.value * 12).coerceAtMost(100), if (it.key < recent.last().close / (recent.last().close * .005)) "SUPPORT/LIQUIDITY" else "RESISTANCE/LIQUIDITY")
        }
    }
    private fun deriveOrderFlow(c: List<Candle>): OrderFlowSnapshot {
        if (c.isEmpty()) return OrderFlowSnapshot()
        val buy = c.sumOf { if (it.close >= it.open) it.volume else 0.0 }
        val sell = c.sumOf { if (it.close < it.open) it.volume else 0.0 }
        val total = (buy + sell).coerceAtLeast(1e-12)
        return OrderFlowSnapshot(buy, sell, buy - sell, null, null, (buy - sell) / total, "OHLCV proxy; not exchange tick-level CVD")
    }
    private fun relativeStrength(c: List<Candle>, btc: List<Candle>, eth: List<Candle>, market: List<Candle>): RelativeStrengthSnapshot {
        fun ret(x: List<Candle>): Double? = if (x.size >= 2) x.last().close / x.first().close - 1 else null
        val r = ret(c)
        fun vs(other: List<Candle>) = if (r != null && ret(other) != null) (r - ret(other)!!) * 100 else null
        return RelativeStrengthSnapshot(vs(btc), vs(eth), vs(market), null)
    }
    private fun scenarios(c: List<Candle>, i: MarketIntelligence, zones: List<LiquidityZone>): List<Scenario> {
        val p = c.lastOrNull()?.close ?: return emptyList()
        val atr = c.takeLast(20).map { it.high - it.low }.average().coerceAtLeast(p * .005)
        return listOf(
            Scenario("Bullish", if (i.action == DecisionAction.LONG) 55 else 35, "بسته‌شدن بالای مقاومت/شکست با حجم", "بازگشت زیر سطح شکست", p + atr * 2),
            Scenario("Base", 30, "حفظ محدوده فعلی", "شکست معتبر محدوده", p),
            Scenario("Bearish", if (i.action == DecisionAction.SHORT) 55 else 35, "از دست رفتن حمایت", "بازپس‌گیری حمایت", p - atr * 2)
        )
    }
    private fun traderConsensus(symbol: String, traders: List<TraderProfile>): TraderConsensus {
        val relevant = traders.filter { it.selectedSymbols.any { s -> s.equals(symbol, true) } }
        if (relevant.isEmpty()) return TraderConsensus(symbol, 0.0, 0.0, 0.0, 0, 0)
        val weights = relevant.map { max(0.1, (it.riskScore ?: 50) / 100.0) }
        val long = relevant.zip(weights).count { it.first.publicPositions.any { p -> p.equals("LONG", true) } }.toDouble()
        val short = relevant.zip(weights).count { it.first.publicPositions.any { p -> p.equals("SHORT", true) } }.toDouble()
        val total = weights.sum().coerceAtLeast(.1)
        return TraderConsensus(symbol, long / total, short / total, 1 - min(1.0, (long + short) / total), relevant.size, ((max(long, short) / total) * 100).toInt())
    }
    private fun portfolioRisk(p: List<PortfolioPosition>): PortfolioRiskSnapshot {
        val total = p.sumOf { it.valueUsd }.coerceAtLeast(1e-12)
        val largest = p.maxByOrNull { it.valueUsd }
        val concentration = largest?.valueUsd?.div(total)?.times(100) ?: 0.0
        val volatility = sqrt(p.sumOf { (it.pnlPercent / 100.0).let { x -> x * x } } / p.size.coerceAtLeast(1)) * 100
        val warnings = buildList { if (concentration > 40) add("تمرکز پرتفوی بالاست") }
        return PortfolioRiskSnapshot(total, concentration, largest?.symbol, volatility, 0.0, if (concentration > 60) "HIGH" else if (concentration > 40) "MEDIUM" else "LOW", warnings)
    }
}

package com.example.data.remote

import com.example.data.model.*

/** Provider contracts keep external APIs replaceable and prevent UI/business logic from depending on vendors. */
interface DerivativesProvider { suspend fun snapshot(symbols: List<String>): List<DerivativesSnapshot> }
interface OnChainProvider { suspend fun snapshot(symbol: String): OnChainIntelligence }
interface LiquidationProvider { suspend fun snapshot(symbol: String): LiquidationSnapshot }
interface SmartMoneyProvider { suspend fun snapshot(symbol: String): SmartMoneySnapshot }
interface TraderProvider { suspend fun traders(symbol: String): TraderIntelligenceSnapshot }
interface UnlockProvider { suspend fun upcoming(symbols: List<String>): List<UnlockEvent> }
interface MacroProvider { suspend fun upcoming(): List<EventRisk> }

object UnavailableProviders {
    val onChain = object : OnChainProvider { override suspend fun snapshot(symbol: String) = OnChainIntelligence(status = FeedStatus.CONFIG_REQUIRED, source = "No provider configured") }
    val liquidation = object : LiquidationProvider { override suspend fun snapshot(symbol: String) = LiquidationSnapshot(status = FeedStatus.CONFIG_REQUIRED, source = "No provider configured") }
    val smartMoney = object : SmartMoneyProvider { override suspend fun snapshot(symbol: String) = SmartMoneySnapshot(status = FeedStatus.CONFIG_REQUIRED, source = "No provider configured") }
    val trader = object : TraderProvider { override suspend fun traders(symbol: String) = TraderIntelligenceSnapshot(emptyList(), TraderConsensus(symbol, 0.0, 0.0, 0.0, 0, 0), FeedStatus.CONFIG_REQUIRED, "No provider configured") }
    val unlocks = object : UnlockProvider { override suspend fun upcoming(symbols: List<String>) = emptyList<UnlockEvent>() }
    val macro = object : MacroProvider { override suspend fun upcoming() = emptyList<EventRisk>() }
}

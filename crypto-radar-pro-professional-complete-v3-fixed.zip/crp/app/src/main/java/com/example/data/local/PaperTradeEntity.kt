package com.example.data.local

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "paper_trades")
data class PaperTradeEntity(
    @androidx.room.PrimaryKey val id: String,
    val symbol: String,
    val side: String,
    val entry: Double,
    val stop: Double,
    val target: Double,
    val quantity: Double,
    val openedAt: Long,
    val closedAt: Long? = null,
    val exit: Double? = null,
    val pnlUsd: Double? = null,
    val status: String = "OPEN"
)

@Dao
interface PaperTradeDao {
    @Query("SELECT * FROM paper_trades ORDER BY openedAt DESC LIMIT 200")
    fun observe(): Flow<List<PaperTradeEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: PaperTradeEntity)
    @Query("UPDATE paper_trades SET status = :status, closedAt = :closedAt, exit = :exit, pnlUsd = :pnl WHERE id = :id")
    suspend fun close(id: String, status: String, closedAt: Long, exit: Double, pnl: Double)
}

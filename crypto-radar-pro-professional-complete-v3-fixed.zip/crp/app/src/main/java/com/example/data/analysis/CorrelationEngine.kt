package com.example.data.analysis

import com.example.data.model.Candle
import com.example.data.model.CorrelationSnapshot
import kotlin.math.sqrt

object CorrelationEngine {
    fun calculate(series: Map<String, List<Candle>>): CorrelationSnapshot {
        val symbols = series.keys.toList()
        val returns = symbols.associateWith { s -> series[s].orEmpty().zipWithNext().mapNotNull { (a,b) -> if (a.close > 0) b.close/a.close-1 else null } }
        val matrix = symbols.map { a -> symbols.map { b -> pearson(returns[a].orEmpty(), returns[b].orEmpty()) } }
        val warnings = buildList {
            for (i in symbols.indices) for (j in i+1 until symbols.size) if (matrix[i][j] >= .85) add("${symbols[i]} / ${symbols[j]} highly correlated")
        }.distinct()
        return CorrelationSnapshot(symbols, matrix, warnings)
    }
    private fun pearson(a: List<Double>, b: List<Double>): Double {
        val n=minOf(a.size,b.size); if(n<3)return 0.0
        val x=a.takeLast(n); val y=b.takeLast(n); val mx=x.average(); val my=y.average()
        val num=x.indices.sumOf { (x[it]-mx)*(y[it]-my) }; val dx=sqrt(x.sumOf{(it-mx)*(it-mx)}); val dy=sqrt(y.sumOf{(it-my)*(it-my)})
        return if(dx*dy==0.0)0.0 else (num/(dx*dy)).coerceIn(-1.0,1.0)
    }
}

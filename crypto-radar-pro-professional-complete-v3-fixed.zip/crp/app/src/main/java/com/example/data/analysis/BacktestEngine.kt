package com.example.data.analysis

import com.example.data.model.BacktestResult
import com.example.data.model.Candle
import kotlin.math.abs
import kotlin.math.max

/**
 * Conservative one-bar walk-forward backtest. Signals are calculated only from candles available
 * at the signal timestamp. Fees/slippage are deducted so the headline result is not gross return.
 */
object BacktestEngine {
    fun rsiTrendBacktest(
        candles: List<Candle>,
        feePercentPerSide: Double = 0.04,
        slippagePercentPerSide: Double = 0.02
    ): BacktestResult {
        if (candles.size < 40) return BacktestResult(0, 0, 0, 0.0, 0.0, 0.0,
            feesAndSlippagePercentPerTrade = (feePercentPerSide + slippagePercentPerSide) * 2)

        var wins = 0
        var losses = 0
        var equity = 1.0
        var peak = 1.0
        var maxDd = 0.0
        val returns = mutableListOf<Double>()
        val cost = (feePercentPerSide + slippagePercentPerSide) / 100.0 * 2.0

        for (index in 30 until candles.lastIndex) {
            val history = candles.subList(0, index + 1)
            val ind = TechnicalAnalysisEngine.calculateIndicators(history)
            val entry = candles[index + 1].open
            if (entry <= 0.0) continue
            val atr = ind.atr.takeIf { it > 0 } ?: entry * 0.02
            val longTrade = ind.rsi < 38 && ind.macdHistogram > 0
            val shortTrade = ind.rsi > 62 && ind.macdHistogram < 0
            if (!longTrade && !shortTrade) continue

            val next = candles[index + 1]
            val gross = if (longTrade) ((next.close - entry) / entry) else ((entry - next.close) / entry)
            val capped = gross.coerceIn(-(atr / entry), atr / entry)
            val net = capped - cost
            returns += net
            if (net > 0) wins++ else losses++
            equity *= (1.0 + net).coerceAtLeast(0.0)
            peak = max(peak, equity)
            maxDd = max(maxDd, (peak - equity) / peak * 100.0)
        }

        val trades = returns.size
        val winReturns = returns.filter { it > 0 }
        val lossReturns = returns.filter { it <= 0 }
        val grossProfit = winReturns.sum()
        val grossLoss = abs(lossReturns.sum())
        return BacktestResult(
            trades = trades,
            wins = wins,
            losses = losses,
            winRate = if (trades == 0) 0.0 else wins * 100.0 / trades,
            netReturnPercent = (equity - 1.0) * 100.0,
            maxDrawdownPercent = maxDd,
            profitFactor = if (grossLoss == 0.0) if (grossProfit > 0) Double.POSITIVE_INFINITY else 0.0 else grossProfit / grossLoss,
            expectancyPercent = if (trades == 0) 0.0 else returns.average() * 100.0,
            averageWinPercent = if (winReturns.isEmpty()) 0.0 else winReturns.average() * 100.0,
            averageLossPercent = if (lossReturns.isEmpty()) 0.0 else lossReturns.average() * 100.0,
            feesAndSlippagePercentPerTrade = (feePercentPerSide + slippagePercentPerSide) * 2
        )
    }
}

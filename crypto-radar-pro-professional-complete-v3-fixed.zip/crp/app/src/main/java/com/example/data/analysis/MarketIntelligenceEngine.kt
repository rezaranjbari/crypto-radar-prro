package com.example.data.analysis

import com.example.data.model.Candle
import com.example.data.model.DataQuality
import com.example.data.model.DecisionAction
import com.example.data.model.DerivativesSnapshot
import com.example.data.model.MarketIntelligence
import com.example.data.model.TechnicalIndicators
import com.example.data.model.TrendDirection
import kotlin.math.abs

/**
 * Deterministic decision-support layer. The engine is deliberately conservative: insufficient or
 * stale data can downgrade a setup to WAIT/NO_TRADE instead of manufacturing certainty.
 */
object MarketIntelligenceEngine {
    fun analyze(
        symbol: String,
        candles: List<Candle>,
        derivatives: DerivativesSnapshot? = null,
        sourceCount: Int = 1,
        nowMs: Long = System.currentTimeMillis()
    ): MarketIntelligence {
        val valid = candles.filter { it.open > 0 && it.high > 0 && it.low > 0 && it.close > 0 && it.high >= it.low }
        val indicators = TechnicalAnalysisEngine.calculateIndicators(valid)
        val latest = valid.lastOrNull()?.close
        val dataAge = valid.lastOrNull()?.timestamp?.let { (nowMs - it).coerceAtLeast(0L) }
        val fresh = dataAge == null || dataAge <= 36L * 60L * 60L * 1000L
        val missing = buildList {
            if (valid.size < 30) add("حداقل تاریخچه کافی برای تحلیل چندلایه موجود نیست")
            if (latest == null) add("قیمت معتبر موجود نیست")
        }
        val quality = DataQuality(
            score = (100 - missing.size * 30 - (if (!fresh) 25 else 0) - (if (sourceCount < 2) 10 else 0)).coerceIn(0, 100),
            fresh = fresh,
            sourceCount = sourceCount,
            missingCriticalFields = missing,
            warnings = buildList {
                if (!fresh) add("آخرین کندل قدیمی است")
                if (sourceCount < 2) add("تأیید چندمنبعی محدود است")
            }
        )
        if (latest == null || valid.size < 20) {
            return MarketIntelligence(symbol, DecisionAction.NO_TRADE, 0, 0, quality, 0, 0, 0, 0, 0, 0,
                reasons = listOf("داده کافی برای تصمیم معاملاتی وجود ندارد"),
                warnings = quality.warnings + quality.missingCriticalFields,
                invalidation = "پس از دریافت داده معتبر دوباره تحلیل شود")
        }

        val trendScore = scoreTrend(indicators)
        val momentumScore = scoreMomentum(indicators)
        val volumeScore = scoreVolume(indicators)
        val structure = MarketStructureEngine.analyze(valid)
        val structureScore = scoreStructure(structure.trend, structure.breakout)
        val derivativesScore = scoreDerivatives(derivatives)
        val riskScore = scoreRisk(indicators, latest, structure)

        val raw = (trendScore * .24 + momentumScore * .18 + volumeScore * .12 + structureScore * .18 + derivativesScore * .12 + riskScore * .16).toInt()
        val score = if (raw >= 50) raw else 100 - raw
        val bullish = trendScore >= 60 && momentumScore >= 50 && structureScore >= 50
        val bearish = trendScore <= 40 && momentumScore <= 50 && structureScore <= 50
        val riskTooHigh = riskScore < 30 || quality.score < 60
        val action = when {
            riskTooHigh -> DecisionAction.NO_TRADE
            bullish && raw >= 68 -> DecisionAction.LONG
            bearish && raw <= 32 -> DecisionAction.SHORT
            else -> DecisionAction.WAIT
        }

        val atr = indicators.atr.takeIf { it > 0 } ?: latest * .02
        val entryMin = latest - atr * .25
        val entryMax = latest + atr * .25
        val stop = when (action) {
            DecisionAction.LONG -> latest - atr * 1.5
            DecisionAction.SHORT -> latest + atr * 1.5
            else -> null
        }
        val tp1 = when (action) {
            DecisionAction.LONG -> latest + atr * 2.0
            DecisionAction.SHORT -> latest - atr * 2.0
            else -> null
        }
        val tp2 = when (action) {
            DecisionAction.LONG -> latest + atr * 3.2
            DecisionAction.SHORT -> latest - atr * 3.2
            else -> null
        }
        val rr = if (stop != null && tp1 != null) abs(tp1 - latest) / abs(latest - stop) else null
        val confidence = ((quality.score * .35) + (abs(raw - 50) * 1.2) + if (derivatives != null) 10 else 0).toInt().coerceIn(0, 95)

        val reasons = buildList {
            add("روند چندتایم‌فریمی: ${trendLabel(indicators)}")
            add("RSI: ${"%.1f".format(indicators.rsi)} | MACD: ${"%.4f".format(indicators.macdHistogram)}")
            add("نسبت حجم: ${"%.2f".format(indicators.volumeRatio)}x")
            if (structure.breakout != null) add("ساختار: ${structure.breakout}")
            derivatives?.fundingBias?.let { add("فاندینگ: $it") }
        }
        val warnings = buildList {
            addAll(quality.warnings)
            if (indicators.rsi > 75 || indicators.rsi < 25) add("RSI در ناحیه افراطی است")
            if (structure.fakeBreakoutRisk) add("ریسک شکست کاذب بالاست")
            if (rr != null && rr < 1.5) add("نسبت سود به زیان کمتر از 1.5 است")
        }
        return MarketIntelligence(symbol, action, score, confidence, quality, trendScore, momentumScore, volumeScore,
            structureScore, derivativesScore, riskScore, entryMin, entryMax, stop, tp1, tp2, rr, reasons, warnings,
            when (action) {
                DecisionAction.LONG -> "بسته‌شدن معتبر زیر حمایت ساختاری/حد ضرر"
                DecisionAction.SHORT -> "بازپس‌گیری مقاومت ساختاری/حد ضرر"
                else -> "تغییر معتبر ساختار و هم‌جهتی چندتایم‌فریمی"
            })
    }

    private fun scoreTrend(i: TechnicalIndicators): Int {
        val states = listOf(i.trend15m, i.trend1h, i.trend4h, i.trend1d)
        return states.map { state -> when (state) { TrendDirection.BULLISH -> 25; TrendDirection.NEUTRAL -> 12; TrendDirection.BEARISH -> 0 } }.sum().coerceIn(0, 100)
    }
    private fun scoreMomentum(i: TechnicalIndicators): Int = when {
        i.rsi in 45.0..68.0 && i.macdHistogram > 0 -> 85
        i.rsi in 32.0..72.0 -> 60
        i.rsi < 25 || i.rsi > 80 -> 35
        else -> 45
    }
    private fun scoreVolume(i: TechnicalIndicators): Int = when {
        i.volumeRatio >= 2.0 -> 90
        i.volumeRatio >= 1.3 -> 75
        i.volumeRatio >= .8 -> 55
        else -> 35
    }
    private fun scoreStructure(trend: TrendDirection, breakout: String?): Int = when {
        breakout?.contains("Upside") == true -> 90
        breakout?.contains("Downside") == true -> 10
        trend == TrendDirection.BULLISH -> 70
        trend == TrendDirection.BEARISH -> 30
        else -> 50
    }
    private fun scoreDerivatives(d: DerivativesSnapshot?): Int = when {
        d == null -> 50
        d.fundingRate == null -> 50
        d.fundingRate in -0.0003..0.0003 -> 65
        d.fundingRate > 0.001 -> 35
        d.fundingRate < -0.001 -> 65
        else -> 50
    }
    private fun scoreRisk(i: TechnicalIndicators, price: Double, s: com.example.data.model.MarketStructureSnapshot): Int {
        val atrPct = if (price > 0) i.atr / price * 100 else 100.0
        var score = when { atrPct < 2 -> 85; atrPct < 4 -> 65; atrPct < 7 -> 45; else -> 20 }
        if (s.fakeBreakoutRisk) score -= 20
        return score.coerceIn(0,100)
    }
    private fun trendLabel(i: TechnicalIndicators): String = listOf(i.trend15m, i.trend1h, i.trend4h, i.trend1d).joinToString("/")
}

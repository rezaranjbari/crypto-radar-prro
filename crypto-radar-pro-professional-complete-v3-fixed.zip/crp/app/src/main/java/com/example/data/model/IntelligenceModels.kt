package com.example.data.model

/**
 * Transparent, deterministic decision-support output. It never represents a guarantee or an
 * instruction to execute a trade.
 */
enum class DecisionAction { LONG, SHORT, WAIT, NO_TRADE }

data class DataQuality(
    val score: Int,
    val fresh: Boolean,
    val sourceCount: Int,
    val missingCriticalFields: List<String> = emptyList(),
    val warnings: List<String> = emptyList()
)

data class MarketIntelligence(
    val symbol: String,
    val action: DecisionAction,
    val score: Int,
    val confidence: Int,
    val dataQuality: DataQuality,
    val trendScore: Int,
    val momentumScore: Int,
    val volumeScore: Int,
    val structureScore: Int,
    val derivativesScore: Int,
    val riskScore: Int,
    val entryMin: Double? = null,
    val entryMax: Double? = null,
    val stopLoss: Double? = null,
    val takeProfit1: Double? = null,
    val takeProfit2: Double? = null,
    val riskReward: Double? = null,
    val reasons: List<String> = emptyList(),
    val warnings: List<String> = emptyList(),
    val invalidation: String = ""
)

package com.example.data.model

enum class FeedStatus { LIVE, DEGRADED, UNAVAILABLE, CONFIG_REQUIRED }

data class ProviderHealth(val provider: String, val status: FeedStatus, val latencyMs: Long? = null, val message: String = "", val updatedAt: Long = System.currentTimeMillis())

data class MarketRegimeSnapshot(val regime: String, val confidence: Int, val volatility: Double, val breadth: Double?, val btcTrend: TrendDirection, val notes: List<String> = emptyList())

data class LiquidationSnapshot(val longUsd: Double? = null, val shortUsd: Double? = null, val largestZone: Double? = null, val status: FeedStatus = FeedStatus.UNAVAILABLE, val source: String = "", val timestamp: Long = System.currentTimeMillis())

data class SmartMoneySnapshot(val netFlowUsd: Double? = null, val whaleTransactions: Int? = null, val accumulationScore: Int? = null, val status: FeedStatus = FeedStatus.UNAVAILABLE, val source: String = "", val timestamp: Long = System.currentTimeMillis())

data class OnChainIntelligence(val activeAddresses: Long? = null, val txCount: Long? = null, val exchangeNetflowUsd: Double? = null, val holderChangePercent: Double? = null, val status: FeedStatus = FeedStatus.UNAVAILABLE, val source: String = "", val timestamp: Long = System.currentTimeMillis())

data class CrossExchangeSnapshot(val symbol: String, val prices: Map<String, Double>, val spreadPercent: Double?, val volumeLeader: String?, val anomaly: Boolean, val status: FeedStatus, val timestamp: Long = System.currentTimeMillis())

data class UnlockEvent(val symbol: String, val eventTime: Long, val valueUsd: Double?, val percentSupply: Double?, val type: String, val status: FeedStatus = FeedStatus.UNAVAILABLE, val source: String = "")

data class EventRisk(val title: String, val eventTime: Long, val importance: Int, val affectedSymbols: List<String> = emptyList(), val source: String? = null)

data class NewsInsight(val title: String, val source: String, val sentiment: Double, val impact: Int, val duplicateGroup: String? = null, val symbols: List<String> = emptyList(), val publishedAt: Long? = null)

data class TraderIntelligenceSnapshot(val traders: List<TraderProfile>, val consensus: TraderConsensus, val status: FeedStatus, val source: String = "", val warnings: List<String> = emptyList())

data class PositionSimulation(val symbol: String, val side: TradeSide, val capitalUsd: Double, val riskPercent: Double, val leverage: Double, val entry: Double, val stop: Double, val target: Double, val quantity: Double, val maxLossUsd: Double, val targetProfitUsd: Double, val liquidationBufferPercent: Double?, val rr: Double)

data class PortfolioAnalytics(val totalUsd: Double, val weightedPnlPercent: Double, val concentrationPercent: Double, val sectorExposure: Map<String, Double>, val warnings: List<String>, val correlation: CorrelationSnapshot?)

data class StrategyEvaluation(val name: String, val inSample: StrategyTestResult, val outOfSample: StrategyTestResult, val robustnessScore: Int, val overfitRisk: Int, val notes: List<String> = emptyList())

data class SignalCalibration(val sampleSize: Int, val brierScore: Double?, val calibrationError: Double?, val confidenceBucketAccuracy: Map<String, Double>, val status: FeedStatus, val warnings: List<String> = emptyList())

data class PaperTrade(val id: String, val symbol: String, val side: TradeSide, val entry: Double, val stop: Double, val target: Double, val quantity: Double, val openedAt: Long, val closedAt: Long? = null, val exit: Double? = null, val pnlUsd: Double? = null, val status: String = "OPEN")

data class FeatureCapability(val key: String, val name: String, val status: FeedStatus, val detail: String, val requiresKey: Boolean = false)

data class ProfessionalFeatureSnapshot(
    val regime: MarketRegimeSnapshot,
    val liquidation: LiquidationSnapshot,
    val smartMoney: SmartMoneySnapshot,
    val onChain: OnChainIntelligence,
    val crossExchange: CrossExchangeSnapshot,
    val unlocks: List<UnlockEvent>,
    val events: List<EventRisk>,
    val news: List<NewsInsight>,
    val traderIntelligence: TraderIntelligenceSnapshot,
    val portfolio: PortfolioAnalytics?,
    val signalCalibration: SignalCalibration,
    val strategyEvaluations: List<StrategyEvaluation>,
    val providerHealth: List<ProviderHealth>,
    val capabilities: List<FeatureCapability>
)

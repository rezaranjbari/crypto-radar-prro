# Crypto Radar Pro

Android app (Kotlin + Jetpack Compose) for multi-source crypto market scanning and technical analysis, in Persian and English.

Data sources: Binance, CoinGecko, CoinCap, CryptoCompare News. No API key is required.

> This app is informational only. It is not financial advice.

## Get the APK from GitHub

1. Push this project to a GitHub repository.
2. Open the **Actions** tab, then **Build APK**, then **Run workflow** (it also runs on every push).
3. When the run finishes, download **crypto-radar-pro-debug-apk** from the run's Artifacts section.
4. Unzip it and install the `.apk` on your phone (allow installs from unknown sources).

## Build locally

Open the folder in Android Studio and run. Requires JDK 17+.

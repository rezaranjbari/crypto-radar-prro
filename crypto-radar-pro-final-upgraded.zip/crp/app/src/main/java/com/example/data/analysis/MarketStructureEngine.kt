package com.example.data.analysis

import com.example.data.model.Candle
import com.example.data.model.MarketStructureSnapshot
import com.example.data.model.TrendDirection
import kotlin.math.abs

object MarketStructureEngine {
    fun analyze(candles: List<Candle>): MarketStructureSnapshot {
        if (candles.size < 12) return MarketStructureSnapshot()
        val recent = candles.takeLast(40)
        val highs = recent.map { it.high }
        val lows = recent.map { it.low }
        val last = recent.last().close
        val prevHigh = highs.dropLast(3).maxOrNull() ?: last
        val prevLow = lows.dropLast(3).minOrNull() ?: last
        val recentHigh = highs.takeLast(5).maxOrNull() ?: last
        val recentLow = lows.takeLast(5).minOrNull() ?: last
        val atr = TechnicalAnalysisEngine.calculateIndicators(recent).atr.coerceAtLeast(last * 0.001)
        val breakout = when {
            last > prevHigh + atr * 0.15 -> "Upside breakout"
            last < prevLow - atr * 0.15 -> "Downside breakout"
            else -> null
        }
        val fakeRisk = breakout != null && abs(last - recentHigh.coerceAtLeast(recentLow)) < atr * 0.35
        val trend = when {
            last > recentHigh * 0.995 -> TrendDirection.BULLISH
            last < recentLow * 1.005 -> TrendDirection.BEARISH
            else -> TrendDirection.NEUTRAL
        }
        return MarketStructureSnapshot(
            trend = trend,
            bos = breakout,
            choch = if (trend == TrendDirection.BULLISH && recentLow > prevLow) "Bullish CHoCH" else if (trend == TrendDirection.BEARISH && recentHigh < prevHigh) "Bearish CHoCH" else null,
            breakout = breakout,
            fakeBreakoutRisk = fakeRisk,
            support = listOf(recentLow, prevLow).distinct().sortedDescending().take(3),
            resistance = listOf(recentHigh, prevHigh).distinct().sorted().take(3),
            liquidityHigh = listOf(prevHigh, recentHigh).distinct(),
            liquidityLow = listOf(prevLow, recentLow).distinct()
        )
    }
}

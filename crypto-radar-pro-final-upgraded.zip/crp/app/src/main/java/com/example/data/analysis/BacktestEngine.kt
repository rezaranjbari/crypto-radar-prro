package com.example.data.analysis

import com.example.data.model.BacktestResult
import com.example.data.model.Candle
import kotlin.math.max

object BacktestEngine {
    fun rsiTrendBacktest(candles: List<Candle>): BacktestResult {
        if (candles.size < 40) return BacktestResult(0, 0, 0, 0.0, 0.0, 0.0)
        var wins = 0; var losses = 0; var equity = 1.0; var peak = 1.0; var maxDd = 0.0
        for (index in 30 until candles.lastIndex) {
            val window = candles.subList(0, index + 1)
            val ind = TechnicalAnalysisEngine.calculateIndicators(window)
            val entry = candles[index].close
            val atr = ind.atr.takeIf { it > 0 } ?: entry * 0.02
            val longTrade = ind.rsi < 38 && ind.macdHistogram > 0
            val shortTrade = ind.rsi > 62 && ind.macdHistogram < 0
            if (!longTrade && !shortTrade) continue
            val next = candles[index + 1]
            val ret = if (longTrade) ((next.close - entry) / entry) else ((entry - next.close) / entry)
            val capped = ret.coerceIn(-atr / entry, atr / entry)
            if (capped > 0) wins++ else losses++
            equity *= (1.0 + capped)
            peak = max(peak, equity)
            maxDd = max(maxDd, (peak - equity) / peak * 100.0)
        }
        val trades = wins + losses
        return BacktestResult(trades, wins, losses, if (trades == 0) 0.0 else wins * 100.0 / trades, (equity - 1.0) * 100.0, maxDd)
    }
}

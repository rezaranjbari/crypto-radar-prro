package com.example.data.model

enum class TradeSide { LONG, SHORT, NEUTRAL }

data class TradeSignal(
    val symbol: String,
    val side: TradeSide,
    val timeframe: String,
    val entryMin: Double,
    val entryMax: Double,
    val stopLoss: Double,
    val takeProfit1: Double,
    val takeProfit2: Double,
    val riskReward1: Double,
    val riskReward2: Double,
    val confidence: Int,
    val reasons: List<String>,
    val invalidation: String,
    val generatedAt: Long = System.currentTimeMillis()
)

data class BacktestResult(
    val trades: Int,
    val wins: Int,
    val losses: Int,
    val winRate: Double,
    val netReturnPercent: Double,
    val maxDrawdownPercent: Double
)

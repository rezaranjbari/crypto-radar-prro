package com.example.data.local

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "trading_journal")
data class TradingJournalEntity(
    @androidx.room.PrimaryKey(autoGenerate = true) val id: Long = 0,
    val symbol: String,
    val side: String,
    val entry: Double,
    val stop: Double,
    val target: Double,
    val resultPercent: Double? = null,
    val note: String = "",
    val openedAt: Long = System.currentTimeMillis(),
    val closedAt: Long? = null
)

@Dao
interface TradingJournalDao {
    @Query("SELECT * FROM trading_journal ORDER BY openedAt DESC LIMIT 100")
    fun observe(): Flow<List<TradingJournalEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: TradingJournalEntity)
}

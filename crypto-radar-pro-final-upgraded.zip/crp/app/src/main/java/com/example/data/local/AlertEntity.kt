package com.example.data.local

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "price_alerts")
data class AlertEntity(
    @androidx.room.PrimaryKey(autoGenerate = true) val id: Long = 0,
    val symbol: String,
    val targetPrice: Double,
    val direction: String,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val lastTriggeredAt: Long? = null
)

@Dao
interface AlertDao {
    @Query("SELECT * FROM price_alerts WHERE enabled = 1 ORDER BY createdAt DESC")
    fun observeActive(): Flow<List<AlertEntity>>

    @Query("SELECT * FROM price_alerts WHERE enabled = 1")
    suspend fun getActive(): List<AlertEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: AlertEntity)

    @Query("UPDATE price_alerts SET enabled = 0 WHERE id = :id")
    suspend fun disable(id: Long)

    @Query("UPDATE price_alerts SET lastTriggeredAt = :timestamp WHERE id = :id")
    suspend fun markTriggered(id: Long, timestamp: Long)
}

package com.example.data.analysis

import com.example.data.model.RiskPlan
import kotlin.math.abs

object RiskManagementEngine {
    fun plan(balance: Double?, riskPercent: Double, entry: Double, stop: Double, target1: Double, target2: Double): RiskPlan {
        val riskPct = riskPercent.coerceIn(0.1, 5.0)
        val riskMoney = balance?.let { it * riskPct / 100.0 }
        val perUnitRisk = abs(entry - stop).coerceAtLeast(1e-12)
        val size = riskMoney?.div(perUnitRisk)
        return RiskPlan(
            accountBalance = balance,
            riskPercent = riskPct,
            entry = entry,
            stop = stop,
            target1 = target1,
            target2 = target2,
            positionSize = size,
            maxLoss = riskMoney,
            rrTarget1 = abs(target1 - entry) / perUnitRisk,
            rrTarget2 = abs(target2 - entry) / perUnitRisk
        )
    }
}

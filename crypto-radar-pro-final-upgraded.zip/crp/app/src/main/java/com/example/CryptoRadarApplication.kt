package com.example

import android.app.Application
import com.example.notifications.AlertScheduler

class CryptoRadarApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AlertScheduler.schedule(this)
    }
}

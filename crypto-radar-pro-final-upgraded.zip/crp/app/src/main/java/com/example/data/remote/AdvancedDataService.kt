package com.example.data.remote

import android.util.Log
import com.example.data.model.DerivativesSnapshot
import com.example.data.model.IranExchangeQuote
import com.example.data.model.IranMarketSnapshot
import com.example.data.model.MacroEvent
import com.example.data.model.OnChainSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.math.abs

object AdvancedDataService {
    private val client = OkHttpClient.Builder().connectTimeout(8, TimeUnit.SECONDS).readTimeout(10, TimeUnit.SECONDS).build()

    private fun get(url: String): String? = runCatching {
        client.newCall(Request.Builder().url(url).header("User-Agent", "CryptoRadarPro/2.0").build()).execute().use { response ->
            if (response.isSuccessful) response.body?.string() else null
        }
    }.getOrNull()

    suspend fun derivatives(symbols: List<String>): List<DerivativesSnapshot> = withContext(Dispatchers.IO) {
        coroutineScope {
            symbols.distinct().take(12).map { symbol ->
                async {
                    val s = symbol.uppercase()
                    val oi = get("https://fapi.binance.com/fapi/v1/openInterest?symbol=${s}USDT")?.let { JSONObject(it).optString("openInterest").toDoubleOrNull() }
                    val premium = get("https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${s}USDT")?.let {
                        val j = JSONObject(it)
                        Triple(j.optString("lastFundingRate").toDoubleOrNull(), j.optString("markPrice").toDoubleOrNull(), j.optString("indexPrice").toDoubleOrNull())
                    }
                    val trades = get("https://fapi.binance.com/fapi/v1/aggTrades?symbol=${s}USDT&limit=1000")
                    var buy = 0.0; var sell = 0.0
                    trades?.let { raw -> runCatching {
                        val arr = JSONArray(raw)
                        for (idx in 0 until arr.length()) {
                            val t = arr.optJSONObject(idx) ?: continue
                            val price = t.optString("p").toDoubleOrNull() ?: continue
                            val qty = t.optString("q").toDoubleOrNull() ?: continue
                            val notional = price * qty
                            if (notional < 50_000.0) continue
                            if (t.optBoolean("m", false)) sell += notional else buy += notional
                        }
                    } }
                    DerivativesSnapshot(s, oi, premium?.first, premium?.second, premium?.third, buy, sell)
                }
            }.awaitAll()
        }
    }

    suspend fun iranMarket(): IranMarketSnapshot = withContext(Dispatchers.IO) {
        val quotes = mutableListOf<IranExchangeQuote>()
        parseNobitex(get("https://api.nobitex.ir/v2/orderbook/USDTIRT"))?.let { quotes += it }
        parseWallex(get("https://api.wallex.ir/v1/depth?symbol=USDTTMN"))?.let { quotes += it }
        parseBitpin(get("https://api.bitpin.ir/v1/mth/otc/orderbook/?symbol=USDT_IRT"))?.let { quotes += it }
        val globalIrrPerUsd = get("https://open.er-api.com/v6/latest/USD")?.let { JSONObject(it).optJSONObject("rates")?.optDouble("IRR", Double.NaN) }?.takeIf { !it.isNaN() }
        val premium = globalIrrPerUsd?.let { fx -> quotes.map { (it.mid / fx - 1.0) * 100.0 }.takeIf { it.isNotEmpty() }?.average() }
        IranMarketSnapshot(quotes, globalIrrPerUsd, premium, quotes.maxByOrNull { it.bid }?.exchange, quotes.minByOrNull { it.ask }?.exchange)
    }

    private fun parsePairs(exchange: String, json: String?, path: (JSONObject) -> Pair<Double, Double>?): IranExchangeQuote? {
        return runCatching { json?.let { path(JSONObject(it)) }?.let { IranExchangeQuote(exchange, "USDTIRT", it.first, it.second, (it.first + it.second) / 2.0) } }.getOrNull()
    }

    private fun parseNobitex(json: String?): IranExchangeQuote? = parsePairs("Nobitex", json) { root ->
        fun side(name: String): Double? = root.optJSONArray(name)?.optJSONArray(0)?.optString(0)?.toDoubleOrNull()
        val bid = side("bids") ?: return@parsePairs null
        val ask = side("asks") ?: return@parsePairs null
        bid to ask
    }

    private fun parseWallex(json: String?): IranExchangeQuote? = parsePairs("Wallex", json) { root ->
        val result = root.optJSONObject("result") ?: root
        val bids = result.optJSONArray("bids") ?: return@parsePairs null
        val asks = result.optJSONArray("asks") ?: return@parsePairs null
        val bid = bids.optJSONArray(0)?.optDouble(0, Double.NaN)?.takeIf { !it.isNaN() } ?: return@parsePairs null
        val ask = asks.optJSONArray(0)?.optDouble(0, Double.NaN)?.takeIf { !it.isNaN() } ?: return@parsePairs null
        bid to ask
    }

    private fun parseBitpin(json: String?): IranExchangeQuote? = parsePairs("Bitpin", json) { root ->
        val bids = root.optJSONArray("bids") ?: return@parsePairs null
        val asks = root.optJSONArray("asks") ?: return@parsePairs null
        val bid = bids.optJSONArray(0)?.optString(0)?.toDoubleOrNull() ?: return@parsePairs null
        val ask = asks.optJSONArray(0)?.optString(0)?.toDoubleOrNull() ?: return@parsePairs null
        bid to ask
    }

    suspend fun macroEvents(): List<MacroEvent> = withContext(Dispatchers.IO) {
        // No synthetic events: this module intentionally returns only events when a trusted feed is added.
        emptyList()
    }

    suspend fun onChain(symbols: List<String>): List<OnChainSnapshot> = withContext(Dispatchers.IO) {
        // No fabricated on-chain values. Provider-specific APIs can be enabled later without changing the UI contract.
        symbols.map { OnChainSnapshot(symbol = it) }
    }
}

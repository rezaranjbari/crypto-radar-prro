package com.example.data.analysis

import com.example.data.model.Candle
import com.example.data.model.CryptoAsset
import com.example.data.model.TechnicalIndicators
import com.example.data.model.TradeSide
import com.example.data.model.TradeSignal
import kotlin.math.abs

object SignalEngine {
    fun build(asset: CryptoAsset, candles: List<Candle>, timeframe: String = "4h"): TradeSignal {
        val i = TechnicalAnalysisEngine.calculateIndicators(candles)
        val price = asset.priceUsd
        val atr = i.atr.takeIf { it > 0 } ?: price * 0.02
        val bullish = listOf(i.trend1h, i.trend4h, i.trend1d).count { it.name == "BULLISH" }
        val bearish = listOf(i.trend1h, i.trend4h, i.trend1d).count { it.name == "BEARISH" }
        val side = when {
            bullish >= 2 && i.rsi < 72 && i.macdHistogram >= 0 -> TradeSide.LONG
            bearish >= 2 && i.rsi > 28 && i.macdHistogram <= 0 -> TradeSide.SHORT
            else -> TradeSide.NEUTRAL
        }
        val entryMin = price - atr * 0.25
        val entryMax = price + atr * 0.25
        val stop = when (side) { TradeSide.LONG -> price - atr * 1.4; TradeSide.SHORT -> price + atr * 1.4; TradeSide.NEUTRAL -> price }
        val tp1 = when (side) { TradeSide.LONG -> price + atr * 1.8; TradeSide.SHORT -> price - atr * 1.8; TradeSide.NEUTRAL -> price }
        val tp2 = when (side) { TradeSide.LONG -> price + atr * 3.2; TradeSide.SHORT -> price - atr * 3.2; TradeSide.NEUTRAL -> price }
        val risk = abs(price - stop).coerceAtLeast(1e-12)
        val rr1 = abs(tp1 - price) / risk
        val rr2 = abs(tp2 - price) / risk
        val confidence = when {
            side == TradeSide.NEUTRAL -> 45
            bullish == 3 || bearish == 3 -> 82
            bullish == 2 || bearish == 2 -> 68
            else -> 55
        }
        val reasons = buildList {
            add("RSI=${"%.1f".format(i.rsi)}")
            add("MACD histogram=${"%.5f".format(i.macdHistogram)}")
            add("Volume=${"%.2f".format(i.volumeRatio)}x")
            add("MTF alignment: $bullish bullish / $bearish bearish")
        }
        return TradeSignal(asset.symbol, side, timeframe, entryMin, entryMax, stop, tp1, tp2, rr1, rr2, confidence, reasons, "Invalidation when price closes beyond stop/structure level")
    }
}

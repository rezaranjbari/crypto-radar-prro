package com.example.data.model

data class DerivativesSnapshot(
    val symbol: String,
    val openInterest: Double? = null,
    val fundingRate: Double? = null,
    val markPrice: Double? = null,
    val indexPrice: Double? = null,
    val largeTradeBuyVolume: Double? = null,
    val largeTradeSellVolume: Double? = null,
    val timestamp: Long = System.currentTimeMillis()
) {
    val fundingBias: String
        get() = when {
            fundingRate == null -> "Unavailable"
            fundingRate > 0.0005 -> "Long crowded"
            fundingRate < -0.0005 -> "Short crowded"
            else -> "Balanced"
        }
}

data class IranExchangeQuote(
    val exchange: String,
    val symbol: String,
    val bid: Double,
    val ask: Double,
    val last: Double? = null,
    val timestamp: Long = System.currentTimeMillis()
) {
    val mid: Double get() = (bid + ask) / 2.0
}

data class IranMarketSnapshot(
    val usdtIrt: List<IranExchangeQuote> = emptyList(),
    val globalUsdtUsd: Double? = null,
    val averagePremiumPercent: Double? = null,
    val bestBidExchange: String? = null,
    val bestAskExchange: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class MarketStructureSnapshot(
    val trend: TrendDirection = TrendDirection.NEUTRAL,
    val bos: String? = null,
    val choch: String? = null,
    val breakout: String? = null,
    val fakeBreakoutRisk: Boolean = false,
    val support: List<Double> = emptyList(),
    val resistance: List<Double> = emptyList(),
    val liquidityHigh: List<Double> = emptyList(),
    val liquidityLow: List<Double> = emptyList()
)

data class RiskPlan(
    val accountBalance: Double? = null,
    val riskPercent: Double = 1.0,
    val entry: Double,
    val stop: Double,
    val target1: Double,
    val target2: Double,
    val positionSize: Double? = null,
    val maxLoss: Double? = null,
    val rrTarget1: Double? = null,
    val rrTarget2: Double? = null
)

data class MacroEvent(
    val title: String,
    val country: String,
    val eventTime: Long,
    val importance: String,
    val sourceUrl: String? = null
)

data class OnChainSnapshot(
    val symbol: String,
    val activeAddresses: Long? = null,
    val transactionCount: Long? = null,
    val networkValueUsd: Double? = null,
    val source: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

data class ProAnalyticsSnapshot(
    val derivatives: List<DerivativesSnapshot> = emptyList(),
    val iranMarket: IranMarketSnapshot = IranMarketSnapshot(),
    val macroEvents: List<MacroEvent> = emptyList(),
    val onChain: List<OnChainSnapshot> = emptyList(),
    val generatedAt: Long = System.currentTimeMillis()
)

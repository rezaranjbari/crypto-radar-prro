package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MarketRoute
import com.example.data.model.ProAnalyticsSnapshot
import com.example.data.model.TrendDirection
import com.example.ui.localization.AppLanguage
import com.example.ui.localization.Strings
import com.example.ui.theme.RadarBg
import com.example.ui.theme.RadarCyan
import com.example.ui.theme.RadarBorder
import com.example.ui.theme.RadarSurface
import com.example.ui.theme.RadarSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MarketNavigatorScreen(
    route: MarketRoute,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize().background(RadarBg),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Explore, null, tint = RadarCyan)
                Spacer(Modifier.width(8.dp))
                Text(Strings.navigatorHeader(language), color = TextPrimary, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            }
        }
        item { RouteCard(route, language) }
        item { SectionCard(Strings.navigatorConfirmation(language), route.confirmation) }
        item { SectionCard(Strings.navigatorInvalidation(language), route.invalidation) }
        item { ListCard(Strings.navigatorNextLevels(language), route.nextLevels) }
        item { ListCard(Strings.navigatorCatalysts(language), route.catalysts) }
        item { ListCard(Strings.navigatorRisks(language), route.risks, warning = true) }
        route.proSnapshot?.let { snapshot ->
            item { ProAnalyticsCard(snapshot, language) }
        }
        item {
            Text(
                Strings.navigatorDisclaimer(language),
                color = TextSecondary,
                fontSize = 11.sp,
                lineHeight = 17.sp,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)
            )
        }
    }
}

@Composable private fun RouteCard(route: MarketRoute, language: AppLanguage) {
    val directionText = when (route.direction) {
        TrendDirection.BULLISH -> Strings.navigatorBullish(language)
        TrendDirection.BEARISH -> Strings.navigatorBearish(language)
        TrendDirection.NEUTRAL -> Strings.navigatorNeutral(language)
    }
    Card(colors = CardDefaults.cardColors(containerColor = RadarSurface), shape = RoundedCornerShape(16.dp), border = androidx.compose.foundation.BorderStroke(1.dp, RadarBorder)) {
        Column(Modifier.padding(16.dp)) {
            Text(directionText, color = RadarCyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Text(route.headline, color = TextPrimary, fontSize = 14.sp, lineHeight = 21.sp)
            Spacer(Modifier.height(10.dp))
            Text(Strings.navigatorRegime(language) + ": ${route.regime}", color = TextSecondary, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Text(Strings.navigatorConfidence(language) + ": ${route.confidence}%", color = TextPrimary, fontSize = 12.sp)
            Spacer(Modifier.height(5.dp))
            LinearProgressIndicator(progress = { route.confidence / 100f }, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable private fun SectionCard(title: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = RadarSurface), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = RadarCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text(body, color = TextPrimary, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

@Composable private fun ListCard(title: String, items: List<String>, warning: Boolean = false) {
    Card(colors = CardDefaults.cardColors(containerColor = if (warning) RadarSurfaceVariant else RadarSurface), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (warning) Icon(Icons.Default.WarningAmber, null, tint = RadarCyan, modifier = Modifier.padding(end = 6.dp))
                Text(title, color = RadarCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Spacer(Modifier.height(6.dp))
            items.forEach { Text("• $it", color = TextPrimary, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(vertical = 2.dp)) }
        }
    }
}


@Composable
private fun ProAnalyticsCard(snapshot: ProAnalyticsSnapshot, language: AppLanguage) {
    Card(colors = CardDefaults.cardColors(containerColor = RadarSurface), shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, RadarBorder)) {
        Column(Modifier.padding(14.dp)) {
            Text(if (language == AppLanguage.PERSIAN) "تحلیل حرفه‌ای بازار" else "Pro Market Analytics", color = RadarCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(8.dp))
            Text(if (language == AppLanguage.PERSIAN) "مشتقات و احساسات" else "Derivatives & positioning", color = TextSecondary, fontSize = 12.sp)
            snapshot.derivatives.take(6).forEach { d ->
                Text(
                    "${d.symbol}: OI=${d.openInterest?.let { String.format(java.util.Locale.US, "%.2f", it) } ?: "—"} | Funding=${d.fundingRate?.let { String.format(java.util.Locale.US, "%.4f%%", it * 100) } ?: "—"} | ${d.fundingBias}",
                    color = TextPrimary, fontSize = 11.sp, modifier = Modifier.padding(vertical = 2.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(if (language == AppLanguage.PERSIAN) "بازار ایران" else "Iran market", color = RadarCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            if (snapshot.iranMarket.usdtIrt.isEmpty()) {
                Text(if (language == AppLanguage.PERSIAN) "داده صرافی‌های ایران در دسترس نیست." else "Iran exchange data unavailable.", color = TextSecondary, fontSize = 11.sp)
            } else {
                snapshot.iranMarket.usdtIrt.forEach { q ->
                    Text("${q.exchange}: bid=${q.bid} | ask=${q.ask}", color = TextPrimary, fontSize = 11.sp, modifier = Modifier.padding(vertical = 2.dp))
                }
                snapshot.iranMarket.averagePremiumPercent?.let {
                    Text(if (language == AppLanguage.PERSIAN) "پریمیوم تقریبی: %.2f%%".format(java.util.Locale.US, it) else "Approx. premium: %.2f%%".format(java.util.Locale.US, it), color = TextPrimary, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(if (language == AppLanguage.PERSIAN) "آن‌چین و اقتصاد کلان" else "On-chain & macro", color = RadarCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(if (snapshot.macroEvents.isEmpty()) (if (language == AppLanguage.PERSIAN) "تقویم کلان تأییدشده فعلاً متصل نیست." else "Verified macro calendar is not connected yet.") else "${snapshot.macroEvents.size} events", color = TextSecondary, fontSize = 11.sp)
            snapshot.onChain.take(5).forEach { c ->
                Text("${c.symbol}: ${c.source ?: "provider unavailable"}", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(vertical = 1.dp))
            }
            Spacer(Modifier.height(6.dp))
            Text(if (language == AppLanguage.PERSIAN) "داده‌ای که منبع معتبر نداشته باشد ساختگی نمی‌شود؛ به‌جای آن «در دسترس نیست» نمایش داده می‌شود." else "Unverified data is never fabricated; unavailable fields remain unavailable.", color = TextSecondary, fontSize = 10.sp, lineHeight = 15.sp)
        }
    }
}

package com.example.data.analysis

import com.example.data.model.CryptoAsset
import com.example.data.model.MarketOverviewData
import com.example.data.model.MarketRoute
import com.example.data.model.NewsImpact
import com.example.data.model.CryptoNewsItem
import com.example.data.model.TrendDirection
import com.example.data.model.RadarOpportunity

object MarketNavigatorEngine {
    fun buildRoute(
        overview: MarketOverviewData,
        assets: List<CryptoAsset>,
        opportunities: List<RadarOpportunity>,
        news: List<CryptoNewsItem>
    ): MarketRoute {
        val avgAltChange = assets.filter { it.symbol != "BTC" && it.symbol != "ETH" }
            .map { it.change24h }.takeIf { it.isNotEmpty() }?.average() ?: 0.0
        val strongNews = news.count { it.impact == NewsImpact.HIGH && it.isVerified }
        val bullishOpps = opportunities.count { it.score >= 75 && it.indicators.trend4h == TrendDirection.BULLISH }
        val bearishOpps = opportunities.count { it.score >= 75 && it.indicators.trend4h == TrendDirection.BEARISH }

        val direction = when {
            overview.btcChange24h > 1.0 && avgAltChange > 0.5 && bullishOpps >= bearishOpps -> TrendDirection.BULLISH
            overview.btcChange24h < -1.0 && avgAltChange < -0.5 && bearishOpps > bullishOpps -> TrendDirection.BEARISH
            else -> TrendDirection.NEUTRAL
        }

        val confidence = (50 +
            (kotlin.math.abs(overview.btcChange24h).coerceAtMost(4.0) * 7).toInt() +
            (kotlin.math.abs(avgAltChange).coerceAtMost(4.0) * 4).toInt() +
            kotlin.math.min(15, kotlin.math.abs(bullishOpps - bearishOpps) * 3) -
            strongNews * 2).coerceIn(35, 95)

        val headline = when (direction) {
            TrendDirection.BULLISH -> "مسیر غالب بازار فعلاً متمایل به صعود است؛ تأیید شکست و حجم را دنبال کن."
            TrendDirection.BEARISH -> "مسیر غالب بازار فعلاً نزولی است؛ حفظ سرمایه و تأیید بازگشت اولویت دارد."
            TrendDirection.NEUTRAL -> "بازار سیگنال یک‌طرفه قدرتمندی ندارد؛ صبر برای تأیید شکست یا برگشت منطقی‌تر است."
        }

        val top = opportunities.sortedByDescending { it.score }.take(3)
        val levels = top.map { "${it.asset.symbol}: ورود ${fmt(it.entryMin)}–${fmt(it.entryMax)} | TP1 ${fmt(it.target1)} | TP2 ${fmt(it.target2)}" }
        val catalysts = news.filter { it.impact == NewsImpact.HIGH }.take(4).map { "${it.source}: ${it.title}" }
        val risks = mutableListOf<String>()
        if (overview.btcChange24h < -2) risks += "نوسان منفی شدید BTC"
        if (overview.btcChange24h > 4) risks += "احتمال FOMO و اصلاح پس از رشد سریع BTC"
        if (strongNews > 0) risks += "${strongNews} خبر مهم تأییدشده در جریان است"
        if (risks.isEmpty()) risks += "تغییر ناگهانی حجم، اخبار کلان یا شکست سطوح کلیدی"

        return MarketRoute(
            regime = overview.marketRegimeFa,
            direction = direction,
            confidence = confidence,
            headline = headline,
            confirmation = when (direction) {
                TrendDirection.BULLISH -> "بسته‌شدن بالای مقاومت مهم همراه با افزایش حجم و حفظ ساختار HH/HL."
                TrendDirection.BEARISH -> "شکست حمایت کلیدی همراه با حجم و تشکیل LH/LL."
                TrendDirection.NEUTRAL -> "خروج معتبر از محدوده رنج همراه با حجم؛ در غیر این صورت عدم ورود."
            },
            invalidation = when (direction) {
                TrendDirection.BULLISH -> "از دست رفتن حمایت ساختاری و کاهش شدید حجم خرید."
                TrendDirection.BEARISH -> "بازپس‌گیری مقاومت و تثبیت بالای آن با حجم."
                TrendDirection.NEUTRAL -> "شکست معتبر محدوده رنج یکی از دو طرف."
            },
            nextLevels = levels.ifEmpty { listOf("داده کافی برای سطح معاملاتی معتبر در دسترس نیست") },
            risks = risks,
            catalysts = catalysts.ifEmpty { listOf("در حال حاضر خبر مهم تأییدشده‌ای برای مسیرساز بودن در داده موجود نیست") }
        )
    }

    private fun fmt(value: Double): String = when {
        value >= 1000 -> "%.0f".format(value)
        value >= 1 -> "%.2f".format(value)
        else -> "%.6f".format(value)
    }
}

# Crypto Radar Pro

A Persian/English Android crypto market-analysis application focused on multi-source market data, technical analysis, opportunity scanning, market routing, derivatives, Iranian exchange quotes, news, watchlists and persistent price alerts.

## Included capabilities

- Multi-source spot market data: Binance, CoinGecko and CoinCap
- OHLCV candlestick charts with volume
- Technical indicators and multi-timeframe analysis
- Market structure, breakout/fake-breakout and support/resistance analysis
- Opportunity scanner with strategy/timeframe filters
- Market Navigator with regime, direction, confidence, catalysts and invalidation
- Derivatives data: Open Interest, funding and large-trade buy/sell pressure
- Iranian USDT market quotes: Nobitex, Wallex and Bitpin
- Cross-source price discrepancy checks
- Crypto news aggregation with source attribution and timestamps
- Persian RTL and English LTR UI
- Local Room cache for offline fallback
- Watchlist, scan history and trading journal persistence
- Persistent price alerts with Android notifications and background WorkManager checks
- Safe Room migration for the alert schema
- Unit-test stage in CI
- GitHub Actions workflow that correctly builds the nested `crp` Android project and uploads the APK artifact

## Build with GitHub Actions

1. Push the repository to GitHub.
2. Open **Actions**.
3. Select **Build Crypto Radar Pro APK**.
4. Choose **Run workflow**.
5. Download the artifact named `crypto-radar-pro-debug-apk` after the run succeeds.

The workflow deliberately builds from the `crp` project directory, so the previous `gradlew not found` / `Android Gradle project not found` failure caused by the nested ZIP layout is avoided.

## Important data policy

The application does not invent market, on-chain or macro values. If a provider is unavailable, the app uses real cached observations where possible and displays unavailable data rather than fabricating values.

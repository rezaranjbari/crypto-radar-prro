package com.astratrade.pro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

data class Coin(val symbol:String,val price:Double,val change:Double,val volume:Double)
data class Candle(val time:Long,val open:Double,val high:Double,val low:Double,val close:Double,val volume:Double)
data class Analysis(val symbol:String,val price:Double,val score:Double,val signal:String,val rsi:Double,val ema20:Double,val ema50:Double,val ema200:Double,val atr:Double,val entry:Double,val stop:Double,val tp1:Double,val tp2:Double,val regime:String,val funding:Double?,val oiChange:Double?,val support:Double?,val resistance:Double?,val candles:List<Candle>)
data class News(val title:String,val url:String,val source:String)

data class ScanRow(val symbol:String,val score:Double,val signal:String,val change:Double,val volume:Double)

class MarketRepository {
    private val client=OkHttpClient.Builder().build()
    private suspend fun text(url:String):String=withContext(Dispatchers.IO){
        val req=Request.Builder().url(url).header("User-Agent","AstraTradePro/3.0").build()
        client.newCall(req).execute().use { r -> if(!r.isSuccessful) error("HTTP ${r.code}"); r.body?.string() ?: "" }
    }
    private suspend fun json(url:String)=JSONObject(text(url))
    suspend fun topCoins():List<Coin>{
        val a=JSONArray(text("https://data-api.binance.vision/api/v3/ticker/24hr"))
        return buildList { for(i in 0 until a.length()){ val o=a.getJSONObject(i); val s=o.optString("symbol"); if(s.endsWith("USDT") && listOf("UP","DOWN","BULL","BEAR").none{s.contains(it)}) add(Coin(s,o.optDouble("lastPrice"),o.optDouble("priceChangePercent"),o.optDouble("quoteVolume"))) } }.sortedByDescending{it.volume}.take(50)
    }
    suspend fun candles(symbolInput:String,interval:String="4h",limit:Int=240):List<Candle>{
        val s=if(symbolInput.uppercase().endsWith("USDT"))symbolInput.uppercase() else symbolInput.uppercase()+"USDT"
        val a=JSONArray(text("https://data-api.binance.vision/api/v3/klines?symbol=$s&interval=$interval&limit=$limit"))
        return buildList { for(i in 0 until a.length()){val x=a.getJSONArray(i);add(Candle(x.getLong(0),x.getString(1).toDouble(),x.getString(2).toDouble(),x.getString(3).toDouble(),x.getString(4).toDouble(),x.getString(5).toDouble()))} }.dropLast(1)
    }
    private fun ema(v:List<Double>,n:Int):Double { if(v.size<n)return v.last(); var e=v.take(n).average(); val k=2.0/(n+1); for(i in n until v.size)e=v[i]*k+e*(1-k); return e }
    private fun rsi(v:List<Double>,n:Int=14):Double { if(v.size<n+1)return 50.0; var g=0.0;var l=0.0;for(i in 1..n){val d=v[i]-v[i-1];if(d>=0)g+=d else l-=d};var ag=g/n;var al=l/n;for(i in n+1 until v.size){val d=v[i]-v[i-1];ag=(ag*(n-1)+max(d,0.0))/n;al=(al*(n-1)+max(-d,0.0))/n};return if(al==0.0)100.0 else 100-100/(1+ag/al)}
    suspend fun funding(symbol:String):Double?=try{json("https://fapi.binance.com/fapi/v1/premiumIndex?symbol=${symbol.uppercase().removeSuffix("USDT")}USDT").optDouble("lastFundingRate")}catch(_:Exception){null}
    suspend fun oiChange(symbol:String):Double?=try{val s=symbol.uppercase().removeSuffix("USDT")+"USDT";val a=JSONArray(text("https://fapi.binance.com/futures/data/openInterestHist?symbol=$s&period=4h&limit=2"));if(a.length()<2)null else{val x=a.getJSONObject(0).optDouble("sumOpenInterestValue");val y=a.getJSONObject(1).optDouble("sumOpenInterestValue");if(x==0.0)null else(y/x-1)*100}}catch(_:Exception){null}
    suspend fun fearGreed():String=try{json("https://api.alternative.me/fng/?limit=1").getJSONArray("data").getJSONObject(0).optString("value")+" • "+json("https://api.alternative.me/fng/?limit=1").getJSONArray("data").getJSONObject(0).optString("value_classification")}catch(_:Exception){"N/A"}
    suspend fun iranPrices():List<String>{
        val out=mutableListOf<String>()
        try{val o=json("https://api.nobitex.ir/market/stats?dstCurrency=rls").optJSONObject("stats");if(o!=null)for(k in listOf("btc-rls","eth-rls","usdt-rls")){val x=o.optJSONObject(k);if(x!=null)out.add("Nobitex ${k.uppercase()}: ${x.optString("latest")}")}}catch(_:Exception){}
        try{val a=JSONArray(text("https://api.wallex.ir/v1/markets")); for(i in 0 until min(5,a.length())){val x=a.getJSONObject(i);out.add("Wallex ${x.optString("symbol")}: ${x.optString("lastPrice")}")}}catch(_:Exception){}
        return out
    }
    suspend fun news():List<News>{
        // RSS XML is intentionally handled in the backend in production. These public JSON feeds keep the Android client dependency-light.
        val urls=listOf("https://min-api.cryptocompare.com/data/v2/news/?lang=EN")
        val out=mutableListOf<News>()
        for(u in urls){try{val o=json(u);val a=o.optJSONArray("Data")?:continue;for(i in 0 until min(20,a.length())){val x=a.getJSONObject(i);out.add(News(x.optString("title"),x.optString("url"),x.optString("source")))}}catch(_:Exception){}}
        return out.distinctBy{it.url}.take(30)
    }
    suspend fun analyze(symbol:String):Analysis{
        val cs=candles(symbol,"4h",260);if(cs.size<205)error("داده کافی برای تحلیل نیست")
        val c=cs.map{it.close};val e20=ema(c,20);val e50=ema(c,50);val e200=ema(c,200);val r=rsi(c);val atr=cs.takeLast(14).mapIndexed{idx,x->if(idx==0)0.0 else max(x.high-x.low,max(abs(x.high-cs[cs.size-14+idx-1].close),abs(x.low-cs[cs.size-14+idx-1].close)))}.average();val p=c.last()
        var score=0.0;score+=if(p>e20)15 else -15;score+=if(e20>e50)15 else -15;score+=if(p>e200)20 else -20;score+=when{r<30->5;r<=70->10;else->-8};score+=if(cs.takeLast(20).dropLast(1).maxOf{it.high}<p)10 else 0;score+=if(atr/p<.03)10 else -5;score=score.coerceIn(-100.0,100.0)
        val regime=when{score>=35->"Risk-On / صعودی";score<=-25->"Risk-Off / نزولی";else->"Neutral / خنثی"};val signal=when{score>=45->"LONG / بررسی ورود";score<=-45->"SHORT / اجتناب از Long";else->"NEUTRAL / صبر"};val entry=if(score>=45)p else Double.NaN;val stop=if(score>=45)p-1.5*atr else Double.NaN;val risk=if(score>=45)entry-stop else Double.NaN
        val lows=cs.takeLast(80).map{it.low}.sorted();val highs=cs.takeLast(80).map{it.high}.sorted();val sup=lows.firstOrNull{it<p};val res=highs.lastOrNull{it>p};return Analysis(symbol.uppercase().removeSuffix("USDT"),p,score,signal,r,e20,e50,e200,atr,entry,stop,if(score>=45)entry+1.5*risk else Double.NaN,if(score>=45)entry+3*risk else Double.NaN,regime,funding(symbol),oiChange(symbol),sup,res,cs)
    }
}

@Composable fun Sparkline(data:List<Candle>,modifier:Modifier=Modifier.fillMaxWidth().height(130.dp)){
    if(data.isEmpty())return
    val vals=data.map{it.close};val lo=vals.minOrNull()?:0.0;val hi=vals.maxOrNull()?:1.0;val range=(hi-lo).takeIf{it>0}?:1.0
    Canvas(modifier){val path=Path();vals.forEachIndexed{i,v->val x=if(vals.size==1)0f else size.width*i/(vals.size-1);val y=size.height-((v-lo)/range*size.height).toFloat();if(i==0)path.moveTo(x,y)else path.lineTo(x,y)};drawPath(path=path)}
}

@Composable fun App(activity:ComponentActivity){
    val repo=remember{MarketRepository()};val scope=rememberCoroutineScope();var tab by remember{mutableIntStateOf(0)};var coins by remember{mutableStateOf<List<Coin>>(emptyList())};var selected by remember{mutableStateOf("BTC")};var analysis by remember{mutableStateOf<Analysis?>(null)};var news by remember{mutableStateOf<List<News>>(emptyList())};var iran by remember{mutableStateOf<List<String>>(emptyList())};var loading by remember{mutableStateOf(false)};var err by remember{mutableStateOf<String?>(null)};var capital by remember{mutableStateOf("1000")};var riskPct by remember{mutableStateOf("1")};var entry by remember{mutableStateOf("")};var stop by remember{mutableStateOf("")};var baseUrl by remember{mutableStateOf("")};var autoRefresh by remember{mutableStateOf(true)};var fearGreed by remember{mutableStateOf("N/A")}
    fun refresh(){scope.launch{loading=true;try{coins=repo.topCoins();iran=repo.iranPrices();news=repo.news();fearGreed=repo.fearGreed();analysis=repo.analyze(selected);err=null}catch(e:Exception){err=e.message?:"خطای ناشناخته"};loading=false}}
    LaunchedEffect(Unit){refresh()}
    MaterialTheme{Scaffold(topBar={TopAppBar(title={Text("AstraTrade Pro 3.0")},actions={if(loading)CircularProgressIndicator(Modifier.size(22.dp).padding(end=8.dp))})},bottomBar={NavigationBar{listOf("داشبورد","اسکنر","تحلیل","اخبار","ریسک").forEachIndexed{i,t->NavigationBarItem(selected=i==tab,onClick={tab=i},icon={Text("•")},label={Text(t)})}}}){pad->
        LazyColumn(Modifier.padding(pad).padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{Text("موتور چندمدلی • تحقیقاتی و بدون تضمین سود",style=MaterialTheme.typography.bodyMedium)};err?.let{item{Text("خطا: $it",color=MaterialTheme.colorScheme.error)}}
            when(tab){
                0->{item{Button(onClick={refresh()}){Text("به‌روزرسانی همه داده‌ها")}};item{Text("Market Regime",style=MaterialTheme.typography.titleLarge)};item{Text(analysis?.regime?:("در حال محاسبه..."))};item{Text("Fear & Greed: $fearGreed")};item{Text("صرافی‌های ایرانی",style=MaterialTheme.typography.titleLarge)};items(iran){Text(it)};item{Text("Top Liquidity",style=MaterialTheme.typography.titleLarge)};items(coins.take(20)){c->ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(c.symbol);Text("${c.price}  |  24h ${"%.2f".format(c.change)}%  |  Vol ${"%.0f".format(c.volume)}")}}}}
                1->{item{Text("Smart Market Scanner",style=MaterialTheme.typography.headlineSmall)};item{Text("اسکن سریع با روند، مومنتوم، حجم، ATR و ساختار بازار")};items(coins.take(15)){c->ElevatedCard(Modifier.fillMaxWidth()){Row(Modifier.padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){Column(Modifier.weight(1f)){Text(c.symbol);Text("24h ${"%.2f".format(c.change)}%")};Button(onClick={selected=c.symbol.removeSuffix("USDT");tab=2}){Text("تحلیل")}}}}}
                2->{item{Text("Smart Navigator",style=MaterialTheme.typography.headlineSmall)};item{Row(Modifier.horizontalScroll(rememberScrollState()),horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("BTC","ETH","SOL","ADA","NEAR","TON","XRP").forEach{s->OutlinedButton(onClick={selected=s;scope.launch{loading=true;try{analysis=repo.analyze(s);err=null}catch(e:Exception){err=e.message};loading=false}}){Text(s)}}}};analysis?.let{a->item{ElevatedCard{Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(6.dp)){Text(a.symbol,style=MaterialTheme.typography.headlineMedium);Text("Score ${"%.1f".format(a.score)} • ${a.signal}");Text("RSI ${"%.1f".format(a.rsi)} • ATR ${"%.6f".format(a.atr)}");Text("EMA20/50/200: ${"%.5f".format(a.ema20)} / ${"%.5f".format(a.ema50)} / ${"%.5f".format(a.ema200)}");Text("Funding: ${a.funding?.let{"%.5f".format(it*100)+"%"}?:"N/A"} • OI 4h: ${a.oiChange?.let{"%.2f".format(it)+"%"}?:"N/A"}");Text("Support ${a.support?:Double.NaN} • Resistance ${a.resistance?:Double.NaN}");Sparkline(a.candles);if(!a.entry.isNaN()){Text("Entry ${a.entry} • SL ${a.stop} • TP1 ${a.tp1} • TP2 ${a.tp2}")}}}};item{Button(onClick={scope.launch{loading=true;try{analysis=repo.analyze(selected);err=null}catch(e:Exception){err=e.message};loading=false}}){Text("اجرای تحلیل")}}}}
                3->{item{Text("Crypto News",style=MaterialTheme.typography.headlineSmall)};item{Button(onClick={scope.launch{loading=true;try{news=repo.news();err=null}catch(e:Exception){err=e.message};loading=false}}){Text("دریافت اخبار")}};items(news){n->ElevatedCard(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(n.title);Text(n.source,style=MaterialTheme.typography.bodySmall);Text(n.url,style=MaterialTheme.typography.bodySmall)}}}}
                4->{item{Text("Risk Center",style=MaterialTheme.typography.headlineSmall)};item{OutlinedTextField(capital,{capital=it},label={Text("سرمایه")},modifier=Modifier.fillMaxWidth())};item{OutlinedTextField(riskPct,{riskPct=it},label={Text("ریسک هر معامله %")},modifier=Modifier.fillMaxWidth())};item{OutlinedTextField(entry,{entry=it},label={Text("Entry")},modifier=Modifier.fillMaxWidth())};item{OutlinedTextField(stop,{stop=it},label={Text("Stop")},modifier=Modifier.fillMaxWidth())};item{val cap=capital.toDoubleOrNull();val rp=riskPct.toDoubleOrNull();val en=entry.toDoubleOrNull();val st=stop.toDoubleOrNull();if(cap!=null&&rp!=null&&en!=null&&st!=null&&en>st){val cash=cap*rp/100;val qty=cash/(en-st);Text("Risk cash: ${"%.2f".format(cash)} • Quantity: ${"%.6f".format(qty)} • Notional: ${"%.2f".format(qty*en)}")}};item{Text("Settings",style=MaterialTheme.typography.titleLarge)};item{OutlinedTextField(baseUrl,{baseUrl=it},label={Text("Backend API URL (اختیاری)")},modifier=Modifier.fillMaxWidth())};item{Row{Switch(autoRefresh,{autoRefresh=it});Text("Auto Refresh")}};item{Text("هیچ سفارش واقعی از این اپ ارسال نمی‌شود.")}}
            }
        }
    }}
}

class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent{App(this)}}}

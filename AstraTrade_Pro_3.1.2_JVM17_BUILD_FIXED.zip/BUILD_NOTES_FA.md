# AstraTrade Pro 3.1.2

## رفع خطای Build
خطای `Inconsistent JVM-target compatibility` برطرف شد؛ Java و Kotlin هر دو روی JVM 17 تنظیم شدند.

VersionCode: 4
VersionName: 3.1.2

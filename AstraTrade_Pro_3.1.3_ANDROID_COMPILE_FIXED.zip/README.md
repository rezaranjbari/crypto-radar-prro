# AstraTrade Pro 3.0

نسخه‌ی ارتقاءیافته‌ی موتور تحلیل و مدیریت معامله. این پروژه عمداً از لایه‌های جدا ساخته شده تا بعداً بتوان آن را به اپ Android، داشبورد وب یا API متصل کرد.

## چه چیزهایی نسبت به نسخه قبلی ارتقاء یافته؟

- معماری Provider برای چند صرافی؛ هسته تحلیل به یک صرافی قفل نیست.
- Binance با retry، timeout، cache کوتاه و حذف کندل باز.
- آداپتور Generic REST برای صرافی‌های دیگر؛ برای APIهای ایرانی باید mapping رسمی همان صرافی پیاده‌سازی شود و endpoint حدسی وارد برنامه نشده است.
- تحلیل چندتایم‌فریمی 1h/4h.
- EMA20/50/200، RSI، MACD، ATR، ADX، Bollinger Bands، Stochastic، VWAP.
- امتیازدهی 0 تا 100 با روند، مومنتوم، حجم، ساختار، قدرت روند و رژیم BTC.
- پلن ورود/حدضرر/دو تارگت/حجم بر اساس ریسک.
- گیت سخت مدیریت ریسک و محدودیت پورتفو.
- بک‌تست walk-forward با کارمزد و slippage.
- دفترچه SQLite با WAL و شاخص‌ها.
- پایش Paper Trading و انتقال حدضرر به نقطه ورود پس از TP1.
- تست‌های خودکار.
- هیچ سفارش واقعی به صرافی ارسال نمی‌شود.

## نصب

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python -m trading_assistant init
```

## اجرا

```bash
python -m trading_assistant scan --demo
python -m trading_assistant scan
python -m trading_assistant backtest --demo --symbols 8
python -m trading_assistant status
python -m trading_assistant monitor --demo --once
```

## نکته مهم درباره صرافی‌های ایرانی

در این نسخه endpoint ساختگی برای صرافی ایرانی قرار داده نشده است؛ چون تفاوت نام بازار، فرمت کندل، احراز هویت و rate limit بین صرافی‌ها می‌تواند باعث قیمت غلط شود. برای اضافه‌کردن هر صرافی باید API رسمی و mapping دقیق آن بررسی و در یک Provider مستقل پیاده شود.

## مسیر توسعه بعدی

1. REST/WebSocket provider برای هر صرافی موردنظر.
2. سرویس News/Sentiment با timestamp و منبع.
3. API داخلی برای Android.
4. داشبورد نموداری.
5. سیستم alert قابل تنظیم.
6. ماژول ML فقط بعد از ایجاد dataset واقعی و walk-forward validation.
7. اجرای Paper Trading طولانی‌مدت قبل از هر اتصال احتمالی به سفارش واقعی.

این نرم‌افزار ابزار تحلیل و آموزش است، نه تضمین سود یا توصیه مالی.

## داشبورد جدید 2.1

برای اجرای رابط گرافیکی:

```bash
pip install -r requirements.txt
python run_dashboard.py
```

سپس مرورگر را روی `http://127.0.0.1:8000` باز کنید.

### APIهای اصلی

- `GET /health`
- `GET /api/config`
- `POST /api/scan`
- `GET /api/scan`
- `GET /api/watchlist`
- `GET /api/news`
- `GET /api/status`
- `GET /api/backtest`
- `GET /api/symbol/{symbol}`

این API عمداً از هسته تحلیل مشترک استفاده می‌کند تا نسخه وب و کلاینت Android در آینده خروجی متفاوتی تولید نکنند.

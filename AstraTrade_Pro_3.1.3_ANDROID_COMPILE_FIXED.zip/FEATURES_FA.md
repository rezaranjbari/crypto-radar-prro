# AstraTrade Pro — امکانات ادغام‌شده

این نسخه، موتور AstraTrade Pro را با موتور Crypto Scanner Pro ادغام می‌کند.

- تحلیل چندتایم‌فریمی 1H/4H/1D
- EMA20/50/200، SMA، RSI، MACD، ATR، ADX، Bollinger، Stochastic، VWAP
- امتیاز روند/مومنتوم/حجم/ساختار و رژیم BTC/ETH
- Funding Rate و Open Interest برای Binance Futures
- Fear & Greed و BTC Dominance
- تشخیص Breakout، Pullback، نواحی Premium/Discount و Support/Resistance
- آمار تاریخی و Walk-forward backtest
- Risk Gate، R:R، Entry/SL/TP1/TP2 و Position Sizing
- Paper Trading و Journal SQLite با WAL
- Watchlist و API
- اخبار RSS با timestamp/source
- اتصال عمومی Nobitex و Wallex در موتور Python؛ endpoint ساختگی برای صرافی‌هایی که API آنها تأیید نشده اضافه نشده است
- خروجی CSV و HTML و اعلان Telegram
- FastAPI برای داشبورد/کلاینت
- Android با داشبورد بازار، اسکنر چندشاخصی، واچ‌لیست، مرکز ریسک و قیمت‌های عمومی Nobitex
- هیچ سفارش واقعی ارسال نمی‌شود

## اصل مهم کیفیت داده
اگر منبعی پاسخ معتبر ندهد، برنامه باید آن منبع را کنار بگذارد و قیمت حدسی تولید نکند. داده قدیمی/کندل باز نباید وارد تحلیل اصلی شود.

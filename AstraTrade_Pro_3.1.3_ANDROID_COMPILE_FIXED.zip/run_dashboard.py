import uvicorn
from trading_assistant.api import app
uvicorn.run(app, host='0.0.0.0', port=8000)

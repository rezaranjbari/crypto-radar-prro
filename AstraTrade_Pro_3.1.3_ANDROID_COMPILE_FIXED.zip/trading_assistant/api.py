"""FastAPI backend for the AstraTrade Pro dashboard/mobile client."""
from dataclasses import asdict
from pathlib import Path
from typing import Optional
import json
import threading

from fastapi import FastAPI, HTTPException, Query
from fastapi.responses import FileResponse, HTMLResponse

from .config import Config
from .data import make_provider
from .journal import Journal
from .pipeline import run_scan

ROOT = Path(__file__).resolve().parent
WEB = ROOT / "web"

app = FastAPI(title="AstraTrade Pro", version="3.0.0")
cfg = Config.load()
provider = make_provider(cfg, demo=True)
journal = Journal(cfg.db_path)
_lock = threading.Lock()
_last_scan = {"regime": None, "results": [], "ts": None}


def _scan():
    global _last_scan
    with _lock:
        regime, results = run_scan(provider, cfg, journal.portfolio(), log=lambda *_: None)
        rows = []
        for plan, verdict in results:
            sid = journal.log_signal(plan, verdict)
            rows.append({"plan": asdict(plan), "verdict": asdict(verdict), "signal_id": sid})
        from datetime import datetime, timezone
        _last_scan = {"regime": regime, "results": rows, "ts": datetime.now(timezone.utc).isoformat()}
        return _last_scan


@app.get("/", response_class=HTMLResponse)
def home():
    return (WEB / "index.html").read_text(encoding="utf-8")


@app.get("/health")
def health():
    return {"ok": True, "version": app.version, "provider": type(provider).__name__}


@app.get("/api/config")
def get_config():
    from dataclasses import asdict
    return asdict(cfg)


@app.post("/api/scan")
def scan():
    return _scan()


@app.get("/api/scan")
def scan_cached():
    if not _last_scan["results"]:
        return _scan()
    return _last_scan


@app.get("/api/watchlist")
def watchlist():
    return [{"symbol": x["symbol"], "price": x["price"], "change_pct": x["change_pct"], "quote_volume": x["quote_volume"]}
            for x in provider.universe(cfg.universe_size, cfg.min_quote_volume)]


@app.get("/api/status")
def status():
    return {"open_trades": journal.open_trades(), "stats": journal.stats(), "today_pnl": journal.today_realized_pnl()}


@app.get("/api/backtest")
def backtest(symbols: int = Query(8, ge=1, le=30)):
    from .backtest import run_backtest
    stats, per = run_backtest(provider, cfg, symbols, log=lambda *_: None)
    return {"stats": stats, "per_symbol": per}


@app.get("/api/news")
def news(limit: int = Query(20, ge=1, le=50)):
    # RSS feeds are configurable; failure of one source never breaks the API.
    import urllib.request
    import xml.etree.ElementTree as ET
    feeds = [
        "https://www.coindesk.com/arc/outboundfeeds/rss/",
        "https://cointelegraph.com/rss",
    ]
    out=[]
    for url in feeds:
        try:
            req=urllib.request.Request(url, headers={"User-Agent":"TradingAssistantPro/2.1"})
            raw=urllib.request.urlopen(req, timeout=8).read()
            root=ET.fromstring(raw)
            for item in root.findall(".//item"):
                title=(item.findtext("title") or "").strip()
                link=(item.findtext("link") or "").strip()
                pub=(item.findtext("pubDate") or "").strip()
                if title and link:
                    out.append({"title":title,"url":link,"published":pub})
        except Exception:
            continue
    seen=set(); clean=[]
    for x in out:
        key=x["url"]
        if key not in seen:
            seen.add(key); clean.append(x)
    return clean[:limit]


@app.get("/api/symbol/{symbol}")
def symbol(symbol: str):
    symbol=symbol.upper()
    try:
        df=provider.klines(symbol,"1h",500)
        from .ranking import compute_metrics
        m=compute_metrics(df, 0)
        return {"symbol":symbol,"metrics":m}
    except Exception as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.get("/api/advanced/iran")
def advanced_iran():
    from .advanced_scanner import iran_snapshot
    return iran_snapshot()

@app.get("/api/advanced/news")
def advanced_news(limit: int = Query(20, ge=1, le=50)):
    from .advanced_scanner import news_rss
    return news_rss(limit)

@app.get("/api/advanced/regime")
def advanced_regime():
    from .advanced_scanner import market_regime
    return market_regime()


@app.get("/api/advanced/risk")
def advanced_risk(capital: float = Query(..., gt=0), risk_pct: float = Query(..., gt=0, le=10), entry: float = Query(..., gt=0), stop: float = Query(..., gt=0)):
    from .advanced_scanner import risk_position
    result = risk_position(capital, risk_pct, entry, stop)
    if result is None:
        raise HTTPException(status_code=400, detail="entry و stop باید متفاوت باشند")
    return result


@app.get("/api/advanced/scan")
def advanced_scan(top_n: int = Query(12, ge=1, le=30), history: int = Query(300, ge=100, le=1000), target: float = Query(3.0, gt=0, le=50), hours: int = Query(24, ge=1, le=168)):
    from types import SimpleNamespace
    from .advanced_scanner import list_binance, market_regime, news_rss, analyze
    ctx = market_regime()
    args = SimpleNamespace(history=history, target=target, hours=hours)
    news = news_rss(20)
    rows = []
    for info in list_binance(1_000_000, top_n, 1.0):
        item = analyze(info, ctx, args, news)
        if item:
            rows.append(item)
    rows.sort(key=lambda x: x.get("score", -999), reverse=True)
    return {"regime": ctx, "results": rows, "count": len(rows)}

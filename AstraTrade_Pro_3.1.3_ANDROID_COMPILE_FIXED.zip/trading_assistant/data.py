"""Exchange data layer.

The scanner depends only on Provider. New exchanges can be added without
touching ranking/risk/backtest code. Unverified exchange APIs are deliberately
not hard-coded; use the generic REST adapter for them.
"""
import time
import zlib
import numpy as np
import pandas as pd
import requests
from dataclasses import dataclass
from .indicators import validate_ohlcv


class Provider:
    def universe(self, n, min_quote_volume): raise NotImplementedError
    def klines(self, symbol, interval="1h", limit=1000): raise NotImplementedError
    def last_price(self, symbol): raise NotImplementedError


class BinanceProvider(Provider):
    INTERVALS = {"1m","3m","5m","15m","30m","1h","2h","4h","6h","8h","12h","1d","3d","1w"}

    def __init__(self, base_url, fallback_url, timeout=12, retries=3, cache_seconds=10):
        self.base_url = base_url.rstrip("/")
        self.fallback_url = fallback_url.rstrip("/")
        self.timeout = timeout
        self.retries = retries
        self.cache_seconds = cache_seconds
        self.session = requests.Session()
        self._cache = {}

    def _get(self, path, params=None):
        key = (path, tuple(sorted((params or {}).items())))
        now = time.time()
        hit = self._cache.get(key)
        if hit and now - hit[0] < self.cache_seconds:
            return hit[1]
        last = None
        for base in (self.base_url, self.fallback_url):
            for attempt in range(self.retries):
                try:
                    r = self.session.get(base + path, params=params, timeout=self.timeout)
                    r.raise_for_status()
                    data = r.json()
                    self._cache[key] = (now, data)
                    return data
                except (requests.RequestException, ValueError) as e:
                    last = e
                    time.sleep(min(0.5 * (2 ** attempt), 3))
        raise RuntimeError(f"exchange request failed: {last}")

    def universe(self, n, min_quote_volume):
        rows = self._get("/api/v3/ticker/24hr")
        out = []
        for r in rows:
            sym = r.get("symbol","")
            if not sym.endswith("USDT") or sym.endswith(("UPUSDT","DOWNUSDT","BULLUSDT","BEARUSDT")):
                continue
            try:
                qv = float(r["quoteVolume"])
                if qv < min_quote_volume:
                    continue
                out.append({"symbol": sym, "quote_volume": qv,
                            "change_pct": float(r["priceChangePercent"]),
                            "price": float(r["lastPrice"])})
            except (KeyError, ValueError):
                continue
        return sorted(out, key=lambda x: x["quote_volume"], reverse=True)[:n]

    def klines(self, symbol, interval="1h", limit=1000):
        if interval not in self.INTERVALS:
            raise ValueError(f"unsupported interval: {interval}")
        rows = self._get("/api/v3/klines", {"symbol":symbol, "interval":interval, "limit":min(limit,1000)})
        now_ms = int(time.time()*1000)
        rows = [r for r in rows if r[6] < now_ms]
        df = pd.DataFrame(rows, columns=["t","open","high","low","close","volume","ct","qv","n","tb","tq","ig"])
        df.index = pd.to_datetime(df["t"], unit="ms", utc=True)
        df.index.name = "time"
        df = df[["open","high","low","close","volume"]].astype(float)
        ok, reason = validate_ohlcv(df, min_rows=min(50, max(20, limit//4)))
        if not ok: raise ValueError(reason)
        return df

    def last_price(self, symbol):
        return float(self._get("/api/v3/ticker/price", {"symbol":symbol})["price"])


class GenericRESTProvider(Provider):
    """Adapter skeleton for Iranian/other exchanges.

    Implement the three methods for the exchange's documented public API.
    This avoids silently using a wrong endpoint/response format.
    """
    def __init__(self, name, base_url):
        self.name, self.base_url = name, base_url.rstrip("/")
        self.session = requests.Session()

    def universe(self, n, min_quote_volume):
        raise NotImplementedError("Implement universe() from the exchange's official API documentation.")

    def klines(self, symbol, interval="1h", limit=1000):
        raise NotImplementedError("Implement klines() from the exchange's official API documentation.")

    def last_price(self, symbol):
        raise NotImplementedError("Implement last_price() from the exchange's official API documentation.")


class DemoProvider(Provider):
    SYMBOLS = ["BTCUSDT","ETHUSDT","SOLUSDT","BNBUSDT","XRPUSDT","ADAUSDT","DOGEUSDT",
               "AVAXUSDT","LINKUSDT","NEARUSDT","TONUSDT","DOTUSDT"]

    def __init__(self, seed=7):
        self.seed, self._cache, self._rng, self._live = seed, {}, np.random.default_rng(seed+1), {}

    def _series(self, symbol):
        if symbol in self._cache: return self._cache[symbol]
        rng = np.random.default_rng(zlib.crc32(symbol.encode()) + self.seed)
        n = 1200
        drift = rng.uniform(-0.0002, 0.0007) if symbol != "BTCUSDT" else 0.00035
        vol = rng.uniform(0.003, 0.009)
        rets = rng.normal(drift, vol, n)
        close = 100 * rng.uniform(.5,50) * np.exp(np.cumsum(rets))
        op = np.r_[close[0], close[:-1]]
        spread = np.abs(rng.normal(0, vol*.6, n))
        hi = np.maximum(op,close)*(1+spread)
        lo = np.minimum(op,close)*(1-spread)
        volume = rng.lognormal(10,.4,n) * (1+2*(rng.random(n)>.95))
        idx = pd.date_range(end=pd.Timestamp.now(tz="UTC").floor("1h"), periods=n, freq="1h")
        df = pd.DataFrame({"open":op,"high":hi,"low":lo,"close":close,"volume":volume}, index=idx)
        self._cache[symbol] = df
        return df

    def universe(self,n,min_quote_volume):
        out=[]
        for s in self.SYMBOLS:
            d=self._series(s); qv=float((d.volume*d.close).tail(24).sum())
            out.append({"symbol":s,"quote_volume":max(qv,min_quote_volume),
                        "change_pct":float(d.close.iloc[-1]/d.close.iloc[-25]*100-100),
                        "price":float(d.close.iloc[-1])})
        return out[:n]

    def klines(self,symbol,interval="1h",limit=1000):
        if interval=="1h": return self._series(symbol).tail(limit).copy()
        base=self.last_price(symbol); steps=self._rng.normal(0,.0015,limit)
        close=base*np.exp(np.cumsum(steps)-steps.sum()); op=np.r_[close[0],close[:-1]]
        idx=pd.date_range(end=pd.Timestamp.now(tz="UTC").floor("1min"),periods=limit,freq="1min")
        return pd.DataFrame({"open":op,"high":np.maximum(op,close)*1.0004,
                             "low":np.minimum(op,close)*.9996,"close":close,"volume":1.0},index=idx)

    def last_price(self,symbol):
        p=self._live.get(symbol,float(self._series(symbol).close.iloc[-1]))
        p*=float(np.exp(self._rng.normal(0,.001))); self._live[symbol]=p; return p


def make_provider(cfg, demo=False):
    return DemoProvider() if demo else BinanceProvider(
        cfg.base_url, cfg.fallback_url, cfg.request_timeout, cfg.request_retries, cfg.cache_seconds
    )

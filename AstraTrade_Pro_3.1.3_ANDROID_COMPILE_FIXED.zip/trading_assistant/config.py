"""Central configuration with safe, explicit defaults."""
from dataclasses import dataclass, asdict
import json
from pathlib import Path


@dataclass
class Config:
    account_size: float = 1000.0
    risk_per_trade_pct: float = 0.75
    max_total_risk_pct: float = 3.0
    daily_loss_limit_pct: float = 2.0
    max_open_trades: int = 4
    max_leverage: float = 3.0

    universe_size: int = 30
    top_n: int = 8
    min_quote_volume: float = 5_000_000
    min_score: float = 62.0
    min_rr: float = 1.8
    min_room_r: float = 1.2
    min_stop_pct: float = 0.25
    max_stop_pct: float = 5.0

    allow_short: bool = True
    block_counter_regime: bool = True
    rsi_long_max: float = 72.0
    rsi_short_min: float = 28.0

    fee_pct: float = 0.10
    slippage_bps: float = 5.0
    monitor_interval_sec: int = 30
    db_path: str = "journal.db"

    base_url: str = "https://data-api.binance.vision"
    fallback_url: str = "https://api.binance.com"
    request_timeout: int = 12
    request_retries: int = 3
    cache_seconds: int = 10

    @classmethod
    def load(cls, path="config.json"):
        p = Path(path)
        if not p.exists():
            return cls()
        data = json.loads(p.read_text(encoding="utf-8"))
        known = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        return cls(**known)

    def save(self, path="config.json"):
        Path(path).write_text(
            json.dumps(asdict(self), ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

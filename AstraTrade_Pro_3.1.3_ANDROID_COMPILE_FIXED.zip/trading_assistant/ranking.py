"""Multi-timeframe market regime and setup scoring."""
from dataclasses import dataclass, field
from .indicators import ema, rsi, macd, atr, adx, bollinger, stoch, vwap, resample_ohlcv, validate_ohlcv

DIR_FA = {"long":"خرید (Long)", "short":"فروش (Short)"}


@dataclass
class Setup:
    symbol: str
    direction: str
    score: float
    reasons: list = field(default_factory=list)
    metrics: dict = field(default_factory=dict)


def market_regime(btc_1h):
    d4 = resample_ohlcv(btc_1h, "4h")
    d1 = btc_1h
    c4 = d4.close
    e50, e200 = ema(c4,50).iloc[-1], ema(c4,200).iloc[-1]
    a = adx(d4).iloc[-1]
    last = c4.iloc[-1]
    if last > e50 > e200 and a >= 18: name="bull"
    elif last < e50 < e200 and a >= 18: name="bear"
    else: name="range"
    change24=float(d1.close.iloc[-1]/d1.close.iloc[-25]*100-100) if len(d1)>=25 else 0
    return {"name":name,"btc_change_24h":change24,"btc_price":float(last),
            "adx_4h":float(a),"ema50_4h":float(e50),"ema200_4h":float(e200)}


def compute_metrics(df1h, quote_volume=0.0):
    d4 = resample_ohlcv(df1h,"4h")
    ok, reason = validate_ohlcv(df1h, 250)
    if not ok: raise ValueError(reason)
    c=df1h.close
    ml, ms, mh = macd(c)
    mid, bb_up, bb_dn = bollinger(c)
    sk, sd = stoch(df1h)
    vol_base=df1h.volume.iloc[-23:-3].mean()
    return {
        "close":float(c.iloc[-1]), "atr":float(atr(df1h).iloc[-1]),
        "rsi":float(rsi(c).iloc[-1]), "adx":float(adx(df1h).iloc[-1]),
        "macd_hist":float(mh.iloc[-1]), "macd_hist_prev":float(mh.iloc[-2]),
        "e20_1":float(ema(c,20).iloc[-1]), "e50_1":float(ema(c,50).iloc[-1]),
        "e200_1":float(ema(c,200).iloc[-1]),
        "c4":float(d4.close.iloc[-1]), "e20_4":float(ema(d4.close,20).iloc[-1]),
        "e50_4":float(ema(d4.close,50).iloc[-1]), "e200_4":float(ema(d4.close,200).iloc[-1]),
        "adx_4":float(adx(d4).iloc[-1]),
        "stoch_k":float(sk.iloc[-1]), "stoch_d":float(sd.iloc[-1]),
        "vwap":float(vwap(df1h).iloc[-1]),
        "bb_mid":float(mid.iloc[-1]), "bb_up":float(bb_up.iloc[-1]), "bb_dn":float(bb_dn.iloc[-1]),
        "vol_ratio":float(df1h.volume.iloc[-3:].mean()/vol_base) if vol_base>0 else 0,
        "prior_high20":float(df1h.high.iloc[-21:-1].max()),
        "prior_low20":float(df1h.low.iloc[-21:-1].min()),
        "resistance":float(df1h.high.iloc[-73:-1].max()),
        "support":float(df1h.low.iloc[-73:-1].min()),
        "swing_low":float(df1h.low.iloc[-20:].min()),
        "swing_high":float(df1h.high.iloc[-20:].max()),
        "quote_volume":float(quote_volume),
    }


def _score(direction,m,regime):
    s=1 if direction=="long" else -1
    reasons=[]; total=0.0
    trend=0
    if s*(m["c4"]-m["e50_4"])>0: trend+=10
    if s*(m["e50_4"]-m["e200_4"])>0: trend+=8
    if s*(m["e20_1"]-m["e50_1"])>0 and s*(m["close"]-m["e50_1"])>0: trend+=8
    if s*m["close"] > s*m["vwap"]: trend+=4
    total+=trend
    if trend: reasons.append(f"روند چندتایم‌فریمی ({trend}/30)")

    r=m["rsi"]; mom=0
    if direction=="long":
        mom += 8 if 48<=r<=68 else 4 if 42<=r<48 or 68<r<=74 else 0
        mom += 4 if m["macd_hist"]>0 else 0
        mom += 3 if m["macd_hist"]>m["macd_hist_prev"] else 0
        mom += 3 if m["stoch_k"]>m["stoch_d"] and m["stoch_k"]<85 else 0
    else:
        mom += 8 if 32<=r<=52 else 4 if 26<=r<32 or 52<r<=58 else 0
        mom += 4 if m["macd_hist"]<0 else 0
        mom += 3 if m["macd_hist"]<m["macd_hist_prev"] else 0
        mom += 3 if m["stoch_k"]<m["stoch_d"] and m["stoch_k"]>15 else 0
    total+=mom
    if mom: reasons.append(f"مومنتوم RSI/MACD/Stoch ({mom}/18)")

    vp=10 if m["vol_ratio"]>=1.8 else 7 if m["vol_ratio"]>=1.3 else 4 if m["vol_ratio"]>=1 else 0
    total+=vp
    if vp: reasons.append(f"حجم {m['vol_ratio']:.1f}x ({vp}/10)")

    struct=0; a=m["atr"]
    if direction=="long":
        if m["close"]>m["prior_high20"]: struct=18 if m["close"]-m["prior_high20"]<=1.2*a else 11
        elif m["close"]>m["e50_1"] and min(abs(m["close"]-m["e20_1"]),abs(m["close"]-m["e50_1"]))<=.6*a: struct=14
    else:
        if m["close"]<m["prior_low20"]: struct=18 if m["prior_low20"]-m["close"]<=1.2*a else 11
        elif m["close"]<m["e50_1"] and min(abs(m["close"]-m["e20_1"]),abs(m["close"]-m["e50_1"]))<=.6*a: struct=14
    total+=struct
    if struct: reasons.append(f"ساختار/شکست/پولبک ({struct}/18)")

    strength=0
    if m["adx_4"]>=25: strength=8
    elif m["adx_4"]>=18: strength=5
    total+=strength
    if strength: reasons.append(f"قدرت روند ADX={m['adx_4']:.0f} ({strength}/8)")

    regime_pts=6 if regime["name"]=="range" else 16 if (regime["name"]=="bull" and s==1) or (regime["name"]=="bear" and s==-1) else 0
    total+=regime_pts
    if regime_pts: reasons.append(f"هم‌جهتی با رژیم BTC ({regime_pts}/16)")
    return min(total,100), reasons


def evaluate_symbol(symbol,df1h,regime,cfg,quote_volume=0.0):
    if len(df1h)<400: return None
    m=compute_metrics(df1h,quote_volume)
    dirs=["long"]+(["short"] if cfg.allow_short else [])
    best=None
    for d in dirs:
        sc,rs=_score(d,m,regime)
        cur=Setup(symbol,d,float(sc),rs,m)
        if best is None or cur.score>best.score: best=cur
    return best


def rank(setups,top_n):
    return sorted([s for s in setups if s],key=lambda x:x.score,reverse=True)[:top_n]

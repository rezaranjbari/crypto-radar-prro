import os, requests


class Notifier:
    def __init__(self):
        self.token=os.getenv("TELEGRAM_BOT_TOKEN")
        self.chat=os.getenv("TELEGRAM_CHAT_ID")

    def send(self,text):
        print(text)
        if self.token and self.chat:
            try:
                requests.post(f"https://api.telegram.org/bot{self.token}/sendMessage",
                              json={"chat_id":self.chat,"text":text},timeout=10)
            except requests.RequestException as e:
                print(f"telegram failed: {e}")

"""Hard risk gate. A failed hard check rejects the plan."""
from dataclasses import dataclass, field


@dataclass
class Verdict:
    approved:bool
    failures:list=field(default_factory=list)
    warnings:list=field(default_factory=list)


def evaluate(plan,cfg,regime,portfolio=None):
    f=[]; w=[]
    if plan.score<cfg.min_score: f.append(f"امتیاز {plan.score:.0f} < {cfg.min_score:.0f}")
    if plan.rr<cfg.min_rr: f.append(f"ریسک/بازده 1:{plan.rr:.2f} < 1:{cfg.min_rr:.2f}")
    if plan.room_r<cfg.min_room_r: f.append(f"مانع نزدیک: {plan.room_r:.1f}R")
    if not cfg.min_stop_pct<=plan.stop_pct<=cfg.max_stop_pct:
        f.append(f"حد ضرر {plan.stop_pct:.2f}% خارج از {cfg.min_stop_pct}-{cfg.max_stop_pct}%")
    if plan.metrics.get("quote_volume",0)<cfg.min_quote_volume: f.append("نقدشوندگی کافی نیست")
    r=plan.metrics.get("rsi",50)
    if plan.direction=="long" and r>cfg.rsi_long_max: f.append(f"RSI={r:.0f} برای Long بیش‌ازحد بالاست")
    if plan.direction=="short" and r<cfg.rsi_short_min: f.append(f"RSI={r:.0f} برای Short بیش‌ازحد پایین است")
    if cfg.block_counter_regime and ((plan.direction=="long" and regime["name"]=="bear") or
                                      (plan.direction=="short" and regime["name"]=="bull")):
        f.append("خلاف رژیم BTC")
    if portfolio:
        opens=portfolio.get("open_trades",[])
        if any(t["symbol"]==plan.symbol for t in opens): f.append("روی این نماد معامله باز است")
        if len(opens)>=cfg.max_open_trades: f.append("سقف معاملات باز پر است")
        open_risk=sum(float(t["risk_amount"]) for t in opens if not t["tp1_hit"])
        if (open_risk+plan.risk_amount)/cfg.account_size*100>cfg.max_total_risk_pct:
            f.append("ریسک باز کل از سقف مجاز بیشتر می‌شود")
        if portfolio.get("today_pnl",0)<=-cfg.account_size*cfg.daily_loss_limit_pct/100:
            f.append("سقف ضرر روزانه فعال شده است")
    if plan.notional>cfg.account_size*cfg.max_leverage*1.0001:
        w.append("حجم پوزیشن به سقف اهرم محدود شده است")
    if plan.metrics.get("adx_4",0)<18:
        w.append("ADX پایین است؛ بازار ممکن است رنج باشد")
    return Verdict(not f,f,w)

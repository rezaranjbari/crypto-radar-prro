import argparse
from .config import Config
from .data import make_provider
from .pipeline import run_scan
from .journal import Journal
from .monitor import run_loop,_close
from .notify import Notifier
from .backtest import run_backtest
from .ranking import DIR_FA

REGIME_FA={"bull":"صعودی 🟢","bear":"نزولی 🔴","range":"رنج ⚪"}
DISCLAIMER="⚠️ ابزار تحلیلی/آموزشی است؛ سود تضمینی ندارد و سفارش واقعی به صرافی ارسال نمی‌کند."


def fmt_card(i,p,v):
    s=1 if p.direction=="long" else -1
    return "\n".join([
      "━"*38,f"#{i} {p.symbol} | {DIR_FA[p.direction]} | {p.score:.0f}/100",
      f"ورود: {p.entry:.8g}",f"حدضرر: {p.stop:.8g} ({p.stop_pct:.2f}%)",
      f"TP1: {p.tp1:.8g} | TP2: {p.tp2:.8g}",f"RR: 1:{p.rr:.2f} | فاصله مانع: {p.room_r:.1f}R",
      f"حجم: {p.qty:.8g} | ارزش: {p.notional:.2f}$ | ریسک: {p.risk_amount:.2f}$",
      "دلایل: "+"؛ ".join(p.reasons),
      "وضعیت: ✅ تایید" if v.approved else "وضعیت: ❌ رد",
      *(f"  - {x}" for x in v.failures), *(f"  ⚠ {x}" for x in v.warnings)
    ])


def cmd_scan(args,cfg):
    provider=make_provider(cfg,args.demo); j=Journal(cfg.db_path)
    print(DISCLAIMER); regime,results=run_scan(provider,cfg,j.portfolio())
    print(f"BTC: {REGIME_FA[regime['name']]} | 24h {regime['btc_change_24h']:+.2f}% | ADX4h {regime['adx_4h']:.1f}")
    approved=[]
    for p,v in results:
        sid=j.log_signal(p,v)
        if v.approved: approved.append((p,v,sid))
    if not approved: print("هیچ ستاپی از گیت ریسک عبور نکرد."); return
    for i,(p,v,sid) in enumerate(approved[:cfg.top_n],1):
        print(fmt_card(i,p,v))
        try: ans=input("ثبت پیپر؟ [y/N] ").strip().lower()
        except EOFError: ans=""
        if ans in ("y","yes","بله","ب"):
            tid=j.open_trade(p,sid); print(f"معامله پیپر #{tid} ثبت شد.")


def cmd_monitor(args,cfg):
    j=Journal(cfg.db_path); provider=make_provider(cfg,args.demo)
    if not j.open_trades(): print("معامله بازی وجود ندارد."); return
    try: run_loop(j,provider,Notifier(),args.interval or cfg.monitor_interval_sec,args.once)
    except KeyboardInterrupt: print("متوقف شد.")


def cmd_status(args,cfg):
    j=Journal(cfg.db_path); print(f"معاملات باز: {len(j.open_trades())}")
    st=j.stats()
    if st["trades"]: print(f"بسته‌شده: {st['trades']} | Win {st['win_rate']:.1f}% | Avg {st['avg_r']:+.2f}R | PF {st['profit_factor']:.2f} | MDD {st['max_drawdown_r']:.2f}R")
    else: print("هنوز معامله بسته‌شده‌ای نیست.")


def cmd_close(args,cfg):
    j=Journal(cfg.db_path); t=j.get_trade(args.id)
    if not t or t["status"]!="open": print("معامله باز پیدا نشد."); return
    _close(t,args.price)
    j.update_trade(t["id"],**{k:t[k] for k in ("qty_open","realized_pnl","status","closed_at","exit_price","r_multiple")})
    print(f"بسته شد: {t['realized_pnl']:+.2f} | {t['r_multiple']:+.2f}R")


def cmd_backtest(args,cfg):
    st,_=run_backtest(make_provider(cfg,args.demo),cfg,args.symbols)
    print(st)


def cmd_init(args,cfg):
    cfg.save(args.config or "config.json"); print("config.json ساخته شد.")


def main(argv=None):
    ap=argparse.ArgumentParser(prog="trading-assistant")
    ap.add_argument("--config",default=None)
    sub=ap.add_subparsers(dest="cmd",required=True)
    for name,fn in [("scan",cmd_scan),("monitor",cmd_monitor),("status",cmd_status),("backtest",cmd_backtest),("close",cmd_close),("init",cmd_init)]:
        p=sub.add_parser(name); p.set_defaults(fn=fn)
        if name in ("scan","monitor","backtest"): p.add_argument("--demo",action="store_true")
        if name=="monitor": p.add_argument("--once",action="store_true"); p.add_argument("--interval",type=int)
        if name=="backtest": p.add_argument("--symbols",type=int,default=8)
        if name=="close": p.add_argument("id",type=int); p.add_argument("price",type=float)
    a=ap.parse_args(argv); a.fn(a,Config.load(a.config))

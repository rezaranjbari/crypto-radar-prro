#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AstraTrade Pro advanced multi-source scanner integrated from the enhanced scanner engine."""
import argparse, csv, html, json, math, os, sqlite3, sys, time, xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone, timedelta
from urllib.parse import quote

import numpy as np
import pandas as pd
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

BINANCE_SPOT = ["https://api.binance.com", "https://data-api.binance.vision"]
BINANCE_FUT = "https://fapi.binance.com"
NOBITEX = "https://api.nobitex.ir"
WALLEX = "https://api.wallex.ir/hector/web/v1"
FNG = "https://api.alternative.me/fng/"
COINGECKO = "https://api.coingecko.com/api/v3"
DB_FILE = "scanner.db"
CSV_FILE = "scan_result.csv"
HTML_FILE = "scan_report.html"
STATE_FILE = "scanner_state.json"
STABLES = {"USDC","FDUSD","TUSD","USDP","DAI","BUSD","USDD","EUR","AEUR","USD1","PAXG","XAUT"}
LEVERAGED = ("UP","DOWN","BULL","BEAR")
REGIME_THRESH = {"Risk-On": 42, "Neutral": 48, "Risk-Off": 58}

S = requests.Session()
S.headers.update({"User-Agent":"CryptoRadarScannerPro/2.0"})
S.mount("https://", HTTPAdapter(max_retries=Retry(total=3, backoff_factor=.6, status_forcelist=(429,500,502,503,504), allowed_methods=frozenset(["GET","POST"]))))


def get(url, params=None, timeout=15, method="GET", **kwargs):
    r = S.request(method, url, params=params, timeout=timeout, **kwargs)
    r.raise_for_status()
    return r.json()


def spot_get(path, params=None):
    last = None
    for base in BINANCE_SPOT:
        try: return get(base + path, params)
        except Exception as e: last = e
    raise last


def safe_float(x, default=np.nan):
    try: return float(x)
    except Exception: return default


def now_utc(): return datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

# ----------------------------- market data -----------------------------
def list_binance(min_volume, top_n, max_spread):
    out=[]
    for t in spot_get("/api/v3/ticker/24hr"):
        s=t.get("symbol","")
        if not s.endswith("USDT"): continue
        base=s[:-4]
        if base in STABLES or base.endswith(LEVERAGED): continue
        vol,bid,ask=map(safe_float,(t.get("quoteVolume"),t.get("bidPrice"),t.get("askPrice")))
        if not np.isfinite(vol) or vol<min_volume or bid<=0 or ask<=0: continue
        spread=(ask-bid)/((ask+bid)/2)*100
        if spread>max_spread: continue
        out.append(dict(symbol=s,price=safe_float(t.get("lastPrice")),chg24=safe_float(t.get("priceChangePercent")),vol24=vol,spread=spread,source="Binance"))
    return sorted(out,key=lambda x:x["vol24"],reverse=True)[:top_n]


def nobitex_stats():
    """Public Iranian market snapshot. No authentication required."""
    try:
        d=get(NOBITEX+"/market/stats",params={"dstCurrency":"rls"})
        stats=d.get("stats",{})
        out={}
        for market,v in stats.items():
            base=market.split("-")[0].upper(); latest=safe_float(v.get("latest"))
            if base and np.isfinite(latest):
                out[base+"IRT"]={"price":latest,"change":safe_float(v.get("dayChange")),"volume_src":safe_float(v.get("volumeSrc")),"source":"Nobitex"}
        return out
    except Exception: return {}


def wallex_markets():
    try:
        d=get(WALLEX+"/markets")
        rows=d.get("result",{}).get("markets",d.get("markets",[]))
        if isinstance(rows,dict): rows=list(rows.values())
        out={}
        for x in rows or []:
            sym=str(x.get("symbol") or x.get("baseAsset","" )).upper()
            p=safe_float(x.get("lastPrice") or x.get("last") or x.get("price"))
            if sym and np.isfinite(p): out[sym]={"price":p,"source":"Wallex"}
        return out
    except Exception: return {}


def iran_snapshot():
    n=nobitex_stats(); w=wallex_markets()
    return {"Nobitex":n,"Wallex":w}


def klines(symbol, interval, limit=500):
    raw=spot_get("/api/v3/klines",{"symbol":symbol,"interval":interval,"limit":min(limit,1000)})
    df=pd.DataFrame(raw,columns=["t","open","high","low","close","volume","ct","qv","n","tb","tq","i"])
    for c in ("open","high","low","close","volume"): df[c]=pd.to_numeric(df[c],errors="coerce")
    return df[["t","open","high","low","close","volume"]].dropna().reset_index(drop=True)


def funding_map():
    try: return {x["symbol"]:safe_float(x.get("lastFundingRate")) for x in get(BINANCE_FUT+"/fapi/v1/premiumIndex")}
    except Exception: return {}


def oi_change(symbol):
    try:
        d=get(BINANCE_FUT+"/futures/data/openInterestHist",{"symbol":symbol,"period":"1h","limit":25})
        if len(d)<2:return None
        a=safe_float(d[0].get("sumOpenInterestValue")); b=safe_float(d[-1].get("sumOpenInterestValue"))
        return (b/a-1)*100 if a else None
    except Exception:return None


def fear_greed():
    try:return int(get(FNG,{"limit":1})["data"][0]["value"])
    except Exception:return None


def btc_dominance():
    try:return safe_float(get(COINGECKO+"/global")["data"]["market_cap_percentage"]["btc"])
    except Exception:return None

# ----------------------------- indicators -----------------------------
def ema(s,n): return s.ewm(span=n,adjust=False).mean()
def rsi(s,n=14):
    d=s.diff(); up=d.clip(lower=0).ewm(alpha=1/n,adjust=False).mean(); dn=(-d.clip(upper=0)).ewm(alpha=1/n,adjust=False).mean()
    return 100-100/(1+up/dn.replace(0,np.nan))
def atr(df,n=14):
    pc=df.close.shift(); tr=pd.concat([df.high-df.low,(df.high-pc).abs(),(df.low-pc).abs()],axis=1).max(axis=1)
    return tr.ewm(alpha=1/n,adjust=False).mean()
def adx(df,n=14):
    up=df.high.diff(); dn=-df.low.diff(); tr=atr(df,n)
    plus=up.where((up>dn)&(up>0),0).ewm(alpha=1/n,adjust=False).mean()/tr
    minus=dn.where((dn>up)&(dn>0),0).ewm(alpha=1/n,adjust=False).mean()/tr
    dx=((plus-minus).abs()/(plus+minus).replace(0,np.nan))*100
    return dx.ewm(alpha=1/n,adjust=False).mean()
def stoch_rsi(s,n=14):
    r=rsi(s,n); lo=r.rolling(n).min(); hi=r.rolling(n).max(); return (r-lo)/(hi-lo).replace(0,np.nan)*100
def vwap(df,n=30):
    pv=((df.high+df.low+df.close)/3)*df.volume; return pv.rolling(n).sum()/df.volume.rolling(n).sum()
def boll(df,n=20,k=2):
    m=df.close.rolling(n).mean(); sd=df.close.rolling(n).std(); return m+k*sd,m-k*sd

def components(df):
    o,h,l,c,v=df.open,df.high,df.low,df.close,df.volume
    e20,e50,e200=ema(c,20),ema(c,50),ema(c,200); rr=rsi(c); aa=adx(df); mac=ema(c,12)-ema(c,26); hist=mac-ema(mac,9)
    vr=v/v.rolling(20).mean(); vw=vwap(df); hi,lo=boll(df)
    green,red=c>o,c<o; body=(c-o).abs(); rng=(h-l).replace(0,np.nan); lower=np.minimum(o,c)-l; upper=h-np.maximum(o,c)
    bull=(c.shift()<o.shift())&green&(c>o.shift())&(o<c.shift()); bear=(c.shift()>o.shift())&red&(c<o.shift())&(o>c.shift())
    hammer=(lower>2*body)&(upper<body)&(body/rng>.05); shoot=(upper>2*body)&(lower<body)&(body/rng>.05)
    comp={
      "ema50":np.where(c>e50,12,-12),"ema20_50":np.where(e20>e50,9,-9),"ema200":np.where(c>e200,10,-10),
      "rsi":np.select([rr<30,rr<50,rr<=70],[7,-4,7],default=-7),
      "macd":np.select([(hist>0)&(hist>hist.shift()),hist>0,(hist<0)&(hist<hist.shift())],[13,6,-13],default=-6),
      "volume":np.where((vr>1.5)&green,12,0)+np.where((vr>1.5)&red,-12,0),
      "breakout":np.where(c>h.rolling(20).max().shift(),10,0)+np.where(c<l.rolling(20).min().shift(),-10,0),
      "candle":np.where(bull,8,0)+np.where(hammer,4,0)+np.where(bear,-8,0)+np.where(shoot,-4,0),
      "adx_trend":np.where(aa>20,np.where(c>e20,5,-5),0),
      "vwap":np.where(c>vw,4,-4),
      "boll":np.where(c>hi,5,np.where(c<lo,-5,0)),
    }
    comp={k:pd.Series(np.asarray(x,dtype=float),index=df.index) for k,x in comp.items()}; total=sum(comp.values()).clip(-100,100)
    return total,comp,rr,vr,e20,aa,vw,hi,lo

TXT={"ema50":("قیمت بالای EMA50","قیمت زیر EMA50"),"ema20_50":("EMA20 بالای EMA50","EMA20 زیر EMA50"),"ema200":("قیمت بالای EMA200","قیمت زیر EMA200"),"rsi":("RSI مساعد","RSI ضعیف/اشباع خرید"),"macd":("MACD مثبت","MACD منفی"),"volume":("حجم صعودی","حجم نزولی"),"breakout":("شکست سقف","شکست کف"),"candle":("الگوی کندلی صعودی","الگوی کندلی نزولی"),"adx_trend":("روند ADX مساعد","روند ADX نامساعد"),"vwap":("بالای VWAP","زیر VWAP"),"boll":("بالای باند بالا","زیر باند پایین")}

def label(x,up=45,down=-45): return "PUMP" if x>=up else "DUMP" if x<=down else "NEUTRAL"
def label_series(s,up=45,down=-45): return pd.Series(np.select([s>=up,s<=down],["PUMP","DUMP"],default="NEUTRAL"),index=s.index)

def levels(df,price,lookback=250,w=5):
    d=df.tail(lookback).reset_index(drop=True); ph=d.high[d.high==d.high.rolling(2*w+1,center=True).max()]; pl=d.low[d.low==d.low.rolling(2*w+1,center=True).min()]
    return sorted([x for x in pl if x<price],reverse=True)[:4],sorted([x for x in ph if x>price])[:4]

def thin(idx,gap):
    keep=[]; last=-10**9
    for i in idx:
        if i-last>=gap:keep.append(i);last=i
    return np.array(keep,dtype=int)

# ----------------------------- regime / zones -----------------------------
def market_regime(funds=None):
    vals={}
    for sym in ("BTCUSDT","ETHUSDT"):
        d4,dd=klines(sym,"4h",300),klines(sym,"1d",300)
        vals[sym]=(components(d4)[0].iloc[-2]+components(dd)[0].iloc[-2])/2
    b1=klines("BTCUSDT","1h",200); btc7=(b1.close.iloc[-2]/b1.close.iloc[-170]-1)*100
    fng,dom=fear_greed(),btc_dominance(); score=.6*vals["BTCUSDT"]+.4*vals["ETHUSDT"]
    if fng is not None:
        if fng<25:score-=10
        elif fng>75:score+=5
    regime="Risk-On" if score>=25 else "Risk-Off" if score<=-15 else "Neutral"
    return {"regime":regime,"score":round(float(score),1),"btc":round(vals["BTCUSDT"]),"eth":round(vals["ETHUSDT"]),"btc7":btc7,"fng":fng,"dom":dom,"pump_th":REGIME_THRESH[regime],"funding":funds or funding_map()}

def zone(score, price, e200, atrv):
    # Relative price location, not a replica of any proprietary model.
    z=score
    if price < e200-2*atrv: return "Discount"
    if price < e200-0.5*atrv: return "Discovery Down"
    if price <= e200+0.5*atrv: return "Neutral"
    if price <= e200+2*atrv: return "Discovery Up"
    if z>=60:return "Extreme"
    return "Premium"

# ----------------------------- news -----------------------------
def news_rss(limit=20):
    feeds=["https://www.coindesk.com/arc/outboundfeeds/rss/","https://cointelegraph.com/rss"]
    rows=[]
    for url in feeds:
        try:
            txt=S.get(url,timeout=10).text; root=ET.fromstring(txt)
            for item in root.findall(".//item")[:limit]:
                rows.append({"title":item.findtext("title") or "","link":item.findtext("link") or "","published":item.findtext("pubDate") or "","source":url.split('/')[2]})
        except Exception:pass
    return rows[:limit]

def news_score(symbol,news):
    base=symbol.replace("USDT","").upper(); pos=("approval","bullish","surge","rally","partnership","adoption","launch","inflow","growth","upgrade"); neg=("hack","exploit","lawsuit","ban","liquidation","outflow","delist","fraud","crash","unlock")
    rel=[x for x in news if base in x["title"].upper()]
    score=sum(1 if any(w in x["title"].lower() for w in pos) else -1 if any(w in x["title"].lower() for w in neg) else 0 for x in rel)
    return score,rel

# ----------------------------- analysis -----------------------------
def historical_stats(d1,current_label,hours,target):
    if len(d1)<max(300,hours+50):return (np.nan,np.nan,np.nan,0)
    fmax=d1.high.rolling(hours).max().shift(-hours)/d1.close-1; fmin=d1.low.rolling(hours).min().shift(-hours)/d1.close-1; fend=d1.close.shift(-hours)/d1.close-1
    labs=label_series(components(d1)[0]); ok=fmax.notna()&(labs==current_label)&(np.arange(len(d1))>=200); idx=thin(np.flatnonzero(ok.values),hours); n=len(idx)
    if not n:return np.nan,np.nan,np.nan,0
    return float((fmax.iloc[idx]*100>=target).mean()*100),float((fmin.iloc[idx]*100<=-target).mean()*100),float(fend.iloc[idx].mean()*100),n

def analyze(info,ctx,a,news=None):
    sym=info["symbol"]
    try:d1,d4,dd=klines(sym,"1h",max(a.history,600)),klines(sym,"4h",500),klines(sym,"1d",300)
    except Exception:return None
    if min(len(d1),len(d4),len(dd))==0 or len(d1)<300 or len(d4)<150 or len(dd)<60:return None
    t1,c1,r1,vr1,e1,adx1,vw1,hi1,lo1=components(d1); t4,c4,r4,vr4,e4,adx4,vw4,hi4,lo4=components(d4); td,cd,rd,vd,ed,ad,vwd,hid,lod=components(dd)
    s1,s4,sd=[float(x.iloc[-2]) for x in (t1,t4,td)]; score=.25*s1+.4*s4+.35*sd
    rs7=(d1.close.iloc[-2]/d1.close.iloc[-170]-1)*100-ctx["btc7"]; score+=10 if rs7>10 else 5 if rs7>5 else -10 if rs7<-10 else -5 if rs7<-5 else 0
    fund=ctx["funding"].get(sym); notes=[]
    if fund is not None:
        if fund>.001:score-=10;notes.append("Funding بسیار بالا")
        elif fund>.0005:score-=5;notes.append("Funding بالا")
        elif fund<-.0005:score+=3;notes.append("Funding منفی")
    price=info["price"]; a4=float(atr(d4).iloc[-2]); atrp=float(atr(d1).iloc[-2]/d1.close.iloc[-2]*100); rsi4=float(r4.iloc[-2]); ext=(price-float(e4.iloc[-2]))/a4 if a4 else 0
    sup,res=levels(d4,price); lab=label(score,ctx["pump_th"],-45)
    hup,hdn,avg,n=historical_stats(d1,lab,a.hours,a.target)
    if n<15:notes.append("نمونه تاریخی کم")
    if info["chg24"]>25:notes.append("حرکت شدید ۲۴h؛ ریسک FOMO")
    if rsi4>75:notes.append("RSI(4H) اشباع خرید")
    if rsi4<25:notes.append("RSI(4H) اشباع فروش")
    if vr1.iloc[-2]>4:notes.append("حجم غیرعادی")
    if info["spread"]>.15:notes.append("اسپرد بالا")
    nscore,nitems=news_score(sym,news or []); score=float(np.clip(score+nscore*2,-100,100)); lab=label(score,ctx["pump_th"],-45)
    brk=(d4.close.iloc[-2]>d4.high.rolling(20).max().shift().iloc[-2]) or (d1.close.iloc[-2]>d1.high.rolling(20).max().shift().iloc[-2])
    if lab=="PUMP":
        cat="High Risk" if atrp>3 or info["chg24"]>30 else "Wait for Pullback" if ext>2 or info["chg24"]>25 else "Breakout" if brk else "Pullback/Entry zone" if rsi4<62 and ext<1.2 else "Watchlist"
    else:cat="Avoid" if lab=="DUMP" else "Neutral"
    plan=dict(entry_lo=np.nan,entry_hi=np.nan,stop=np.nan,t1=np.nan,t2=np.nan,rr_res=np.nan)
    if lab=="PUMP":
        if ext>2:e=float(e4.iloc[-2]); plan["entry_lo"],plan["entry_hi"]=e-.3*a4,e+.3*a4
        else:plan["entry_lo"],plan["entry_hi"]=price-.3*a4,price
        mid=(plan["entry_lo"]+plan["entry_hi"])/2; plan["stop"]=plan["entry_lo"]-1.2*a4; risk=mid-plan["stop"];plan["t1"],plan["t2"]=mid+1.5*risk,mid+3*risk
        if res:plan["rr_res"]=(res[0]-mid)/risk
    sign=1 if lab=="PUMP" else -1 if lab=="DUMP" else 0; agree=sum(1 for x in (s1,s4,sd) if sign and x*sign>15)
    conf="High" if agree==3 and n>=30 and ctx["regime"]!="Risk-Off" else "Low" if agree<=1 or n<15 else "Medium"
    e200=float(ed.iloc[-2]); z=zone(score,price,e200,a4)
    prime=(lab=="PUMP" and z in ("Discount","Discovery Down") and agree>=2) or (lab=="DUMP" and z in ("Premium","Extreme") and agree>=2)
    oi=None
    pros=[];cons=[]
    for tf,cc in (("1H",c1),("4H",c4),("1D",cd)):
        for k,ser in cc.items():
            v=ser.iloc[-2]
            (pros if v>0 else cons).append(f"[{tf}] {TXT.get(k,(k,k))[0 if v>0 else 1]}") if v!=0 else None
    return {"symbol":sym,"price":price,"chg24":info["chg24"],"vol24M":info["vol24"]/1e6,"s1h":round(s1),"s4h":round(s4),"s1d":round(sd),"score":round(score,1),"signal":lab,"category":cat,"confidence":conf,"zone":z,"prime_point":bool(prime),"rsi4h":round(rsi4,1),"adx4h":round(float(adx4.iloc[-2]),1),"atr1h%":round(atrp,2),"rs7_vs_btc":round(rs7,1),"funding%":None if fund is None else round(fund*100,4),"oi24h%":oi,"support":sup[0] if sup else np.nan,"resistance":res[0] if res else np.nan,**plan,"hist_up":hup,"hist_down":hdn,"avg_fwd%":avg,"samples":n,"news_score":nscore,"news_count":len(nitems),"notes":" | ".join(notes),"_pros":pros,"_cons":cons,"_news":nitems,"_sups":sup,"_ress":res}

# ----------------------------- risk / journal -----------------------------
def risk_position(capital,risk_pct,entry,stop):
    risk_cash=capital*risk_pct/100; dist=abs(entry-stop)
    if dist<=0:return None
    qty=risk_cash/dist; notional=qty*entry; return {"risk_cash":risk_cash,"qty":qty,"notional":notional,"stop_pct":dist/entry*100}

def db():
    c=sqlite3.connect(DB_FILE); c.execute("CREATE TABLE IF NOT EXISTS signals(id INTEGER PRIMARY KEY,time_utc TEXT,symbol TEXT,price REAL,entry_lo REAL,entry_hi REAL,stop REAL,t1 REAL,t2 REAL,score REAL,category TEXT,result TEXT DEFAULT 'OPEN')"); c.commit(); return c

def log_signals(rows,now):
    c=db(); cut=datetime.now(timezone.utc)-timedelta(hours=12)
    for _,r in rows.iterrows():
        old=c.execute("SELECT 1 FROM signals WHERE symbol=? AND time_utc>=?",(r.symbol,cut.strftime("%Y-%m-%d %H:%M"))).fetchone()
        if old:continue
        c.execute("INSERT INTO signals(time_utc,symbol,price,entry_lo,entry_hi,stop,t1,t2,score,category) VALUES(?,?,?,?,?,?,?,?,?,?)",(now,r.symbol,r.price,r.entry_lo,r.entry_hi,r.stop,r.t1,r.t2,r.score,r.category))
    c.commit();c.close()

def evaluate_db():
    c=db(); rows=pd.read_sql_query("SELECT * FROM signals ORDER BY id",c); c.close(); out=[]
    for _,r in rows.iterrows():
        try:k=klines(r.symbol,"1h",1000); t0=int(pd.Timestamp(r.time_utc.replace(" UTC","")).tz_localize("UTC").timestamp()*1000);k=k[k.t>=t0]
        except Exception:out.append("DATA_ERROR");continue
        trig=t1=False;res="OPEN"
        for _,candle in k.iterrows():
            if not trig:
                if candle.low<=r.entry_hi:trig=True
                else:continue
            if candle.low<=r.stop:res="T1_then_STOP" if t1 else "STOP";break
            if candle.high>=r.t1:t1=True
            if candle.high>=r.t2:res="T2";break
        else:res=("T1_OPEN" if t1 else "OPEN") if trig else "NOT_TRIGGERED"
        out.append(res)
    if len(out)==len(rows):
        rows["result"]=out; print(rows[["time_utc","symbol","score","category","result"]].to_string(index=False)); print("\nخلاصه:\n"+rows.result.value_counts().to_string())

# ----------------------------- reports -----------------------------
def fp(x):return "-" if x is None or (isinstance(x,float) and np.isnan(x)) else f"{x:.6g}"
def shortlist(df,a):
    return df[(df.signal=="PUMP")&df.category.isin(["Breakout","Pullback/Entry zone"])&(df.samples>=10)&(df.hist_up>=a.min_hit)].sort_values(["prime_point","score","hist_up"],ascending=False).head(7)
def regime_text(ctx):return f"بازار: {ctx['regime']} | امتیاز {ctx['score']} | BTC {ctx['btc']} | ETH {ctx['eth']} | F&G {ctx['fng'] or '-'} | BTC.D {fp(ctx['dom'])}% | آستانه PUMP {ctx['pump_th']}"

def write_html(df,ctx,short,a,now,news):
    cols=["symbol","price","chg24","score","signal","category","confidence","zone","prime_point","hist_up","hist_down","samples","news_score","notes"]
    def table(p):
        h=''.join('<th>'+html.escape(c)+'</th>' for c in cols); rr=''.join('<tr>'+''.join('<td>'+html.escape(fp(x[c]) if isinstance(x[c],float) else str(x[c]))+'</td>' for c in cols)+'</tr>' for _,x in p.iterrows()); return '<table><tr>'+h+'</tr>'+rr+'</table>'
    body=f"<h1>Crypto Radar Scanner Pro</h1><p>{html.escape(now)}</p><p>{html.escape(regime_text(ctx))}</p><h2>Shortlist</h2>{table(short) if len(short) else '<p>ستاپ واجد شرایط پیدا نشد.</p>'}<h2>PUMP</h2>{table(df[df.signal=='PUMP'].head(40))}<h2>DUMP</h2>{table(df[df.signal=='DUMP'].head(40))}<h2>News</h2><ul>"+''.join(f"<li>{html.escape(n['title'])} — {html.escape(n['source'])}</li>" for n in news)+"</ul><p>ابزار تحقیقاتی؛ هیچ سیگنالی تضمین سود نیست.</p>"
    css="body{font-family:Tahoma,sans-serif;margin:24px;line-height:1.7}table{border-collapse:collapse;width:100%;margin:16px 0}td,th{border:1px solid #ccc;padding:5px;font-size:12px}th{background:#eee}"
    open(a.html,'w',encoding='utf-8').write(f"<!doctype html><html lang='fa' dir='rtl'><meta charset='utf-8'><style>{css}</style><body>{body}</body></html>")

def telegram(msg):
    tok,chat=os.getenv("TG_TOKEN"),os.getenv("TG_CHAT")
    if not tok or not chat:return
    try:S.post(f"https://api.telegram.org/bot{tok}/sendMessage",json={"chat_id":chat,"text":msg[:4000]},timeout=15).raise_for_status()
    except Exception as e:print("Telegram:",e)

def notify(short,ctx,a):
    st=json.load(open(STATE_FILE)) if os.path.exists(STATE_FILE) else {}; now=time.time(); lines=[]
    for _,r in short.iterrows():
        if now-st.get(r.symbol,0)<a.cooldown*3600:continue
        st[r.symbol]=now; lines.append(f"🟢 {r.symbol} | {r.category} | {r.score} | {r.zone}\nEntry {fp(r.entry_lo)}–{fp(r.entry_hi)} | SL {fp(r.stop)} | T1 {fp(r.t1)} | T2 {fp(r.t2)}\nHist {fp(r.hist_up)}% (n={r.samples})")
    if lines:telegram(regime_text(ctx)+"\n\n"+"\n\n".join(lines));json.dump(st,open(STATE_FILE,'w'))

# ----------------------------- run modes -----------------------------
def run_scan(a):
    now=now_utc(); news=news_rss(a.news_limit) if not a.no_news else []; ctx=market_regime(); syms=list_binance(a.min_volume,a.top,a.max_spread)
    print(f"{len(syms)} نماد؛ در حال تحلیل چندتایم‌فریمی...")
    with ThreadPoolExecutor(max_workers=a.workers) as ex: rows=[r for r in ex.map(lambda i:analyze(i,ctx,a,news),syms) if r]
    if not rows:raise SystemExit("داده‌ای دریافت نشد؛ اتصال/پروکسی را بررسی کنید.")
    df=pd.DataFrame(rows); short=shortlist(df,a)
    for sym in short.symbol:
        v=oi_change(sym); df.loc[df.symbol==sym,"oi24h%"]=v; short.loc[short.symbol==sym,"oi24h%"]=v
    df.drop(columns=[c for c in df if c.startswith('_')],errors='ignore').to_csv(a.csv,index=False,encoding='utf-8-sig');write_html(df,ctx,short,a,now,news)
    print("\n"+regime_text(ctx));print("\n=== SHORTLIST ===")
    if short.empty:print("ستاپ باکیفیت پیدا نشد؛ معامله را اجباری نکنید.")
    for _,r in short.iterrows():print(f"{r.symbol} | {r.category} | {r.zone} | Prime={r.prime_point} | score={r.score} | entry {fp(r.entry_lo)}–{fp(r.entry_hi)} | SL {fp(r.stop)} | T1 {fp(r.t1)} | T2 {fp(r.t2)} | hist {fp(r.hist_up)}% n={r.samples}")
    log_signals(short,now)
    if a.telegram:notify(short,ctx,a)
    print(f"\nخروجی: {a.csv} | {a.html} | {DB_FILE}")

def single(a):
    ctx=market_regime();sym=a.coin.upper();sym=sym if sym.endswith('USDT') else sym+'USDT';t=spot_get('/api/v3/ticker/24hr',{'symbol':sym});bid=safe_float(t['bidPrice']);ask=safe_float(t['askPrice']);info={'symbol':sym,'price':safe_float(t['lastPrice']),'chg24':safe_float(t['priceChangePercent']),'vol24':safe_float(t['quoteVolume']),'spread':(ask-bid)/((ask+bid)/2)*100};r=analyze(info,ctx,a,news_rss(a.news_limit) if not a.no_news else [])
    if not r:raise SystemExit('داده کافی نیست')
    print(regime_text(ctx));print(json.dumps({k:v for k,v in r.items() if not k.startswith('_')},ensure_ascii=False,indent=2));print('\nعوامل مثبت:\n'+'\n'.join(r['_pros']));print('\nعوامل منفی:\n'+'\n'.join(r['_cons']))
    if a.capital>0 and np.isfinite(r['entry_lo']) and np.isfinite(r['stop']):print('\nسایز پیشنهادی بر اساس ریسک:',risk_position(a.capital,a.risk_pct,(r['entry_lo']+r['entry_hi'])/2,r['stop']))

def main():
    p=argparse.ArgumentParser(description='Crypto Radar Scanner Pro');p.add_argument('--coin');p.add_argument('--evaluate',action='store_true');p.add_argument('--min-volume',type=float,default=2_000_000);p.add_argument('--max-spread',type=float,default=.3);p.add_argument('--top',type=int,default=150);p.add_argument('--target',type=float,default=10);p.add_argument('--hours',type=int,default=48);p.add_argument('--history',type=int,default=2000);p.add_argument('--min-hit',type=float,default=10);p.add_argument('--loop',type=int,default=0);p.add_argument('--telegram',action='store_true');p.add_argument('--cooldown',type=float,default=12);p.add_argument('--proxy');p.add_argument('--workers',type=int,default=6);p.add_argument('--news-limit',type=int,default=20);p.add_argument('--no-news',action='store_true');p.add_argument('--capital',type=float,default=0);p.add_argument('--risk-pct',type=float,default=1);p.add_argument('--csv',default=CSV_FILE);p.add_argument('--html',default=HTML_FILE);a=p.parse_args()
    if a.proxy:S.proxies={'http':a.proxy,'https':a.proxy}
    if a.evaluate:return evaluate_db()
    if a.coin:return single(a)
    while True:
        try:run_scan(a)
        except KeyboardInterrupt:break
        except Exception as e:print('خطا:',repr(e))
        if not a.loop:break
        time.sleep(a.loop*60)
if __name__=='__main__':main()

"""Walk-forward backtest using the same signal/plan/risk engine."""
from . import ranking,risk
from .journal import compute_stats
from .monitor import apply_bars,_close
from .plan import build_plan


def _simulate(plan,future,cfg):
    t={"symbol":plan.symbol,"direction":plan.direction,"entry":plan.entry,"stop":plan.stop,
       "tp1":plan.tp1,"tp2":plan.tp2,"qty":plan.qty,"qty_open":plan.qty,
       "risk_amount":plan.risk_amount,"realized_pnl":0.0,"tp1_hit":0,"status":"open"}
    used=0
    for ts,row in future.iterrows():
        used+=1
        t,_=apply_bars(t,[(ts,float(row.high),float(row.low))])
        if t["status"]!="open": break
    if t["status"]=="open" and used: _close(t,float(future.close.iloc[used-1]))
    slippage=2*(cfg.slippage_bps/10000)*plan.notional
    fees=2*(cfg.fee_pct/100)*plan.notional
    net=t["realized_pnl"]-slippage-fees
    return net/plan.risk_amount,used


def run_backtest(provider,cfg,n_symbols=10,horizon=72,step=4,start=600,log=print):
    uni=provider.universe(n_symbols,0); btc=provider.klines("BTCUSDT","1h",1000)
    rs=[]; per={}
    for u in uni:
        sym=u["symbol"]; df=provider.klines(sym,"1h",1000); i=start; count=0
        while i<len(df)-2:
            regime=ranking.market_regime(btc.loc[:df.index[i]])
            st=ranking.evaluate_symbol(sym,df.iloc[:i+1],regime,cfg,1e12)
            if st and st.score>=cfg.min_score:
                plan=build_plan(st,cfg)
                if risk.evaluate(plan,cfg,regime,None).approved:
                    r,used=_simulate(plan,df.iloc[i+1:i+1+horizon],cfg)
                    rs.append(r); count+=1; i+=max(used,1); continue
            i+=step
        per[sym]=count; log(f"  {sym}: {count} trades")
    return compute_stats(rs),per

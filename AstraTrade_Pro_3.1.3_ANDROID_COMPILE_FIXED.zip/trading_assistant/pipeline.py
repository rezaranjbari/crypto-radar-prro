"""End-to-end scan pipeline."""
from . import ranking, risk
from .plan import build_plan


def run_scan(provider,cfg,portfolio=None,log=print):
    log("① دریافت داده و رژیم بازار...")
    uni=provider.universe(cfg.universe_size,cfg.min_quote_volume)
    btc=provider.klines("BTCUSDT","1h",1000)
    regime=ranking.market_regime(btc)
    setups=[]
    for u in uni:
        try:
            df=provider.klines(u["symbol"],"1h",1000)
            setups.append(ranking.evaluate_symbol(u["symbol"],df,regime,cfg,u["quote_volume"]))
        except Exception as e:
            log(f"  رد {u.get('symbol','?')}: {e}")
    top=ranking.rank(setups,cfg.top_n*2)
    results=[]
    for st in top:
        try:
            plan=build_plan(st,cfg)
            verdict=risk.evaluate(plan,cfg,regime,portfolio)
            results.append((plan,verdict))
        except Exception as e:
            log(f"  خطا در پلن {st.symbol}: {e}")
    return regime,results

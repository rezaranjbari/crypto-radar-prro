"""Trade-plan construction with ATR/swing stops and liquidity-aware targets."""
from dataclasses import dataclass, field


@dataclass
class Plan:
    symbol:str; direction:str; entry:float; stop:float; tp1:float; tp2:float
    rr:float; room_r:float; stop_pct:float; qty:float; notional:float
    risk_amount:float; score:float; reasons:list=field(default_factory=list)
    metrics:dict=field(default_factory=dict)


def build_plan(setup,cfg):
    m=setup.metrics; s=1 if setup.direction=="long" else -1
    entry,a=m["close"],m["atr"]
    if a<=0 or entry<=0: raise ValueError("invalid price/ATR")
    if s==1:
        stop=min(m["swing_low"]-.25*a, entry-1.15*a)
        stop=max(stop, entry-3.5*a)
    else:
        stop=max(m["swing_high"]+.25*a, entry+1.15*a)
        stop=min(stop, entry+3.5*a)
    risk=abs(entry-stop)
    tp1=entry+s*1.5*risk; tp2=entry+s*3.0*risk
    level=m["resistance"] if s==1 else m["support"]
    ahead=(level-entry)*s
    room_r=ahead/risk if ahead>0 else 99
    if ahead>0:
        cap=level-s*level*.001
        tp1=min(tp1,cap) if s==1 else max(tp1,cap)
        tp2=min(tp2,cap) if s==1 else max(tp2,cap)
    rr=(((tp1-entry)*s)+((tp2-entry)*s))/2/risk
    risk_amount=cfg.account_size*cfg.risk_per_trade_pct/100
    qty=risk_amount/risk
    max_notional=cfg.account_size*cfg.max_leverage
    if qty*entry>max_notional:
        qty=max_notional/entry
        risk_amount=qty*risk
    return Plan(setup.symbol,setup.direction,entry,stop,tp1,tp2,rr,room_r,
                risk/entry*100,qty,qty*entry,risk_amount,setup.score,
                list(setup.reasons),dict(m))

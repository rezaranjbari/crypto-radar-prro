"""Paper-trade monitoring with conservative same-candle handling."""
import time
import pandas as pd
from .journal import now_iso


def _close(t,price):
    s=1 if t["direction"]=="long" else -1
    t["realized_pnl"]+=(price-t["entry"])*s*t["qty_open"]
    t["qty_open"]=0.0; t["status"]="closed"; t["exit_price"]=price; t["closed_at"]=now_iso()
    t["r_multiple"]=t["realized_pnl"]/t["risk_amount"] if t["risk_amount"] else 0


def apply_bars(trade,bars):
    t=dict(trade); events=[]; s=1 if t["direction"]=="long" else -1
    for _,high,low in bars:
        if t["status"]!="open": break
        stop_hit=low<=t["stop"] if s==1 else high>=t["stop"]
        tp1_now=(not t["tp1_hit"]) and ((high>=t["tp1"]) if s==1 else (low<=t["tp1"]))
        tp2_now=t["tp1_hit"] and ((high>=t["tp2"]) if s==1 else (low<=t["tp2"]))
        if stop_hit:
            kind="breakeven" if t["tp1_hit"] else "stop"
            _close(t,t["stop"]); events.append((kind,f"{t['symbol']}: {kind} at {t['stop']:.8g}")); break
        if tp1_now:
            part=t["qty"]*.5
            t["realized_pnl"]+=(t["tp1"]-t["entry"])*s*part
            t["qty_open"]-=part; t["tp1_hit"]=1; t["stop"]=t["entry"]
            events.append(("tp1",f"{t['symbol']}: TP1 hit; 50% closed; stop moved to entry"))
        elif tp2_now:
            _close(t,t["tp2"]); events.append(("tp2",f"{t['symbol']}: TP2 hit; trade closed"))
    return t,events


def df_to_bars(df):
    return [(ts,float(r.high),float(r.low)) for ts,r in zip(df.index,df.itertuples())]


def check_once(journal,provider,notifier):
    n=0
    for trade in journal.open_trades():
        since=pd.Timestamp(trade["last_check"] or trade["opened_at"])
        try:
            df=provider.klines(trade["symbol"],"1m",30)
            bars=[b for b in df_to_bars(df) if b[0]>since]
            p=provider.last_price(trade["symbol"])
            bars.append((pd.Timestamp.now(tz="UTC"),p,p))
        except Exception as e:
            notifier.send(f"monitor error {trade['symbol']}: {e}"); continue
        new,events=apply_bars(trade,bars)
        upd={k:new[k] for k in ("stop","tp1_hit","qty_open","realized_pnl","status","closed_at","exit_price","r_multiple")}
        upd["last_check"]=now_iso(); journal.update_trade(trade["id"],**upd)
        for _,msg in events: notifier.send(msg); n+=1
    return n


def run_loop(journal,provider,notifier,interval=30,once=False):
    while True:
        check_once(journal,provider,notifier)
        if once or not journal.open_trades(): return
        time.sleep(interval)

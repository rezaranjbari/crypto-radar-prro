"""SQLite journal for signals, paper trades and performance."""
import sqlite3
from datetime import datetime, timezone


def now_iso(): return datetime.now(timezone.utc).isoformat()


class Journal:
    def __init__(self,path="journal.db"):
        self.db=sqlite3.connect(path)
        self.db.row_factory=sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS signals(
          id INTEGER PRIMARY KEY, ts TEXT, symbol TEXT, direction TEXT, score REAL,
          entry REAL, stop REAL, tp1 REAL, tp2 REAL, rr REAL, approved INTEGER, reasons TEXT);
        CREATE TABLE IF NOT EXISTS trades(
          id INTEGER PRIMARY KEY, signal_id INTEGER, symbol TEXT, direction TEXT,
          entry REAL, stop REAL, initial_stop REAL, tp1 REAL, tp2 REAL, qty REAL, qty_open REAL,
          risk_amount REAL, realized_pnl REAL DEFAULT 0, tp1_hit INTEGER DEFAULT 0,
          status TEXT DEFAULT 'open', opened_at TEXT, closed_at TEXT, exit_price REAL,
          r_multiple REAL, updated_at TEXT, last_check TEXT, note TEXT);
        CREATE INDEX IF NOT EXISTS idx_trades_status ON trades(status);
        CREATE INDEX IF NOT EXISTS idx_signals_ts ON signals(ts);
        """)

    def log_signal(self,plan,verdict):
        cur=self.db.execute(
          "INSERT INTO signals(ts,symbol,direction,score,entry,stop,tp1,tp2,rr,approved,reasons) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
          (now_iso(),plan.symbol,plan.direction,plan.score,plan.entry,plan.stop,plan.tp1,plan.tp2,
           plan.rr,int(verdict.approved)," | ".join(verdict.failures or plan.reasons)))
        self.db.commit(); return cur.lastrowid

    def open_trade(self,plan,signal_id=None):
        t=now_iso()
        cur=self.db.execute(
          "INSERT INTO trades(signal_id,symbol,direction,entry,stop,initial_stop,tp1,tp2,qty,qty_open,risk_amount,opened_at,updated_at,last_check) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
          (signal_id,plan.symbol,plan.direction,plan.entry,plan.stop,plan.stop,plan.tp1,plan.tp2,
           plan.qty,plan.qty,plan.risk_amount,t,t,t))
        self.db.commit(); return cur.lastrowid

    def get_trade(self,tid):
        r=self.db.execute("SELECT * FROM trades WHERE id=?",(tid,)).fetchone()
        return dict(r) if r else None

    def open_trades(self):
        return [dict(r) for r in self.db.execute("SELECT * FROM trades WHERE status='open' ORDER BY id")]

    def closed_trades(self):
        return [dict(r) for r in self.db.execute("SELECT * FROM trades WHERE status='closed' ORDER BY id")]

    def update_trade(self,tid,**fields):
        allowed={"stop","tp1_hit","qty_open","realized_pnl","status","closed_at","exit_price",
                 "r_multiple","updated_at","last_check","note"}
        bad=set(fields)-allowed
        if bad: raise ValueError(f"invalid columns: {bad}")
        fields.setdefault("updated_at",now_iso())
        sets=",".join(f"{k}=?" for k in fields)
        self.db.execute(f"UPDATE trades SET {sets} WHERE id=?",( *fields.values(),tid)); self.db.commit()

    def today_realized_pnl(self):
        day=datetime.now(timezone.utc).strftime("%Y-%m-%d")
        r=self.db.execute("SELECT COALESCE(SUM(realized_pnl),0) FROM trades WHERE substr(updated_at,1,10)=?",(day,)).fetchone()
        return float(r[0])

    def portfolio(self): return {"open_trades":self.open_trades(),"today_pnl":self.today_realized_pnl()}

    def stats(self):
        return compute_stats([t["r_multiple"] for t in self.closed_trades() if t["r_multiple"] is not None],
                             [t["realized_pnl"] for t in self.closed_trades()])


def compute_stats(rs,pnls=None):
    n=len(rs)
    if not n: return {"trades":0}
    wins=[r for r in rs if r>0]; losses=[r for r in rs if r<=0]
    gp,gl=sum(wins),-sum(losses)
    eq=peak=mdd=0.0
    for r in rs:
        eq+=r; peak=max(peak,eq); mdd=max(mdd,peak-eq)
    return {"trades":n,"win_rate":len(wins)/n*100,"avg_r":sum(rs)/n,"total_r":sum(rs),
            "profit_factor":gp/gl if gl else float("inf"),"max_drawdown_r":mdd,
            "total_pnl":sum(pnls) if pnls else None}

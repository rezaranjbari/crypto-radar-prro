# تغییرات AstraTrade Pro 3.1

- ادغام موتور Trading Assistant و Advanced Scanner در یک پروژه.
- ارتقای اپ Android با Dashboard، Scanner، Smart Navigator، News و Risk Center.
- نمودار Sparkline و تحلیل 4H داخل اپ.
- دریافت Funding Rate و تغییر Open Interest از Binance Futures.
- Fear & Greed، قیمت Nobitex و Wallex.
- محاسبه Entry/SL/TP و Position Sizing بر اساس درصد ریسک.
- APIهای `/api/advanced/scan` و `/api/advanced/risk` برای اتصال کلاینت‌ها به موتور حرفه‌ای.
- تست‌های Python: 10 مورد موفق.
- هیچ سفارش واقعی ارسال نمی‌شود.

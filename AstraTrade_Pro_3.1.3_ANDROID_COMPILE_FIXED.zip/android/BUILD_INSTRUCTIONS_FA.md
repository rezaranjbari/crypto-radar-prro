# راهنمای ساخت APK

1. این ZIP را در GitHub داخل Repository قرار دهید.
2. در ریشه Repository باید پوشه `android` و پوشه `.github/workflows` وجود داشته باشد.
3. وارد Actions شوید.
4. Workflow با نام `Build Android APK` را انتخاب کنید.
5. گزینه Run workflow را بزنید.
6. بعد از موفقیت، در بخش Artifacts فایل `astratrade-pro-debug-apk` را دریافت کنید.

نکته:
- این نسخه برای شروع، به API عمومی داده‌های Binance Vision وصل می‌شود.
- سفارش واقعی ارسال نمی‌کند.
- موتور تحلیل Python نسخه حرفه‌ای در کنار اپ قرار دارد و برای تبدیل شدن به backend/API مستقل آماده است.
- برای صرافی‌های ایرانی باید API رسمی هر صرافی جداگانه به Provider اضافه شود تا قیمت اشتباه وارد سیستم نشود.

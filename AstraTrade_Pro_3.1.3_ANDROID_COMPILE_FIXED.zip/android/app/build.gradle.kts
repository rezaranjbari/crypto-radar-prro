plugins {
 id("com.android.application")
 id("org.jetbrains.kotlin.android")
}
android {
 namespace="com.astratrade.pro"
 compileSdk=35
 defaultConfig {
  applicationId="com.astratrade.pro"
  minSdk=26
  targetSdk=35
  versionCode=5
  versionName="3.1.3"
 }
 compileOptions {
  sourceCompatibility = JavaVersion.VERSION_17
  targetCompatibility = JavaVersion.VERSION_17
 }
 kotlinOptions {
  jvmTarget = "17"
 }
 buildFeatures { compose=true }
 composeOptions { kotlinCompilerExtensionVersion="1.5.15" }
 packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}
dependencies {
 implementation("androidx.core:core-ktx:1.15.0")
 implementation("androidx.activity:activity-compose:1.9.3")
 implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.4")
 implementation("androidx.compose.ui:ui:1.7.8")
 implementation("androidx.compose.ui:ui-tooling-preview:1.7.8")
 implementation("androidx.compose.material3:material3:1.3.1")
 implementation("androidx.navigation:navigation-compose:2.8.4")
 implementation("androidx.datastore:datastore-preferences:1.1.1")
 implementation("com.squareup.okhttp3:okhttp:4.12.0")
 implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
 debugImplementation("androidx.compose.ui:ui-tooling:1.7.8")
}

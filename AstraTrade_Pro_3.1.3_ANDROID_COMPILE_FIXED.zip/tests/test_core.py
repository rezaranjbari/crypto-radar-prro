import pandas as pd
from trading_assistant.config import Config
from trading_assistant.data import DemoProvider
from trading_assistant.indicators import rsi, atr, adx, bollinger
from trading_assistant.pipeline import run_scan
from trading_assistant.journal import Journal, compute_stats
from trading_assistant.monitor import apply_bars
from trading_assistant.ranking import market_regime


def trade(direction="long"):
    s=1 if direction=="long" else -1
    return {"symbol":"TEST","direction":direction,"entry":100.0,"stop":100-5*s,
            "initial_stop":100-5*s,"tp1":100+7.5*s,"tp2":100+15*s,
            "qty":2.0,"qty_open":2.0,"risk_amount":10.0,"realized_pnl":0.0,
            "tp1_hit":0,"status":"open"}


def test_indicators():
    s=pd.Series(range(1,500),dtype=float)
    assert rsi(s).iloc[-1] == 100
    assert atr(pd.DataFrame({"high":s+1,"low":s-1,"close":s})).iloc[-1] > 0
    assert adx(pd.DataFrame({"high":s+1,"low":s-1,"close":s})).iloc[-1] >= 0
    mid,up,dn=bollinger(s); assert up.iloc[-1] >= mid.iloc[-1] >= dn.iloc[-1]


def test_monitor():
    t,e=apply_bars(trade(),[(None,108,99)])
    assert t["tp1_hit"]==1 and t["stop"]==100 and t["qty_open"]==1
    t,e=apply_bars(t,[(None,116,104)])
    assert t["status"]=="closed" and abs(t["realized_pnl"]-22.5)<1e-9


def test_same_bar_stop_first():
    t,e=apply_bars(trade(),[(None,120,90)])
    assert e[0][0]=="stop"


def test_pipeline():
    cfg=Config(min_quote_volume=0, top_n=5)
    regime,results=run_scan(DemoProvider(),cfg,log=lambda *_:None)
    assert regime["name"] in {"bull","bear","range"} and results


def test_stats():
    s=compute_stats([2,-1,2,-1,-1])
    assert s["trades"]==5 and abs(s["profit_factor"]-4/3)<1e-9


def test_journal(tmp_path):
    cfg=Config(min_quote_volume=0,db_path=str(tmp_path/"j.db"))
    _,results=run_scan(DemoProvider(),cfg,log=lambda *_:None)
    p,v=results[0]; j=Journal(cfg.db_path); sid=j.log_signal(p,v); tid=j.open_trade(p,sid)
    assert j.open_trades()[0]["id"]==tid
    j.update_trade(tid,status="closed",r_multiple=1.5,realized_pnl=15)
    assert j.stats()["trades"]==1

from fastapi.testclient import TestClient
from trading_assistant.api import app

client=TestClient(app)

def test_health():
    r=client.get('/health'); assert r.status_code==200 and r.json()['ok']

def test_dashboard():
    r=client.get('/'); assert r.status_code==200 and 'AstraTrade Pro' in r.text

def test_config():
    r=client.get('/api/config'); assert r.status_code==200 and 'risk_per_trade_pct' in r.json()


def test_advanced_risk_validation():
    r=client.get('/api/advanced/risk', params={'capital':1000,'risk_pct':1,'entry':100,'stop':95})
    assert r.status_code==200 and r.json()['risk_cash']==10

# یادداشت ساخت

1. مخزن را روی GitHub قرار دهید.
2. از Actions، workflow با نام Build Android APK را اجرا کنید.
3. خروجی `astratrade-pro-debug-apk` را از Artifacts دریافت کنید.

نکته: محیط فعلی امکان اجرای Gradle/دریافت وابستگی‌های Android را نداشت؛ بنابراین APK را اینجا ادعا نمی‌کنیم که محلی build شده است. تست Python با 10 تست موفق انجام شد و GitHub Actions مسئول build Android است.

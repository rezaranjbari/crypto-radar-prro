package com.example.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.core.view.WindowCompat

private val HardenedDarkColorScheme = darkColorScheme(
    primary = NeonEmerald,
    onPrimary = CyberNavyBackground,
    primaryContainer = NeonEmeraldContainer,
    onPrimaryContainer = NeonEmerald,

    secondary = NeonCyan,
    onSecondary = CyberNavyBackground,
    secondaryContainer = NeonCyanContainer,
    onSecondaryContainer = NeonCyan,

    tertiary = NeonPurple,
    onTertiary = CyberNavyBackground,

    background = CyberNavyBackground,
    onBackground = TextPrimary,

    surface = CyberNavySurface,
    onSurface = TextPrimary,
    surfaceVariant = CyberNavyCard,
    onSurfaceVariant = TextSecondary,

    outline = CyberBorder,
    outlineVariant = CyberBorderGlow,

    error = NeonRed,
    onError = TextPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false, // Keep high-contrast cyber theme for security tool
    content: @Composable () -> Unit
) {
    val colorScheme = HardenedDarkColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = CyberNavyBackground.toArgb()
                window.navigationBarColor = CyberNavyBackground.toArgb()
                val insetsController = WindowCompat.getInsetsController(window, view)
                insetsController.isAppearanceLightStatusBars = false
                insetsController.isAppearanceLightNavigationBars = false
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AuditCategory
import com.example.data.model.AuditCheckItem
import com.example.data.model.AuditStatus
import com.example.ui.MainViewModel
import com.example.ui.components.CyberBadge
import com.example.ui.components.CyberCard
import com.example.ui.components.MetricBox
import com.example.ui.components.SectionHeader
import com.example.ui.theme.CyberBorder
import com.example.ui.theme.CyberNavyBackground
import com.example.ui.theme.CyberNavyCard
import com.example.ui.theme.CyberNavySurface
import com.example.ui.theme.NeonAmber
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonEmerald
import com.example.ui.theme.NeonRed
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SecurityAuditScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val report by viewModel.auditReport.collectAsState()
    val isAuditing by viewModel.isAuditing.collectAsState()
    var selectedCategory by remember { mutableStateOf<AuditCategory?>(null) }
    var showReportDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    val filteredItems = remember(report, selectedCategory) {
        val all = report?.items ?: emptyList()
        if (selectedCategory == null) all else all.filter { it.category == selectedCategory }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(8.dp))
            report?.let { rep ->
                AuditScoreHeader(
                    score = rep.totalScore,
                    secureCount = rep.secureCount,
                    warnCount = rep.warningCount,
                    insecureCount = rep.insecureCount,
                    isAuditing = isAuditing,
                    onRunAudit = { viewModel.runSecurityAudit() },
                    onViewReport = { showReportDialog = true }
                )
            }
        }

        // Category Filter Chips
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                item {
                    FilterChip(
                        selected = selectedCategory == null,
                        onClick = { selectedCategory = null },
                        label = { Text("همه بررسی‌ها") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonEmerald.copy(alpha = 0.2f),
                            selectedLabelColor = NeonEmerald,
                            containerColor = CyberNavySurface,
                            labelColor = TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedCategory == null,
                            borderColor = CyberBorder,
                            selectedBorderColor = NeonEmerald
                        )
                    )
                }

                items(AuditCategory.entries.toTypedArray()) { category ->
                    FilterChip(
                        selected = selectedCategory == category,
                        onClick = { selectedCategory = category },
                        label = { Text(category.title) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonCyan.copy(alpha = 0.2f),
                            selectedLabelColor = NeonCyan,
                            containerColor = CyberNavySurface,
                            labelColor = TextSecondary
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = selectedCategory == category,
                            borderColor = CyberBorder,
                            selectedBorderColor = NeonCyan
                        )
                    )
                }
            }
        }

        item {
            SectionHeader(
                title = "چک‌لیست ۱۲ مرحله‌ای ایمن‌سازی",
                subtitle = "اعمال سیاست‌های امنیتی Pipeline CI در GitHub"
            )
        }

        items(filteredItems, key = { it.id }) { checkItem ->
            AuditCheckItemCard(checkItem)
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    if (showReportDialog && report != null) {
        SecurityReportDialog(
            reportText = report!!.rawReportText,
            onDismiss = { showReportDialog = false },
            onCopy = {
                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("SECURITY_REPORT.txt", report!!.rawReportText))
                Toast.makeText(context, "SECURITY_REPORT.txt در کلیپ‌بورد کپی شد", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
fun AuditScoreHeader(
    score: Int,
    secureCount: Int,
    warnCount: Int,
    insecureCount: Int,
    isAuditing: Boolean,
    onRunAudit: () -> Unit,
    onViewReport: () -> Unit
) {
    CyberCard(
        borderColor = if (score >= 90) NeonEmerald.copy(alpha = 0.6f) else NeonAmber.copy(alpha = 0.6f),
        backgroundColor = CyberNavyCard
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                CyberBadge(
                    text = "نسخه شخصی ایمن‌سازی‌شده",
                    color = NeonCyan
                )

                OutlinedButton(
                    onClick = onViewReport,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonEmerald),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CyberBorder),
                    modifier = Modifier.testTag("view_security_report_button")
                ) {
                    Icon(Icons.Default.Description, contentDescription = "گزارش", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("SECURITY_REPORT.txt", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Score Circular Gauge Indicator
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.size(110.dp)
            ) {
                CircularProgressIndicator(
                    progress = { score / 100f },
                    modifier = Modifier.fillMaxSize(),
                    color = if (score >= 90) NeonEmerald else NeonAmber,
                    trackColor = CyberNavySurface,
                    strokeWidth = 10.dp
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$score%",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = if (score >= 90) "ایمن‌سازی‌شده" else "بازبینی",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (score >= 90) NeonEmerald else NeonAmber,
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Metric boxes
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricBox(
                    title = "امن",
                    value = secureCount.toString(),
                    modifier = Modifier.weight(1f),
                    accentColor = NeonEmerald
                )
                MetricBox(
                    title = "هشدارها",
                    value = warnCount.toString(),
                    modifier = Modifier.weight(1f),
                    accentColor = NeonAmber
                )
                MetricBox(
                    title = "نقض‌ها",
                    value = insecureCount.toString(),
                    modifier = Modifier.weight(1f),
                    accentColor = NeonRed
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onRunAudit,
                enabled = !isAuditing,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NeonCyan,
                    contentColor = CyberNavyBackground
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("run_audit_button")
            ) {
                if (isAuditing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        color = CyberNavyBackground,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("در حال بررسی سیاست‌های امنیتی Android...")
                } else {
                    Icon(Icons.Default.Refresh, contentDescription = "ممیزی", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("اجرای دوباره ممیزی زنده امنیتی", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun AuditCheckItemCard(item: AuditCheckItem) {
    var expanded by remember { mutableStateOf(false) }

    val statusColor = when (item.status) {
        AuditStatus.SECURE -> NeonEmerald
        AuditStatus.WARNING -> NeonAmber
        AuditStatus.INSECURE -> NeonRed
    }

    CyberCard(
        borderColor = if (item.status == AuditStatus.SECURE) CyberBorder else statusColor.copy(alpha = 0.5f),
        backgroundColor = CyberNavySurface,
        onClick = { expanded = !expanded },
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = when (item.status) {
                            AuditStatus.SECURE -> Icons.Default.CheckCircle
                            AuditStatus.WARNING -> Icons.Default.Warning
                            AuditStatus.INSECURE -> Icons.Default.Security
                        },
                        contentDescription = "وضعیت",
                        tint = statusColor,
                        modifier = Modifier.size(20.dp)
                    )

                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = item.title,
                                color = TextPrimary,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            CyberBadge(
                                text = "STEP ${item.workflowStep}",
                                color = NeonCyan
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = item.summary,
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                IconButton(
                    onClick = { expanded = !expanded },
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = "تغییر وضعیت",
                        tint = TextSecondary
                    )
                }
            }

            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberNavyBackground)
                            .padding(10.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "تأیید فنی:",
                                color = TextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                            Text(
                                text = item.technicalDetails,
                                color = TextPrimary,
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }

                    if (item.recommendation != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Remediation: ${item.recommendation}",
                            color = NeonAmber,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SecurityReportDialog(
    reportText: String,
    onDismiss: () -> Unit,
    onCopy: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.Security, contentDescription = null, tint = NeonEmerald)
                Text(
                    text = "release/SECURITY_REPORT.txt",
                    color = TextPrimary,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        },
        containerColor = CyberNavyCard,
        text = {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberNavyBackground)
                    .padding(12.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = reportText,
                        color = NeonEmerald,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 16.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onCopy,
                colors = ButtonDefaults.buttonColors(containerColor = NeonEmerald, contentColor = CyberNavyBackground)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = "کپی", modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("کپی گزارش")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("بستن", color = TextSecondary)
            }
        }
    )
}

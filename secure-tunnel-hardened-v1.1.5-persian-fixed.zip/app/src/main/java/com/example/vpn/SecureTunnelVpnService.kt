package com.example.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import com.example.MainActivity
import java.io.IOException

/**
 * VPN controller. It deliberately refuses to advertise a live tunnel unless a real
 * protocol engine is attached. This prevents a false "connected" state or an accidental
 * 0/0 black-hole that would silently cut the user's internet connection.
 */
class SecureTunnelVpnService : VpnService() {
    private var tunInterface: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            when (intent?.action) {
                ACTION_STOP -> stopTunnel()
                ACTION_START -> startForegroundMode()
            }
        } catch (t: Throwable) {
            Log.e("SecureTunnelVPN", "VPN service command failed", t)
            stopTunnel()
        }
        return START_STICKY
    }

    private fun startForegroundMode() {
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
        // No protocol engine is bundled yet. Do not establish a default route.
        // A real engine must call Builder.establish() and forward TUN packets before this
        // service may report an active tunnel.
    }

    private fun stopTunnel() {
        try { tunInterface?.close() } catch (_: IOException) {}
        tunInterface = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotification(): Notification {
        val pending = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Secure Tunnel")
            .setContentText("سرویس VPN آماده است؛ موتور تونل فعال نیست")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentIntent(pending)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Secure Tunnel", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onRevoke() {
        // Android can revoke the VPN slot when another VPN takes ownership.
        // Always close our descriptor and stop so the UI cannot keep a stale state.
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.securetunnel.START"
        const val ACTION_STOP = "com.example.securetunnel.STOP"
        private const val CHANNEL_ID = "secure_tunnel"
        private const val NOTIFICATION_ID = 7001
    }
}

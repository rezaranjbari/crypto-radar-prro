# Runtime security status

- Android VPN permission flow: enabled.
- VPN service declared with `BIND_VPN_SERVICE`: enabled.
- VPN revoke cleanup: enabled.
- Profile secrets: encrypted with Android Keystore + AES-GCM.
- Cleartext traffic: disabled.
- Backup/data extraction: disabled.
- Fake Connected state: disabled.
- Fake traffic counters: disabled.
- Protocol forwarding engine: **not bundled yet**.

The app therefore fails closed rather than creating a TUN interface that drops all traffic. A real engine must be integrated before this app should be used as a daily VPN client.

# Security hardening changes — v1.1.0

- Removed Firebase/AI Studio runtime dependencies and API-key configuration.
- Removed fake/default tunnel credentials.
- Added Android Keystore + AES-GCM encrypted profile storage.
- Added migration from the previous plaintext `SharedPreferences` profile store.
- Added Android `VpnService` declaration and foreground-service notification path.
- Made tunnel connection fail-safe: the app never reports Connected without a real protocol engine.
- Removed randomized/fake traffic statistics.
- Added TLS hostname verification to endpoint probes.
- Added VMess and WireGuard URI parsing.
- Enforced release R8/resource shrinking.
- Added GitHub Actions static checks and reproducible build steps.
- Added security report artifact generation.
- Kept cleartext networking disabled and application backup disabled.
- Kept Kill Switch semantics honest: OS-level “Block connections without VPN” remains a user-controlled Android setting.

## Deliberate limitation

A VPN protocol engine is not embedded in this source package. A TUN device without packet forwarding would black-hole traffic, so the app refuses to create a default route until a real engine is integrated.

## v1.1.1 build hardening
- Fixed missing `kotlinx.coroutines.delay` import in `MainViewModel`.
- Replaced the missing launcher foreground drawable reference with a local vector drawable.
- Marked `libandroidx.graphics.path.so` as `doNotStrip` so Android packaging keeps the native library intact and does not attempt unsupported symbol stripping.
- Bumped app version to 1.1.1.

## v1.1.2 build/repository fix
- Fixed missing kotlinx.coroutines.delay import in MainViewModel.
- Replaced the missing launcher foreground drawable reference with a real vector drawable.
- Added CI preflight checks for both regressions.
- Removed the stale CI check referencing the deleted generated icon.
